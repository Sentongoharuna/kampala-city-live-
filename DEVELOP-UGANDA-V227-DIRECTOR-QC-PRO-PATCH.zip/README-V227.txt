develop.uganda V227 Director & QC Pro
Base required: V226 FIX2 Newsroom Media Intake (versionCode 22602)

Additions:
- ML Kit bundled face composition guidance for PEOPLE / INTERVIEW contexts
- screen-only preview luminance histogram
- instant MP4 QC with MediaMetadataRetriever
- instant review hub: play/share/package/social master/match/delete-confirm
- shot continuity memory
- estimated recording time from free bytes / active target bitrate
- actual CameraX/Camera2 exposed camera map and selectable real camera IDs in REPORT
- Camera Health reliability dashboard
- V226 FIX2 MediaStore newsroom intake/playback/package workflow retained

No face guide or histogram is added to CameraX OverlayEffect.
