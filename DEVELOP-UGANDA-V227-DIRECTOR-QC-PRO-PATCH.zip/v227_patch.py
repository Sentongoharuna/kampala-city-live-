from pathlib import Path
import re
import shutil

ROOT = Path("v172-source/app")
SRC = ROOT / "src/main/java/com/sentongoharuna/pulse"

REPORT = SRC / "DevelopUgandaCameraActivity.kt"
LIVE = SRC / "DevelopUgandaLiveActivity.kt"
PHOTO = SRC / "DevelopUgandaPhotoSuiteActivity.kt"
HOME = SRC / "DevelopUgandaNewsroomActivity.kt"
PACKAGER = SRC / "DevelopUgandaStoryPackager.kt"
PACKAGES = SRC / "DevelopUgandaStoryPackagesActivity.kt"
MANIFEST = ROOT / "src/main/AndroidManifest.xml"
GRADLE = ROOT / "build.gradle.kts"

PAYLOAD = Path(__file__).resolve().parent

def replace_once(text, old, new, label):
    if old not in text:
        raise SystemExit("V227 anchor missing: " + label)
    return text.replace(old, new, 1)

def insert_before(text, marker, addition, label):
    if marker not in text:
        raise SystemExit("V227 insertion anchor missing: " + label)
    return text.replace(marker, addition + marker, 1)

def replace_function(text, start_marker, next_marker, replacement, label):
    start = text.find(start_marker)
    if start < 0:
        raise SystemExit("V227 function start missing: " + label)
    end = text.find(next_marker, start + len(start_marker))
    if end < 0:
        raise SystemExit("V227 function end missing: " + label)
    return text[:start] + replacement + text[end:]

gradle = GRADLE.read_text(encoding="utf-8")

if 'versionCode = 22602' not in gradle:
    raise SystemExit("V227 requires V226 FIX2 versionCode 22602")

if 'versionName = "226.2-newsroom-media-intake"' not in gradle:
    raise SystemExit("V227 requires V226 FIX2 Newsroom Media Intake base")

for name in [
    "DevelopUgandaDirectorOverlayView.kt",
    "DevelopUgandaLensIntelligence.kt",
    "DevelopUgandaContinuityMemory.kt",
    "DevelopUgandaClipQc.kt",
    "DevelopUgandaInstantReviewDialog.kt",
    "DevelopUgandaCameraHealthActivity.kt",
]:
    shutil.copyfile(
        PAYLOAD / name,
        SRC / name
    )

report = REPORT.read_text(encoding="utf-8")

report = replace_once(
    report,
    "        const val ACTION_SHOT_ASSIST = 23\n",
    "        const val ACTION_SHOT_ASSIST = 23\n"
    "        const val ACTION_DIRECTOR = 24\n"
    "        const val ACTION_CONTINUITY = 25\n"
    "        const val ACTION_HEALTH = 26\n",
    "V227 report actions"
)

report = replace_once(
    report,
    "    private lateinit var shotAssistView: DevelopUgandaShotAssistView\n",
    "    private lateinit var shotAssistView: DevelopUgandaShotAssistView\n"
    "    private lateinit var directorOverlayView: DevelopUgandaDirectorOverlayView\n",
    "director overlay field"
)

report = replace_once(
    report,
    "    private lateinit var assistButton: Button\n",
    "    private lateinit var assistButton: Button\n"
    "    private lateinit var directorButton: Button\n"
    "    private lateinit var continuityButton: Button\n"
    "    private lateinit var healthButton: Button\n",
    "V227 button fields"
)

report = replace_once(
    report,
    "    private lateinit var reportOutputRow: LinearLayout\n",
    "    private lateinit var reportOutputRow: LinearLayout\n"
    "    private lateinit var reportDirectorRow: LinearLayout\n",
    "director row field"
)

report = replace_once(
    report,
    "    private var automaticSocialExportActive = false\n",
    "    private var automaticSocialExportActive = false\n"
    "    private var selectedCameraDeviceId: String? = null\n"
    "    private var directorEnabled = true\n",
    "V227 camera state"
)

director_runnable = '''    private val directorRunnable =
        object : Runnable {
            override fun run() {
                if (
                    ::directorOverlayView.isInitialized
                ) {
                    directorOverlayView.visibility =
                        if (
                            directorEnabled &&
                            !cleanModeEnabled
                        ) {
                            View.VISIBLE
                        } else {
                            View.GONE
                        }
                }

                if (
                    directorEnabled &&
                    !cleanModeEnabled &&
                    ::previewView.isInitialized &&
                    ::directorOverlayView.isInitialized &&
                    previewView.width > 0 &&
                    previewView.height > 0
                ) {
                    val bitmap =
                        try {
                            previewView.bitmap
                        } catch (_: Exception) {
                            null
                        }

                    if (
                        bitmap != null
                    ) {
                        directorOverlayView.submitFrame(
                            bitmap,
                            isDirectorPeopleMode()
                        )
                    }
                }

                uiHandler.postDelayed(
                    this,
                    1100L
                )
            }
        }

'''

report = insert_before(
    report,
    "    private val hideFocusReticleRunnable =\n",
    director_runnable,
    "director runnable"
)

report = replace_once(
    report,
    "        startShotAssistLoop()\n"
    "        requestPermissionsAndStart()\n",
    "        startShotAssistLoop()\n"
    "        startDirectorLoop()\n"
    "        requestPermissionsAndStart()\n",
    "start Director loop"
)

shot_assist_add = '''        root.addView(
            shotAssistView,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )


'''

director_add = shot_assist_add + '''        directorOverlayView =
            DevelopUgandaDirectorOverlayView(
                this
            ).apply {
                setDirectorEnabled(
                    directorEnabled
                )

                isClickable =
                    false

                isFocusable =
                    false
            }

        root.addView(
            directorOverlayView,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )


'''

report = replace_once(
    report,
    shot_assist_add,
    director_add,
    "Director screen overlay"
)

report = replace_once(
    report,
    '            "LENS ▾\\nBACK",\n',
    '            "LENS ▾\\n${currentLensDeckLabel()}",\n',
    "initial lens button"
)

output_anchor = '''        bottomDeck.addView(
            reportOutputRow
        )

        settingsSummaryView = hud(
'''

director_row = '''        bottomDeck.addView(
            reportOutputRow
        )

        reportDirectorRow =
            row().apply {
                gravity =
                    Gravity.CENTER

                setPadding(
                    0,
                    dp(4),
                    0,
                    0
                )
            }

        directorButton =
            deckButton(
                "DIRECTOR ▾\\n" +
                    if (
                        directorEnabled
                    ) {
                        "ON"
                    } else {
                        "OFF"
                    },
                0xFF91B6A0.toInt()
            ).apply {
                isSelected =
                    directorEnabled
            }

        continuityButton =
            deckButton(
                "MATCH LAST\\nSHOT",
                0xFFAEBDEB.toInt()
            ).apply {
                isSelected =
                    DevelopUgandaContinuityMemory.load(
                        this@DevelopUgandaCameraActivity,
                        cameraExperienceId
                    ) != null
            }

        healthButton =
            deckButton(
                "CAMERA\\nHEALTH",
                0xFF73B7D9.toInt()
            )

        listOf(
            directorButton,
            continuityButton,
            healthButton
        ).forEachIndexed {
                index,
                button ->
            reportDirectorRow.addView(
                button,
                LinearLayout.LayoutParams(
                    0,
                    dp(34),
                    1f
                ).apply {
                    if (
                        index >
                            0
                    ) {
                        marginStart =
                            dp(7)
                    }
                }
            )
        }

        bottomDeck.addView(
            reportDirectorRow
        )

        settingsSummaryView = hud(
'''

report = replace_once(
    report,
    output_anchor,
    director_row,
    "V227 operator row"
)

report = replace_once(
    report,
    "        assistButton.setOnTouchListener(\n"
    "            DeckTouchListener(ACTION_SHOT_ASSIST)\n"
    "        )\n",
    "        assistButton.setOnTouchListener(\n"
    "            DeckTouchListener(ACTION_SHOT_ASSIST)\n"
    "        )\n\n"
    "        directorButton.setOnTouchListener(\n"
    "            DeckTouchListener(ACTION_DIRECTOR)\n"
    "        )\n\n"
    "        continuityButton.setOnTouchListener(\n"
    "            DeckTouchListener(ACTION_CONTINUITY)\n"
    "        )\n\n"
    "        healthButton.setOnTouchListener(\n"
    "            DeckTouchListener(ACTION_HEALTH)\n"
    "        )\n",
    "V227 touch listeners"
)

report = replace_once(
    report,
    "                        ACTION_SHOT_ASSIST ->\n"
    "                            cycleShotAssist()\n",
    "                        ACTION_SHOT_ASSIST ->\n"
    "                            cycleShotAssist()\n\n"
    "                        ACTION_DIRECTOR ->\n"
    "                            toggleDirectorGuidance()\n\n"
    "                        ACTION_CONTINUITY ->\n"
    "                            matchLastShotContinuity()\n\n"
    "                        ACTION_HEALTH ->\n"
    "                            openV227CameraHealth()\n",
    "V227 action dispatch"
)

report = replace_once(
    report,
    "                        ACTION_CAPABILITIES ->\n"
    "                            showCameraCapabilities()\n",
    "                        ACTION_CAPABILITIES ->\n"
    "                            openV227CameraHealth()\n",
    "capabilities to Health dashboard"
)

report = report.replace(
    "            reportOutputRow,\n"
    "            zoomRow,\n",
    "            reportOutputRow,\n"
    "            reportDirectorRow,\n"
    "            zoomRow,\n"
)

report = report.replace(
    "                reportOutputRow,\n"
    "                zoomRow,\n",
    "                reportOutputRow,\n"
    "                reportDirectorRow,\n"
    "                zoomRow,\n"
)

helpers = (
    PAYLOAD /
    "report_v227_helpers.txt"
).read_text(
    encoding="utf-8"
)

report = insert_before(
    report,
    "    private fun recordingHealthText(): String {\n",
    helpers,
    "REPORT V227 helper block"
)

load_tail = '''        integrityEnabled =
            prefs.getBoolean(
                "integrity",
                integrityEnabled
            )
    }
'''

load_new = '''        integrityEnabled =
            prefs.getBoolean(
                "integrity",
                integrityEnabled
            )

        selectedCameraDeviceId =
            prefs.getString(
                "real_camera_id",
                selectedCameraDeviceId
            )

        directorEnabled =
            prefs.getBoolean(
                "director_enabled",
                directorEnabled
            )
    }
'''

report = replace_once(
    report,
    load_tail,
    load_new,
    "load V227 camera prefs"
)

save_tail = '''            .putBoolean(
                "integrity",
                integrityEnabled
            )
            .apply()
    }
'''

save_new = '''            .putBoolean(
                "integrity",
                integrityEnabled
            )
            .putString(
                "real_camera_id",
                selectedCameraDeviceId
            )
            .putBoolean(
                "director_enabled",
                directorEnabled
            )
            .apply()
    }
'''

report = replace_once(
    report,
    save_tail,
    save_new,
    "save V227 camera prefs"
)

selector_old = '''        val selector =
            if (useFront) {
                CameraSelector.DEFAULT_FRONT_CAMERA
            } else {
                CameraSelector.DEFAULT_BACK_CAMERA
            }
'''

selector_new = '''        if (
            selectedCameraDeviceId != null &&
            !DevelopUgandaLensIntelligence.hasCamera(
                p,
                selectedCameraDeviceId
            )
        ) {
            selectedCameraDeviceId =
                null
        }

        val selector =
            DevelopUgandaLensIntelligence.selectorFor(
                p,
                selectedCameraDeviceId,
                useFront
            )
'''

report = replace_once(
    report,
    selector_old,
    selector_new,
    "real lens selector"
)

bind_catch_old = '''        } catch (e: Exception) {
            toast("Selected camera is unavailable")
        }
    }

        private fun drawReporterOverlay(frame: Frame) {
'''

bind_catch_new = '''        } catch (e: Exception) {
            if (
                selectedCameraDeviceId !=
                    null
            ) {
                val failedId =
                    selectedCameraDeviceId

                selectedCameraDeviceId =
                    null

                saveReportCameraPreferences()

                toast(
                    "Camera ID $failedId cannot use this capture profile • returning to ${if (useFront) "front" else "back"} camera"
                )

                uiHandler.post {
                    bindCamera()
                }
            } else {
                toast(
                    "Selected camera is unavailable"
                )
            }
        }
    }

        private fun drawReporterOverlay(frame: Frame) {
'''

report = replace_once(
    report,
    bind_catch_old,
    bind_catch_new,
    "real lens bind fallback"
)

report = replace_once(
    report,
    "                                useFront =\n"
    "                                    !useFront\n",
    "                                selectedCameraDeviceId =\n"
    "                                    null\n\n"
    "                                useFront =\n"
    "                                    !useFront\n",
    "double tap lens reset"
)

double_label_old = '''                                lensButton.text =
                                    if (useFront) {
                                        "LENS\\nFRONT"
                                    } else {
                                        "LENS\\nBACK"
                                    }
'''

double_label_new = '''                                lensButton.text =
                                    "LENS\\n${currentLensDeckLabel()}"
'''

report = replace_once(
    report,
    double_label_old,
    double_label_new,
    "double tap real lens label"
)

refresh_lens_old = '''        if (::lensButton.isInitialized) {
            lensButton.text =
                "LENS ▾\\n${if (useFront) "FRONT" else "BACK"}"
        }
'''

refresh_lens_new = '''        if (::lensButton.isInitialized) {
            lensButton.text =
                "LENS ▾\\n${currentLensDeckLabel()}"
        }
'''

report = replace_once(
    report,
    refresh_lens_old,
    refresh_lens_new,
    "refresh real lens label"
)

new_lens_function = '''    private fun showReportLensDropdown(
        anchor: View
    ) {
        if (
            recording !=
                null
        ) {
            toast(
                "Stop recording before changing lens"
            )
            return
        }

        val selected =
            when {
                selectedCameraDeviceId !=
                    null ->
                        2

                useFront ->
                    1

                else ->
                    0
            }

        showReportPillDropdown(
            anchor,
            "REAL LENS INTELLIGENCE",
            arrayOf(
                "AUTO BACK",
                "AUTO FRONT",
                "REAL CAMERAS"
            ),
            selected
        ) {
                picked ->
            when (
                picked
            ) {
                0 -> {
                    selectedCameraDeviceId =
                        null

                    useFront =
                        false

                    saveReportCameraPreferences()
                    bindCamera()
                }

                1 -> {
                    selectedCameraDeviceId =
                        null

                    useFront =
                        true

                    saveReportCameraPreferences()
                    bindCamera()
                }

                else ->
                    showRealCameraDevicePicker()
            }
        }
    }

'''

report = replace_function(
    report,
    "    private fun showReportLensDropdown(\n",
    "    private fun showReportLightDropdown(\n",
    new_lens_function,
    "showReportLensDropdown"
)

report = replace_once(
    report,
    '                "${recordingHealthText()} • ${motionGuardLabel()}"\n',
    '                "${recordingHealthText()} • ${motionGuardLabel()} • ${estimatedRecordingTimeText()}"\n',
    "estimated recording time HUD"
)

report = replace_once(
    report,
    "                    recStarted = System.currentTimeMillis()\n",
    "                    recordingWarningsSeen.clear()\n"
    "                    recStarted = System.currentTimeMillis()\n",
    "clear per-clip warnings"
)

report = replace_once(
    report,
    '                        statusView.text = "SAVED"\n',
    '                        statusView.text = "FINALIZED • QC"\n',
    "REPORT QC status"
)

social_export_marker = '''                        if (
                            !hadError &&
                            isSocialMediaCamera()
                        ) {
'''

review_block = '''                        saveV227ContinuitySnapshot()

                        val reviewPackageId =
                            reportId.ifBlank {
                                baseName.ifBlank {
                                    "DU_${System.currentTimeMillis()}"
                                }
                            }

                        DevelopUgandaClipQc.inspect(
                            this@DevelopUgandaCameraActivity,
                            event.outputResults.outputUri,
                            reviewPackageId
                        ) {
                                result ->
                            statusView.text =
                                if (
                                    result.playableFrame &&
                                    result.hasVideo &&
                                    result.sourceReadable
                                ) {
                                    "QC READY"
                                } else {
                                    "QC CHECK"
                                }

                            statusView.setTextColor(
                                if (
                                    result.playableFrame &&
                                    result.hasVideo &&
                                    result.sourceReadable
                                ) {
                                    0xFF83B995.toInt()
                                } else {
                                    0xFFD8B85B.toInt()
                                }
                            )

                            DevelopUgandaInstantReviewDialog.show(
                                this@DevelopUgandaCameraActivity,
                                result,
                                reviewPackageId,
                                isSocialMediaCamera()
                            ) {
                                matchLastShotContinuity()
                            }
                        }

'''

report = insert_before(
    report,
    social_export_marker,
    review_block,
    "REPORT Instant QC/Review"
)

report = replace_once(
    report,
    '''                        uiHandler.postDelayed({
                            statusView.text = "STBY"
                            statusView.setTextColor(
                                0xFFFF5A52.toInt()
                            )
                        }, 1800L)
''',
    '''                        uiHandler.postDelayed({
                            if (
                                statusView.text.toString() !=
                                    "QC CHECK"
                            ) {
                                statusView.text = "STBY"
                                statusView.setTextColor(
                                    0xFFFF5A52.toInt()
                                )
                            }
                        }, 5200L)
''',
    "REPORT post-QC standby"
)

report = report.replace(
    "DEVELOP_UGANDA_V226_",
    "DEVELOP_UGANDA_V227_"
)
report = report.replace(
    '"V226"',
    '"V227"'
)
report = report.replace(
    "•   V226   •",
    "•   V227   •"
)
report = report.replace(
    "develop.uganda • V216",
    "develop.uganda • V227"
)
report = report.replace(
    '${autoDirectorStateText()} • V215',
    '${autoDirectorStateText()} • V227'
)

REPORT.write_text(
    report,
    encoding="utf-8"
)

photo = PHOTO.read_text(encoding="utf-8")

photo = replace_once(
    photo,
    "    private lateinit var assistView: DevelopUgandaShotAssistView\n",
    "    private lateinit var assistView: DevelopUgandaShotAssistView\n"
    "    private lateinit var directorView: DevelopUgandaDirectorOverlayView\n",
    "photo Director field"
)

photo_runnable_marker = '''    private val modeId by lazy {
        defaultPhotoModeId()
    }
'''

photo_runnable = '''    private val directorRunnable =
        object : Runnable {
            override fun run() {
                if (
                    ::previewView.isInitialized &&
                    ::directorView.isInitialized &&
                    previewView.width > 0 &&
                    previewView.height > 0
                ) {
                    val bitmap =
                        try {
                            previewView.bitmap
                        } catch (_: Exception) {
                            null
                        }

                    if (
                        bitmap !=
                            null
                    ) {
                        directorView.submitFrame(
                            bitmap,
                            modeId ==
                                "PEOPLE_PHOTO"
                        )
                    }
                }

                uiHandler.postDelayed(
                    this,
                    1200L
                )
            }
        }

'''

photo = insert_before(
    photo,
    photo_runnable_marker,
    photo_runnable,
    "photo Director runnable"
)

photo = replace_once(
    photo,
    '''        uiHandler.postDelayed(
            assistRunnable,
            900L
        )
''',
    '''        uiHandler.postDelayed(
            assistRunnable,
            900L
        )

        uiHandler.postDelayed(
            directorRunnable,
            1200L
        )
''',
    "photo Director start"
)

photo_assist_add = '''        root.addView(
            assistView,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

'''

photo_director_add = photo_assist_add + '''        directorView =
            DevelopUgandaDirectorOverlayView(
                this
            )

        root.addView(
            directorView,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

'''

photo = replace_once(
    photo,
    photo_assist_add,
    photo_director_add,
    "photo Director overlay"
)

PHOTO.write_text(
    photo,
    encoding="utf-8"
)

live = LIVE.read_text(encoding="utf-8")

live = replace_once(
    live,
    "    private lateinit var livePreviewToneView: View\n",
    "    private lateinit var livePreviewToneView: View\n"
    "    private lateinit var liveDirectorOverlayView: DevelopUgandaDirectorOverlayView\n",
    "LIVE Director field"
)

live_director_runnable = '''    private val liveDirectorRunnable =
        object : Runnable {
            override fun run() {
                if (
                    ::previewView.isInitialized &&
                    ::liveDirectorOverlayView.isInitialized &&
                    previewView.width > 0 &&
                    previewView.height > 0
                ) {
                    val bitmap =
                        try {
                            previewView.bitmap
                        } catch (_: Exception) {
                            null
                        }

                    if (
                        bitmap != null
                    ) {
                        liveDirectorOverlayView.submitFrame(
                            bitmap,
                            liveDirectorPeopleMode()
                        )
                    }
                }

                uiHandler.postDelayed(
                    this,
                    1200L
                )
            }
        }

'''

live = insert_before(
    live,
    "    private val uiTicker =\n",
    live_director_runnable,
    "LIVE Director runnable"
)

live = replace_once(
    live,
    "        startLiveAutoViewDescription()\n"
    "        requestNeededPermissions()\n",
    "        startLiveAutoViewDescription()\n"
    "        uiHandler.postDelayed(\n"
    "            liveDirectorRunnable,\n"
    "            1200L\n"
    "        )\n"
    "        requestNeededPermissions()\n",
    "start LIVE Director"
)

tone_add = '''        root.addView(
            livePreviewToneView,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

'''

live_director_add = tone_add + '''        liveDirectorOverlayView =
            DevelopUgandaDirectorOverlayView(
                this
            )

        root.addView(
            liveDirectorOverlayView,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

'''

live = replace_once(
    live,
    tone_add,
    live_director_add,
    "LIVE Director overlay"
)

live_helpers = (
    PAYLOAD /
    "live_v227_helpers.txt"
).read_text(
    encoding="utf-8"
)

live = insert_before(
    live,
    "    private fun liveTargetBitrate(): Int {\n",
    live_helpers,
    "LIVE estimate helpers"
)

live = replace_once(
    live,
    '                } • HEALTH $health"\n',
    '                } • HEALTH $health • ${liveEstimatedRecordingTimeText()}"\n',
    "LIVE recording-time estimate"
)

live = replace_once(
    live,
    '''                        recordButton.setRecordingState(
                            false
                        )

                        liveSubTitle.text =
                            "LIVE STUDIO • ${profiles[profileIndex]} • CONTINUOUS AF/AE/AWB • READY"
''',
    '''                        recordButton.setRecordingState(
                            false
                        )

                        liveSubTitle.text =
                            "LIVE STUDIO • ${profiles[profileIndex]} • QC CHECK"
''',
    "LIVE Finalize QC initial status"
)

live_error_marker = '''                        if (
                            event.hasError()
                        ) {
'''

live_review = '''                        if (
                            !event.hasError()
                        ) {
                            DevelopUgandaClipQc.inspect(
                                this@DevelopUgandaLiveActivity,
                                event.outputResults.outputUri,
                                liveRecordingName
                            ) {
                                    result ->
                                liveSubTitle.text =
                                    if (
                                        result.playableFrame &&
                                        result.hasVideo &&
                                        result.sourceReadable
                                    ) {
                                        "LIVE STUDIO • ${profiles[profileIndex]} • CONTINUOUS AF/AE/AWB • READY"
                                    } else {
                                        "LIVE STUDIO • ${profiles[profileIndex]} • QC CHECK"
                                    }

                                DevelopUgandaInstantReviewDialog.show(
                                    this@DevelopUgandaLiveActivity,
                                    result,
                                    liveRecordingName,
                                    false,
                                    null
                                )
                            }
                        }

'''

live = insert_before(
    live,
    live_error_marker,
    live_review,
    "LIVE Instant QC/Review"
)

live = live.replace(
    "DEVELOP_UGANDA_V226_",
    "DEVELOP_UGANDA_V227_"
)
live = live.replace(
    "V226",
    "V227"
)

LIVE.write_text(
    live,
    encoding="utf-8"
)

packager = PACKAGER.read_text(encoding="utf-8")
packager = packager.replace(
    "V226",
    "V227"
)
PACKAGER.write_text(
    packager,
    encoding="utf-8"
)

packages = PACKAGES.read_text(encoding="utf-8")
packages = packages.replace(
    "V226",
    "V227"
)
PACKAGES.write_text(
    packages,
    encoding="utf-8"
)

home = HOME.read_text(encoding="utf-8")

home = home.replace(
    '"AUTO STORY PACKAGE • V226\\nV225 PHOTO + V224 GUARD RETAINED"',
    '"DIRECTOR & QC PRO • V227\\nV226 FIX2 NEWSROOM + V225 PHOTO RETAINED"',
    1
)

independent_anchor = '''        page.addView(
            sectionTitle(
                "INDEPENDENT PRO CAMERAS"
            )
        )
'''

v227_home = '''        page.addView(
            compactStatus(
                "V227 • DIRECTOR & QC PRO",
                "SCREEN-ONLY REAL FACE COMPOSITION FOR PEOPLE/INTERVIEW • PREVIEW LUMA HISTOGRAM • ESTIMATED RECORD TIME • REAL CAMERA DEVICE MAP • SHOT CONTINUITY • INSTANT MP4 QC + REVIEW • V226 FIX2 NEWSROOM INTAKE RETAINED",
                0xFF91B6A0.toInt()
            )
        )

        page.addView(
            launchCard(
                "V227 • CAMERA HEALTH",
                "See what this phone actually exposes",
                "REAL CameraX/Camera2 device IDs + focal lengths • UHD • HLG HDR • stabilization • hardware FPS ranges • JPEG / Ultra HDR / RAW / RAW+JPEG • on-device transcription • thermal/location/storage • H.264/AAC encoder presence",
                0xFF73B7D9.toInt(),
                "OPEN CAMERA HEALTH"
            ) {
                openIndependentCamera(
                    DevelopUgandaCameraHealthActivity::class.java
                )
            }
        )

'''

home = replace_once(
    home,
    independent_anchor,
    v227_home +
    independent_anchor,
    "V227 Home section"
)

home = home.replace(
    '"AUTO STORY PACKAGE • V226"',
    '"AUTO STORY PACKAGE • V227"'
)

home = home.replace(
    '"V226 • STORY PACKAGES"',
    '"V227 • STORY PACKAGES"'
)

HOME.write_text(
    home,
    encoding="utf-8"
)

manifest = MANIFEST.read_text(encoding="utf-8")

story_player_activity = '''        <activity
            android:name=".DevelopUgandaStoryPlayerActivity"
            android:screenOrientation="portrait"
            android:exported="false"/>

'''

if ".DevelopUgandaCameraHealthActivity" not in manifest:
    manifest = replace_once(
        manifest,
        story_player_activity,
        story_player_activity +
        '''        <activity
            android:name=".DevelopUgandaCameraHealthActivity"
            android:screenOrientation="portrait"
            android:exported="false"/>

''',
        "Camera Health manifest activity"
    )

MANIFEST.write_text(
    manifest,
    encoding="utf-8"
)

if 'com.google.mlkit:face-detection:16.1.7' not in gradle:
    gradle = replace_once(
        gradle,
        '    implementation("com.google.mlkit:image-labeling:17.0.9")\n',
        '    implementation("com.google.mlkit:image-labeling:17.0.9")\n'
        '    implementation("com.google.mlkit:face-detection:16.1.7")\n',
        "ML Kit bundled face detector dependency"
    )

gradle = re.sub(
    r"versionCode\s*=\s*\d+",
    "versionCode = 22700",
    gradle,
    count=1
)

gradle = re.sub(
    r'versionName\s*=\s*"[^"]+"',
    'versionName = "227.0-director-qc-pro"',
    gradle,
    count=1
)

GRADLE.write_text(
    gradle,
    encoding="utf-8"
)

print("V227 Director & QC Pro applied.")
