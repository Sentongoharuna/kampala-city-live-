# PULSE Phase Continuity

Phase 4 is cumulative. Nothing from Phase 1, Phase 2, or Phase 3 is intentionally removed.

- Phase 1 remains: native camera, microphone recording, camera switch, torch, zoom/exposure, reporter/headline, GPS/location, altitude/speed/heading, weather, battery/storage/network HUD, newsroom burn-in and Gallery video saving.
- Phase 2 remains: professional ISO/shutter/WB/tint/focus controls where Camera2 exposes them, AE lock, physical lens discovery, stabilization controls, quality/FPS/HDR/HEVC capability reporting, audio monitor, RAW/burst/timelapse, zebra/peaking/false-colour/histogram/waveform/grid/horizon tools.
- Phase 3 remains: RTMP/RTMPS/SRT LIVE newsroom, retry/reconnect, adaptive bitrate, simultaneous local MP4 backup, stream health, lower thirds/watermark, teleprompter and local/manual comment pinning.
- Phase 4 adds advanced telemetry and metadata: synchronized 1-second telemetry samples, 10-minute weather cache refresh with offline fallback, customizable telemetry strip, optional mini-map, and a real MP4 application metadata track using MIME `application/vnd.pulse.telemetry+json`.

If timed-metadata remuxing fails on a device, the original report video is preserved and PULSE falls back to a JSONL sidecar so reporting is never blocked.

YouTube/Facebook account authentication and remote comment APIs are still not fabricated. The broadcaster supplies the platform ingest URL/stream key.

For safety and Android compliance, LIVE capture remains foreground-only. No covert background recording is implemented.
