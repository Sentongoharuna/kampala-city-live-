package com.sentongoharuna.pulse

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/** Ten-minute weather cache. Failed refreshes retain the last valid sample. */
class WeatherCache {
    @Volatile var temperatureC: Double? = null
    @Volatile var humidityPct: Int? = null
    @Volatile var windKmh: Double? = null
    @Volatile var windDirection: Int? = null
    @Volatile var condition: String = "Weather waiting"
    @Volatile private var lastRefresh = 0L
    private val io = Executors.newSingleThreadExecutor()

    fun refreshIfDue(lat: Double, lon: Double) {
        val now = System.currentTimeMillis()
        if (now - lastRefresh < 10 * 60_000L && temperatureC != null) return
        lastRefresh = now
        io.execute {
            runCatching {
                val endpoint = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                    "&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m,wind_direction_10m&timezone=auto"
                val c = URL(endpoint).openConnection() as HttpURLConnection
                c.connectTimeout = 7000; c.readTimeout = 7000
                try {
                    if (c.responseCode in 200..299) {
                        val current = JSONObject(c.inputStream.bufferedReader().use { it.readText() }).getJSONObject("current")
                        temperatureC = current.optDouble("temperature_2m").takeUnless { it.isNaN() }
                        humidityPct = current.optInt("relative_humidity_2m").takeIf { it >= 0 }
                        windKmh = current.optDouble("wind_speed_10m").takeUnless { it.isNaN() }
                        windDirection = current.optInt("wind_direction_10m").takeIf { it >= 0 }
                        condition = weatherText(current.optInt("weather_code", -1))
                    }
                } finally { c.disconnect() }
            }
        }
    }

    fun close() = io.shutdownNow()

    private fun weatherText(code: Int): String = when (code) {
        0 -> "Clear"; 1 -> "Mostly clear"; 2 -> "Partly cloudy"; 3 -> "Cloudy"
        45, 48 -> "Fog"; 51, 53, 55 -> "Drizzle"; 56, 57 -> "Freezing drizzle"
        61, 63, 65 -> "Rain"; 66, 67 -> "Freezing rain"; 71, 73, 75, 77 -> "Snow"
        80, 81, 82 -> "Rain showers"; 85, 86 -> "Snow showers"; 95 -> "Thunderstorm"
        96, 99 -> "Storm / hail"; else -> "Weather"
    }
}
