package com.sentongoharuna.pulse

import android.content.ContentValues
import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.nio.ByteBuffer
import kotlin.math.max

/**
 * Adds PULSE's synchronized JSON telemetry as a real MP4 timed metadata track.
 * MIME: application/vnd.pulse.telemetry+json
 *
 * The original video is deleted only after the enhanced MP4 is closed successfully. On any
 * failure the original remains untouched, so metadata processing can never destroy a report.
 */
object TelemetryMp4Muxer {
    const val MIME = "application/vnd.pulse.telemetry+json"

    data class Result(val success: Boolean, val outputUri: Uri?, val message: String)

    fun embedMediaStoreSource(
        context: Context,
        sourceUri: Uri,
        samples: List<TelemetrySnapshot>,
        finalDisplayName: String
    ): Result {
        val extractor = MediaExtractor()
        return try {
            context.contentResolver.openFileDescriptor(sourceUri, "r")!!.use { pfd ->
                extractor.setDataSource(pfd.fileDescriptor)
                remuxOpened(context, extractor, samples, finalDisplayName) {
                    runCatching { context.contentResolver.delete(sourceUri, null, null) }
                }
            }
        } catch (t: Throwable) {
            Result(false, null, t.message ?: "Telemetry mux failed")
        } finally {
            runCatching { extractor.release() }
        }
    }

    fun embedFileSource(
        context: Context,
        source: File,
        samples: List<TelemetrySnapshot>,
        finalDisplayName: String
    ): Result {
        if (!source.exists() || source.length() == 0L) return Result(false, null, "Backup file is empty")
        val extractor = MediaExtractor()
        return try {
            extractor.setDataSource(source.absolutePath)
            remuxOpened(context, extractor, samples, finalDisplayName) { runCatching { source.delete() } }
        } catch (t: Throwable) {
            Result(false, null, t.message ?: "Telemetry mux failed")
        } finally { runCatching { extractor.release() } }
    }

    private fun remuxOpened(
        context: Context,
        extractor: MediaExtractor,
        samples: List<TelemetrySnapshot>,
        finalDisplayName: String,
        onSuccessDeleteSource: () -> Unit
    ): Result {
        if (extractor.trackCount == 0) return Result(false, null, "No media tracks")
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, finalDisplayName)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/PULSE")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val outUri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: return Result(false, null, "Could not create enhanced Gallery video")

        try {
            resolver.openFileDescriptor(outUri, "rw")!!.use { pfd ->
                val muxer = MediaMuxer(pfd.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
                try {
                    val trackMap = IntArray(extractor.trackCount)
                    var orientation = 0
                    for (i in 0 until extractor.trackCount) {
                        val format = extractor.getTrackFormat(i)
                        if (format.containsKey(MediaFormat.KEY_ROTATION)) orientation = format.getInteger(MediaFormat.KEY_ROTATION)
                        trackMap[i] = muxer.addTrack(format)
                    }
                    val metadataFormat = MediaFormat().apply { setString(MediaFormat.KEY_MIME, MIME) }
                    val metadataTrack = muxer.addTrack(metadataFormat)
                    if (orientation != 0) runCatching { muxer.setOrientationHint(orientation) }
                    samples.firstOrNull { it.latitude != null && it.longitude != null }?.let { s ->
                        val la = s.latitude!!; val lo = s.longitude!!
                        if (la in -90.0..90.0 && lo in -180.0..180.0) runCatching { muxer.setLocation(la.toFloat(), lo.toFloat()) }
                    }
                    muxer.start()

                    for (i in 0 until extractor.trackCount) {
                        extractor.selectTrack(i)
                        extractor.seekTo(0L, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
                        val format = extractor.getTrackFormat(i)
                        val preferred = if (format.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) format.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE) else 0
                        val buffer = ByteBuffer.allocateDirect(max(16 * 1024 * 1024, preferred.coerceAtMost(64 * 1024 * 1024)))
                        val info = MediaCodec.BufferInfo()
                        while (true) {
                            buffer.clear()
                            val size = extractor.readSampleData(buffer, 0)
                            if (size < 0) break
                            info.offset = 0
                            info.size = size
                            info.presentationTimeUs = extractor.sampleTime.coerceAtLeast(0L)
                            info.flags = extractor.sampleFlags
                            muxer.writeSampleData(trackMap[i], buffer, info)
                            extractor.advance()
                        }
                        extractor.unselectTrack(i)
                    }

                    val ordered = if (samples.isEmpty()) emptyList() else samples.sortedBy { it.elapsedUs }
                    for (sample in ordered) {
                        val bytes = sample.toJson().toString().toByteArray(Charsets.UTF_8)
                        val data = ByteBuffer.wrap(bytes)
                        val info = MediaCodec.BufferInfo().apply {
                            offset = 0; size = bytes.size; presentationTimeUs = sample.elapsedUs.coerceAtLeast(0L); flags = 0
                        }
                        muxer.writeSampleData(metadataTrack, data, info)
                    }
                    muxer.stop()
                } finally { runCatching { muxer.release() } }
            }
            values.clear(); values.put(MediaStore.Video.Media.IS_PENDING, 0)
            resolver.update(outUri, values, null, null)
            onSuccessDeleteSource()
            publishJsonl(context, samples, finalDisplayName.removeSuffix(".mp4") + ".telemetry.jsonl")
            return Result(true, outUri, "Telemetry MP4 saved")
        } catch (t: Throwable) {
            runCatching { resolver.delete(outUri, null, null) }
            return Result(false, null, t.message ?: "Telemetry MP4 creation failed")
        }
    }

    fun publishSidecarOnly(context: Context, samples: List<TelemetrySnapshot>, displayName: String) {
        publishJsonl(context, samples, displayName)
    }

    private fun publishJsonl(context: Context, samples: List<TelemetrySnapshot>, displayName: String) {
        if (samples.isEmpty()) return
        runCatching {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, displayName)
                put(MediaStore.MediaColumns.MIME_TYPE, "application/x-ndjson")
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOCUMENTS + "/PULSE")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return
            context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { out ->
                samples.forEach { out.append(it.toJson().toString()).append('\n') }
            }
            values.clear(); values.put(MediaStore.MediaColumns.IS_PENDING, 0)
            context.contentResolver.update(uri, values, null, null)
        }
    }
}
