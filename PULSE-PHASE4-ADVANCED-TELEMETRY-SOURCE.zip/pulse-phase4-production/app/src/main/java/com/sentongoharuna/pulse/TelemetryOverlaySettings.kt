package com.sentongoharuna.pulse

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.view.Gravity
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AlertDialog

/** Persisted operator choices for the small broadcast telemetry strip. */
object TelemetryOverlaySettings {
    data class Settings(
        val gps: Boolean = true,
        val altitude: Boolean = true,
        val motion: Boolean = true,
        val weather: Boolean = true,
        val time: Boolean = true,
        val network: Boolean = true,
        val device: Boolean = true,
        val map: Boolean = false,
        val top: Boolean = false,
        val opacity: Float = 0.72f
    )

    private const val PREF = "pulse_phase4_telemetry"

    fun load(context: Context): Settings {
        val p = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        return Settings(
            gps = p.getBoolean("gps", true),
            altitude = p.getBoolean("altitude", true),
            motion = p.getBoolean("motion", true),
            weather = p.getBoolean("weather", true),
            time = p.getBoolean("time", true),
            network = p.getBoolean("network", true),
            device = p.getBoolean("device", true),
            map = p.getBoolean("map", false),
            top = p.getBoolean("top", false),
            opacity = p.getFloat("opacity", 0.72f).coerceIn(0.20f, 1f)
        )
    }

    fun show(activity: Activity, onChanged: (Settings) -> Unit) {
        val current = load(activity)
        val box = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 8, 36, 8)
        }
        fun check(title: String, value: Boolean): CheckBox = CheckBox(activity).apply {
            text = title
            isChecked = value
        }
        val gps = check("GPS latitude / longitude", current.gps)
        val altitude = check("Altitude / accuracy", current.altitude)
        val motion = check("Heading / speed", current.motion)
        val weather = check("Weather", current.weather)
        val time = check("Date / timezone / timecode", current.time)
        val network = check("Network / upload / dropped frames", current.network)
        val device = check("Battery / storage", current.device)
        val map = check("Map thumbnail", current.map)
        listOf(gps, altitude, motion, weather, time, network, device, map).forEach(box::addView)

        box.addView(TextView(activity).apply {
            text = "Overlay position"
            setTextColor(Color.DKGRAY)
            gravity = Gravity.START
        })
        val positions = RadioGroup(activity).apply { orientation = RadioGroup.HORIZONTAL }
        val bottom = RadioButton(activity).apply { text = "Bottom"; isChecked = !current.top }
        val top = RadioButton(activity).apply { text = "Top"; isChecked = current.top }
        positions.addView(bottom); positions.addView(top); box.addView(positions)

        val opacityLabel = TextView(activity).apply { text = "Opacity ${(current.opacity * 100).toInt()}%" }
        val opacity = SeekBar(activity).apply { max = 80; progress = ((current.opacity - .20f) * 100f).toInt().coerceIn(0, 80) }
        opacity.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                opacityLabel.text = "Opacity ${progress + 20}%"
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })
        box.addView(opacityLabel); box.addView(opacity)

        AlertDialog.Builder(activity)
            .setTitle("PULSE telemetry overlay")
            .setMessage("These choices affect the visible telemetry strip. All synchronized samples remain in the metadata track.")
            .setView(box)
            .setPositiveButton("APPLY") { _, _ ->
                val s = Settings(
                    gps.isChecked, altitude.isChecked, motion.isChecked, weather.isChecked,
                    time.isChecked, network.isChecked, device.isChecked, map.isChecked,
                    top.isChecked, ((opacity.progress + 20) / 100f).coerceIn(.20f, 1f)
                )
                activity.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                    .putBoolean("gps", s.gps).putBoolean("altitude", s.altitude)
                    .putBoolean("motion", s.motion).putBoolean("weather", s.weather)
                    .putBoolean("time", s.time).putBoolean("network", s.network)
                    .putBoolean("device", s.device).putBoolean("map", s.map)
                    .putBoolean("top", s.top).putFloat("opacity", s.opacity).apply()
                onChanged(s)
            }
            .setNegativeButton("CANCEL", null)
            .show()
    }
}
