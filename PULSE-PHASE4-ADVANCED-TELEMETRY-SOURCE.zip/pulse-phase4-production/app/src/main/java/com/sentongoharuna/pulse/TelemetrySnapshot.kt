package com.sentongoharuna.pulse

import org.json.JSONObject

/** One synchronized PULSE telemetry sample. elapsedUs shares the recording time base. */
data class TelemetrySnapshot(
    val epochMs: Long,
    val elapsedUs: Long,
    val timezone: String,
    val timecode: String,
    val mode: String,
    val reporter: String,
    val headline: String,
    val place: String,
    val latitude: Double?,
    val longitude: Double?,
    val altitudeM: Double?,
    val accuracyM: Float?,
    val speedKmh: Float?,
    val headingDeg: Float?,
    val temperatureC: Double?,
    val condition: String?,
    val humidityPct: Int?,
    val windKmh: Double?,
    val windDirectionDeg: Int?,
    val network: String,
    val upstreamKbps: Int?,
    val droppedFrames: Long?,
    val batteryPct: Int,
    val freeStorageGb: Int
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("schema", "pulse.telemetry.v1")
        put("epoch_ms", epochMs)
        put("elapsed_us", elapsedUs)
        put("timezone", timezone)
        put("timecode", timecode)
        put("mode", mode)
        put("reporter", reporter)
        put("headline", headline)
        put("place", place)
        putNullable("latitude", latitude)
        putNullable("longitude", longitude)
        putNullable("altitude_m", altitudeM)
        putNullable("accuracy_m", accuracyM)
        putNullable("speed_kmh", speedKmh)
        putNullable("heading_deg", headingDeg)
        putNullable("temperature_c", temperatureC)
        putNullable("condition", condition)
        putNullable("humidity_pct", humidityPct)
        putNullable("wind_kmh", windKmh)
        putNullable("wind_direction_deg", windDirectionDeg)
        put("network", network)
        putNullable("upstream_kbps", upstreamKbps)
        putNullable("dropped_frames", droppedFrames)
        put("battery_pct", batteryPct)
        put("free_storage_gb", freeStorageGb)
    }

    private fun JSONObject.putNullable(key: String, value: Any?) {
        if (value == null) put(key, JSONObject.NULL) else put(key, value)
    }
}
