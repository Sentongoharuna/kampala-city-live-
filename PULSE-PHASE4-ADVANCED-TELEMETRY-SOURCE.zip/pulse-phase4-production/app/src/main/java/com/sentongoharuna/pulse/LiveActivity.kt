package com.sentongoharuna.pulse

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.location.Geocoder
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.provider.MediaStore
import android.telephony.TelephonyManager
import android.view.Gravity
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.pedro.common.ConnectChecker
import com.pedro.encoder.input.gl.render.filters.`object`.TextObjectFilterRender
import com.pedro.encoder.input.sources.video.Camera2Source
import com.pedro.library.base.recording.RecordController
import com.pedro.library.generic.GenericStream
import com.pedro.library.util.BitrateAdapter
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

/**
 * Phase 3 LIVE newsroom.
 *
 * Real network streaming is supplied by RootEncoder 2.7.5 and accepts RTMP/RTMPS/SRT endpoints.
 * The activity deliberately stops capture when it leaves the foreground; there is no hidden
 * background recording in this phase.
 */
class LiveActivity : AppCompatActivity(), ConnectChecker {

    private lateinit var root: FrameLayout
    private lateinit var surface: SurfaceView
    private lateinit var liveButton: Button
    private lateinit var endpointButton: Button
    private lateinit var profileButton: Button
    private lateinit var backupButton: Button
    private lateinit var switchButton: Button
    private lateinit var torchButton: Button
    private lateinit var reportButton: Button
    private lateinit var prompterButton: Button
    private lateinit var commentsButton: Button
    private lateinit var dataButton: Button
    private lateinit var healthText: TextView
    private lateinit var lowerThirdView: TextView
    private lateinit var telemetryView: TextView
    private lateinit var miniMapView: MiniMapView
    private lateinit var teleprompterView: TextView
    private lateinit var commentView: TextView

    private lateinit var fusedLocation: FusedLocationProviderClient
    private lateinit var telemetryRecorder: TelemetrySessionRecorder
    private val weatherCache = WeatherCache()
    private var telemetrySettings = TelemetryOverlaySettings.Settings()
    private val main = Handler(Looper.getMainLooper())

    private val stream: GenericStream by lazy {
        GenericStream(this, this).apply {
            getGlInterface().autoHandleOrientation = true
            getStreamClient().setReTries(10)
        }
    }

    private var endpoint = ""
    private var providerLabel = "CUSTOM"
    private var profile = LiveProfile.BALANCED
    private var adaptiveBitrate = true
    private var localBackup = true
    private var currentBackupFile: File? = null
    private var streamStartedAt = 0L
    private var currentBitrate = 0L
    private var connected = false
    private var reconnecting = false

    private var reporter = "PULSE REPORTER"
    private var headline = "CITIZEN REPORT"
    private var place = "Location acquiring…"
    private var lat: Double? = null
    private var lon: Double? = null
    private var altitude: Double? = null
    private var accuracy: Float? = null
    private var speedKmh: Float? = null
    private var heading: Float? = null

    private var liveBadgeFilter: TextObjectFilterRender? = null
    private var lowerThirdFilter: TextObjectFilterRender? = null
    private var watermarkFilter: TextObjectFilterRender? = null
    private var telemetryFilter: TextObjectFilterRender? = null

    private var teleprompterText = ""
    private var teleprompterSpeed = 22
    private var teleprompterRunning = false
    private var teleprompterY = 0f

    private val comments = mutableListOf<String>()
    private var pinnedComment: String? = null

    private var bitrateAdapter: BitrateAdapter = createBitrateAdapter(profile)

    private val healthTick = object : Runnable {
        override fun run() {
            updateHealth()
            updateLiveGraphics()
            main.postDelayed(this, 1000L)
        }
    }

    private val teleprompterTick = object : Runnable {
        override fun run() {
            if (!teleprompterRunning || teleprompterText.isBlank()) return
            teleprompterY -= teleprompterSpeed / 12f
            if (teleprompterY < -teleprompterView.height) {
                teleprompterY = root.height.toFloat() * 0.25f
            }
            teleprompterView.translationY = teleprompterY
            main.postDelayed(this, 33L)
        }
    }

    private val locationCallback = object : LocationCallback() {
        override fun onLocationResult(result: LocationResult) {
            val loc = result.lastLocation ?: return
            lat = loc.latitude
            lon = loc.longitude
            altitude = if (loc.hasAltitude()) loc.altitude else null
            accuracy = if (loc.hasAccuracy()) loc.accuracy else null
            speedKmh = if (loc.hasSpeed()) loc.speed * 3.6f else null
            heading = if (loc.hasBearing()) loc.bearing else null
            weatherCache.refreshIfDue(loc.latitude, loc.longitude)
            if (::miniMapView.isInitialized && telemetrySettings.map) miniMapView.updateLocation(loc.latitude, loc.longitude, heading)
            try {
                val g = Geocoder(this@LiveActivity, Locale.getDefault())
                @Suppress("DEPRECATION")
                val a = g.getFromLocation(loc.latitude, loc.longitude, 1)?.firstOrNull()
                place = listOfNotNull(a?.subLocality, a?.locality, a?.subAdminArea, a?.countryName)
                    .distinct().take(3).joinToString(" • ").ifBlank { "GPS ${loc.latitude.format5()}, ${loc.longitude.format5()}" }
            } catch (_: Exception) {
                place = "GPS ${loc.latitude.format5()}, ${loc.longitude.format5()}"
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        fusedLocation = LocationServices.getFusedLocationProviderClient(this)
        telemetryRecorder = TelemetrySessionRecorder(this)
        telemetrySettings = TelemetryOverlaySettings.load(this)
        buildUi()
        if (hasPermission(Manifest.permission.CAMERA) && hasPermission(Manifest.permission.RECORD_AUDIO)) {
            prepareLivePipeline()
        } else {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO, Manifest.permission.ACCESS_FINE_LOCATION),
                309
            )
        }
        startLocation()
        main.post(healthTick)
    }

    private fun buildUi() {
        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        surface = SurfaceView(this)
        root.addView(surface, FrameLayout.LayoutParams(-1, -1))

        surface.holder.addCallback(object : SurfaceHolder.Callback {
            override fun surfaceCreated(holder: SurfaceHolder) {
                if (!stream.isOnPreview) {
                    runCatching { stream.startPreview(surface) }
                }
            }
            override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
                stream.getGlInterface().setPreviewResolution(width, height)
            }
            override fun surfaceDestroyed(holder: SurfaceHolder) {
                if (stream.isOnPreview) runCatching { stream.stopPreview() }
            }
        })

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setBackgroundColor(0xB8000000.toInt())
        }
        val title = horizontal()
        title.addView(label("PULSE LIVE", 18f, 0xFFFFD54A.toInt(), true), weight())
        title.addView(label("PHASE 4", 10f, 0xFF8FE8FF.toInt(), true).apply { gravity = Gravity.END }, weight())
        top.addView(title)
        healthText = label("STANDBY • 0.0 Mb/s • DROPPED 0 • 00:00:00", 9.5f, Color.WHITE, true)
        top.addView(healthText)
        root.addView(top, FrameLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP))

        lowerThirdView = label("PULSE LIVE\n$reporter • $place\n$headline", 13f, Color.WHITE, true).apply {
            setPadding(dp(10), dp(8), dp(10), dp(8))
            setBackgroundColor(0x99000000.toInt())
        }
        root.addView(lowerThirdView, FrameLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM).apply {
            leftMargin = dp(8); rightMargin = dp(8); bottomMargin = dp(178)
        })

        telemetryView = label("DATA STANDBY", 9f, 0xFFB8F1FF.toInt(), false).apply {
            setPadding(dp(8), dp(5), dp(8), dp(5))
            setBackgroundColor(0x78000000)
        }
        root.addView(telemetryView, FrameLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP).apply {
            leftMargin = dp(8); rightMargin = dp(8); topMargin = dp(58)
        })

        miniMapView = MiniMapView(this).apply {
            visibility = if (telemetrySettings.map) View.VISIBLE else View.GONE
            alpha = 0.94f
        }
        root.addView(miniMapView, FrameLayout.LayoutParams(dp(156), dp(156), Gravity.START or Gravity.BOTTOM).apply {
            leftMargin = dp(8); bottomMargin = dp(250)
        })

        teleprompterView = label("", 20f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(22), dp(12), dp(22), dp(12))
            setBackgroundColor(0x5A000000)
            visibility = View.GONE
        }
        root.addView(teleprompterView, FrameLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP).apply {
            topMargin = dp(120)
        })

        commentView = label("", 11f, Color.WHITE, false).apply {
            setPadding(dp(8), dp(6), dp(8), dp(6))
            setBackgroundColor(0x70000000)
            visibility = View.GONE
        }
        root.addView(commentView, FrameLayout.LayoutParams(dp(235), ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.END or Gravity.CENTER_VERTICAL).apply {
            marginEnd = dp(8)
        })

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(7), dp(8), dp(10))
            setBackgroundColor(0xE0000000.toInt())
        }

        val row1 = horizontal().apply { gravity = Gravity.CENTER }
        liveButton = Button(this).apply {
            text = "●  GO LIVE"
            setTextColor(Color.WHITE)
            textSize = 17f
            isAllCaps = false
            background = rounded(0xFFE53935.toInt(), 25f)
        }
        row1.addView(liveButton, LinearLayout.LayoutParams(dp(180), dp(52)))
        endpointButton = smallButton("ENDPOINT")
        row1.addView(space(6))
        row1.addView(endpointButton, LinearLayout.LayoutParams(dp(96), dp(46)))
        profileButton = smallButton("PROFILE")
        row1.addView(space(6))
        row1.addView(profileButton, LinearLayout.LayoutParams(dp(86), dp(46)))
        bottom.addView(row1)

        val row2 = horizontal().apply { gravity = Gravity.CENTER }
        backupButton = smallButton("BACKUP ON")
        switchButton = smallButton("FLIP")
        torchButton = smallButton("TORCH")
        reportButton = smallButton("REPORT")
        row2.addView(backupButton, weight())
        row2.addView(switchButton, weight())
        row2.addView(torchButton, weight())
        row2.addView(reportButton, weight())
        bottom.addView(row2)

        val row3 = horizontal().apply { gravity = Gravity.CENTER }
        prompterButton = smallButton("PROMPTER")
        commentsButton = smallButton("COMMENTS")
        val adaptiveButton = smallButton("AUTO RATE")
        val backButton = smallButton("CAMERA")
        row3.addView(prompterButton, weight())
        row3.addView(commentsButton, weight())
        row3.addView(adaptiveButton, weight())
        row3.addView(backButton, weight())
        bottom.addView(row3)

        val row4 = horizontal().apply { gravity = Gravity.CENTER }
        dataButton = smallButton("DATA / MAP")
        row4.addView(dataButton, LinearLayout.LayoutParams(dp(180), dp(42)))
        bottom.addView(row4)

        root.addView(bottom, FrameLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))
        setContentView(root)

        liveButton.setOnClickListener { if (stream.isStreaming) stopLive() else startLive() }
        endpointButton.setOnClickListener { editEndpoint() }
        profileButton.setOnClickListener { chooseProfile() }
        backupButton.setOnClickListener {
            localBackup = !localBackup
            backupButton.text = if (localBackup) "BACKUP ON" else "BACKUP OFF"
        }
        switchButton.setOnClickListener {
            runCatching { (stream.videoSource as? Camera2Source)?.switchCamera() }
                .onFailure { toast("Camera switch failed: ${it.message}") }
        }
        torchButton.setOnClickListener {
            val source = stream.videoSource as? Camera2Source ?: return@setOnClickListener
            runCatching {
                if (source.isLanternEnabled()) source.disableLantern() else source.enableLantern()
            }.onFailure { toast("Torch not available") }
        }
        reportButton.setOnClickListener { editReport() }
        prompterButton.setOnClickListener { configureTeleprompter() }
        commentsButton.setOnClickListener { showCommentsDialog() }
        dataButton.setOnClickListener {
            TelemetryOverlaySettings.show(this) { settings ->
                telemetrySettings = settings
                miniMapView.visibility = if (settings.map) View.VISIBLE else View.GONE
                if (settings.map && lat != null && lon != null) miniMapView.updateLocation(lat!!, lon!!, heading)
                telemetryFilter?.setAlpha(settings.opacity)
                telemetryFilter?.setPosition(5f, if (settings.top) 14f else 72f)
                updateLiveGraphics()
            }
        }
        adaptiveButton.setOnClickListener {
            adaptiveBitrate = !adaptiveBitrate
            adaptiveButton.text = if (adaptiveBitrate) "AUTO RATE" else "RATE LOCK"
        }
        backButton.setOnClickListener { finish() }
    }

    private fun prepareLivePipeline() {
        if (stream.isStreaming || stream.isRecording) return
        val wasPreview = stream.isOnPreview
        if (wasPreview) runCatching { stream.stopPreview() }
        runCatching { stream.release() }

        var ok = prepareProfile(profile)
        if (!ok && profile != LiveProfile.LOW_LATENCY) {
            profile = LiveProfile.LOW_LATENCY
            ok = prepareProfile(profile)
            toast("Device fallback: 720p30 live profile")
        }
        if (!ok) {
            toast("Live camera/audio profile could not be prepared")
            return
        }

        bitrateAdapter = createBitrateAdapter(profile)
        installStreamGraphics()
        profileButton.text = profile.short
        if (surface.holder.surface.isValid) {
            runCatching { stream.startPreview(surface) }
                .onFailure { toast("Live preview error: ${it.message}") }
        }
    }

    private fun prepareProfile(p: LiveProfile): Boolean {
        return try {
            stream.prepareVideo(p.width, p.height, p.videoBitrate, p.fps, 2, 90) &&
                stream.prepareAudio(48_000, true, 128_000, echoCanceler = true, noiseSuppressor = true)
        } catch (_: Exception) {
            false
        }
    }

    private fun startLive() {
        if (endpoint.isBlank()) {
            editEndpoint(startAfter = true)
            return
        }
        if (!(endpoint.startsWith("rtmp", true) || endpoint.startsWith("srt", true))) {
            toast("Use a full RTMP/RTMPS or SRT ingest URL")
            return
        }
        if (!stream.isOnPreview) prepareLivePipeline()
        if (stream.isStreaming) return

        try {
            streamStartedAt = System.currentTimeMillis()
            connected = false
            reconnecting = false
            telemetryRecorder.start("LIVE") { elapsedUs -> telemetrySnapshot(elapsedUs, droppedFrames()) }
            stream.startStream(endpoint.trim())
            if (localBackup) startBackup()
            liveButton.text = "■  END LIVE"
            liveButton.background = rounded(0xFFB71C1C.toInt(), 25f)
            updateLiveGraphics()
        } catch (e: Exception) {
            toast("Could not start live: ${e.message}")
        }
    }

    private fun stopLive() {
        val telemetry = if (::telemetryRecorder.isInitialized && telemetryRecorder.isActive()) telemetryRecorder.stop() else null
        val backup = currentBackupFile
        if (stream.isRecording) runCatching { stream.stopRecord() }
        currentBackupFile = null
        if (stream.isStreaming) runCatching { stream.stopStream() }
        connected = false
        reconnecting = false
        liveButton.text = "●  GO LIVE"
        liveButton.background = rounded(0xFFE53935.toInt(), 25f)
        if (backup != null && telemetry != null) {
            backupButton.text = "FINALIZING DATA"
            Thread {
                val finalName = backup.name.replace("_RAW.mp4", ".mp4")
                val result = TelemetryMp4Muxer.embedFileSource(this, backup, telemetry.samples, finalName)
                runOnUiThread {
                    if (result.success) {
                        backupButton.text = if (localBackup) "BACKUP ON" else "BACKUP OFF"
                        toast("LIVE backup saved with timed telemetry metadata")
                    } else {
                        TelemetryMp4Muxer.publishSidecarOnly(this, telemetry.samples, finalName.removeSuffix(".mp4") + ".telemetry.jsonl")
                        publishBackupToGallery(backup)
                        toast("Backup preserved; metadata mux failed: ${result.message}")
                    }
                }
            }.start()
        } else if (telemetry != null) {
            TelemetryMp4Muxer.publishSidecarOnly(this, telemetry.samples, "PULSE_LIVE_${System.currentTimeMillis()}.telemetry.jsonl")
        }
        updateHealth()
    }

    private fun startBackup() {
        if (stream.isRecording) return
        val folder = File(getExternalFilesDir(Environment.DIRECTORY_MOVIES), "PULSE-Live").apply { mkdirs() }
        val name = "PULSE_LIVE_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}_RAW.mp4"
        val file = File(folder, name)
        currentBackupFile = file
        stream.startRecord(file.absolutePath) { status ->
            if (status == RecordController.Status.RECORDING) runOnUiThread { backupButton.text = "BACKUP REC" }
        }
    }

    private fun publishBackupToGallery(file: File) {
        if (!file.exists() || file.length() == 0L) return
        Thread {
            try {
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, file.name)
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/PULSE")
                    put(MediaStore.Video.Media.IS_PENDING, 1)
                }
                val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return@Thread
                contentResolver.openOutputStream(uri)?.use { out -> file.inputStream().use { it.copyTo(out) } }
                values.clear(); values.put(MediaStore.Video.Media.IS_PENDING, 0)
                contentResolver.update(uri, values, null, null)
                file.delete()
                runOnUiThread { backupButton.text = if (localBackup) "BACKUP ON" else "BACKUP OFF" }
            } catch (_: Exception) {
                runOnUiThread { toast("Backup kept in app storage; Gallery copy failed") }
            }
        }.start()
    }

    private fun installStreamGraphics() {
        val gl = stream.getGlInterface()
        liveBadgeFilter = TextObjectFilterRender().apply {
            setText("  PULSE LIVE  ", 34f, Color.WHITE, 0xFFE53935.toInt(), Typeface.DEFAULT_BOLD)
            setScale(28f, 7f)
            setPosition(3f, 4f)
            setAlpha(0.96f)
        }
        lowerThirdFilter = TextObjectFilterRender().apply {
            setText(lowerThirdText(), 25f, Color.WHITE, 0xC8000000.toInt(), Typeface.DEFAULT_BOLD)
            setScale(90f, 12f)
            setPosition(5f, 82f)
            setAlpha(0.92f)
        }
        watermarkFilter = TextObjectFilterRender().apply {
            setText("PULSE", 26f, 0xFFFFD54A.toInt(), 0x33000000, Typeface.DEFAULT_BOLD)
            setScale(18f, 5f)
            setPosition(79f, 5f)
            setAlpha(0.85f)
        }
        telemetryFilter = TextObjectFilterRender().apply {
            setText(telemetryText(), 21f, 0xFFB8F1FF.toInt(), 0xB0000000.toInt(), Typeface.MONOSPACE)
            setScale(90f, 8f)
            setPosition(5f, if (telemetrySettings.top) 14f else 72f)
            setAlpha(telemetrySettings.opacity)
        }
        gl.addFilter(liveBadgeFilter!!)
        gl.addFilter(lowerThirdFilter!!)
        gl.addFilter(watermarkFilter!!)
        gl.addFilter(telemetryFilter!!)
    }

    private fun updateLiveGraphics() {
        lowerThirdView.text = "PULSE ${if (stream.isStreaming) "LIVE" else "STANDBY"}\n$reporter • $place\n$headline"
        lowerThirdFilter?.setText(lowerThirdText(), 25f, Color.WHITE, 0xC8000000.toInt(), Typeface.DEFAULT_BOLD)
        val badge = if (stream.isStreaming) "  PULSE LIVE  " else "  PULSE STBY  "
        liveBadgeFilter?.setText(badge, 34f, Color.WHITE, if (stream.isStreaming) 0xFFE53935.toInt() else 0xFF37474F.toInt(), Typeface.DEFAULT_BOLD)
        val data = telemetryText()
        telemetryView.text = data
        telemetryFilter?.setText(data, 21f, 0xFFB8F1FF.toInt(), 0xB0000000.toInt(), Typeface.MONOSPACE)
        telemetryFilter?.setAlpha(telemetrySettings.opacity)
    }


    private fun telemetryText(): String {
        val s = telemetrySettings
        val parts = mutableListOf<String>()
        if (s.gps && lat != null && lon != null) parts += "GPS ${"%.5f".format(Locale.US, lat)} ${"%.5f".format(Locale.US, lon)}"
        if (s.altitude) altitude?.let { parts += "ALT ${it.roundToInt()}m" }
        if (s.motion) {
            speedKmh?.let { parts += "SPD ${it.roundToInt()}km/h" }
            heading?.let { parts += "HDG ${it.roundToInt()}°" }
        }
        if (s.weather) {
            weatherCache.temperatureC?.let { parts += "WX ${"%.1f".format(Locale.US, it)}C ${weatherCache.condition}" }
            weatherCache.humidityPct?.let { parts += "RH ${it}%" }
            weatherCache.windKmh?.let { parts += "WIND ${"%.0f".format(Locale.US, it)}km/h" }
        }
        if (s.network) parts += "NET ${networkLabel()} ${upstreamKbps() ?: 0}kbps DROP ${droppedFrames()}"
        if (s.device) parts += "BAT ${batteryPercent()}% FREE ${freeStorageGb()}GB"
        if (s.time) parts += SimpleDateFormat("HH:mm:ss z", Locale.US).format(Date())
        return if (parts.isEmpty()) "PULSE DATA" else parts.joinToString(" • ")
    }

    private fun telemetrySnapshot(elapsedUs: Long, dropped: Long?): TelemetrySnapshot = TelemetrySnapshot(
        epochMs = System.currentTimeMillis(), elapsedUs = elapsedUs,
        timezone = TelemetrySessionRecorder.timezoneId(), timecode = TelemetrySessionRecorder.timecode(elapsedUs),
        mode = "LIVE", reporter = reporter, headline = headline, place = place,
        latitude = lat, longitude = lon, altitudeM = altitude, accuracyM = accuracy, speedKmh = speedKmh, headingDeg = heading,
        temperatureC = weatherCache.temperatureC, condition = weatherCache.condition, humidityPct = weatherCache.humidityPct,
        windKmh = weatherCache.windKmh, windDirectionDeg = weatherCache.windDirection,
        network = networkLabel(), upstreamKbps = upstreamKbps(), droppedFrames = dropped,
        batteryPct = batteryPercent(), freeStorageGb = freeStorageGb()
    )

    private fun droppedFrames(): Long? = runCatching {
        stream.getStreamClient().getDroppedVideoFrames() + stream.getStreamClient().getDroppedAudioFrames()
    }.getOrNull()

    private fun upstreamKbps(): Int? {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        return runCatching { cm.getNetworkCapabilities(cm.activeNetwork)?.linkUpstreamBandwidthKbps?.takeIf { it > 0 } }.getOrNull()
    }

    private fun batteryPercent(): Int {
        val i: Intent = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return -1
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        return if (level >= 0 && scale > 0) (level * 100f / scale).roundToInt() else -1
    }

    private fun freeStorageGb(): Int = runCatching {
        (StatFs(Environment.getExternalStorageDirectory().absolutePath).availableBytes / 1_073_741_824L).toInt()
    }.getOrDefault(-1)

    private fun lowerThirdText(): String {
        val time = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        return " $headline  |  $reporter  |  $place  |  $time "
    }

    private fun updateHealth() {
        val uptime = if (streamStartedAt == 0L || !stream.isStreaming) 0L else System.currentTimeMillis() - streamStartedAt
        val c = stream.getStreamClient()
        val drop = runCatching { c.getDroppedVideoFrames() + c.getDroppedAudioFrames() }.getOrDefault(0L)
        val cache = runCatching { "${c.getItemsInCache()}/${c.getCacheSize()}" }.getOrDefault("--")
        val state = when {
            reconnecting -> "RECONNECTING"
            connected -> "LIVE"
            stream.isStreaming -> "CONNECTING"
            else -> "STANDBY"
        }
        healthText.text = "$state • ${"%.2f".format(Locale.US, currentBitrate / 1_000_000.0)} Mb/s • DROP $drop • CACHE $cache • ${networkLabel()} • ${formatMs(uptime)}"
    }

    private fun editEndpoint(startAfter: Boolean = false) {
        val input = EditText(this).apply {
            hint = "rtmps://…/stream-key   or   srt://host:port?..."
            setText(endpoint)
            setTextColor(Color.WHITE)
            setHintTextColor(0xFF90A4AE.toInt())
            setSingleLine(false)
            minLines = 2
        }
        val providers = arrayOf("CUSTOM", "YOUTUBE", "FACEBOOK", "SRT")
        var selected = providers.indexOf(providerLabel).coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle("Live ingest endpoint")
            .setSingleChoiceItems(providers, selected) { _, which -> selected = which }
            .setMessage("Paste the full ingest URL supplied by the platform. PULSE does not create or expose your stream key.")
            .setView(input)
            .setPositiveButton("SAVE") { _, _ ->
                endpoint = input.text.toString().trim()
                providerLabel = providers[selected]
                endpointButton.text = providerLabel.take(8)
                if (startAfter && endpoint.isNotBlank()) startLive()
            }
            .setNegativeButton("CANCEL", null)
            .show()
    }

    private fun chooseProfile() {
        if (stream.isStreaming || stream.isRecording) {
            toast("End LIVE before changing profile")
            return
        }
        val items = LiveProfile.entries.map { "${it.title} • ${it.width}x${it.height} • ${it.fps}fps • ${it.videoBitrate / 1_000_000.0}Mb/s" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Live quality profile")
            .setSingleChoiceItems(items, LiveProfile.entries.indexOf(profile)) { dialog, which ->
                profile = LiveProfile.entries[which]
                profileButton.text = profile.short
                dialog.dismiss()
                prepareLivePipeline()
            }.show()
    }

    private fun editReport() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), 0, dp(16), 0) }
        val r = EditText(this).apply { hint = "Reporter"; setText(reporter) }
        val h = EditText(this).apply { hint = "Headline"; setText(headline) }
        box.addView(r); box.addView(h)
        AlertDialog.Builder(this).setTitle("Live lower third").setView(box)
            .setPositiveButton("APPLY") { _, _ ->
                reporter = r.text.toString().ifBlank { "PULSE REPORTER" }
                headline = h.text.toString().ifBlank { "CITIZEN REPORT" }
                updateLiveGraphics()
            }.setNegativeButton("CANCEL", null).show()
    }

    private fun configureTeleprompter() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), 0, dp(16), 0) }
        val input = EditText(this).apply { hint = "Teleprompter script"; setText(teleprompterText); minLines = 5 }
        val speedLabel = TextView(this).apply { text = "Speed $teleprompterSpeed" }
        val speed = SeekBar(this).apply { max = 60; progress = teleprompterSpeed }
        speed.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { teleprompterSpeed = progress.coerceAtLeast(5); speedLabel.text = "Speed $teleprompterSpeed" }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })
        box.addView(input); box.addView(speedLabel); box.addView(speed)
        AlertDialog.Builder(this).setTitle("Teleprompter").setView(box)
            .setPositiveButton(if (teleprompterRunning) "STOP" else "START") { _, _ ->
                teleprompterText = input.text.toString()
                teleprompterView.text = teleprompterText
                teleprompterRunning = !teleprompterRunning
                teleprompterView.visibility = if (teleprompterRunning) View.VISIBLE else View.GONE
                if (teleprompterRunning) {
                    teleprompterY = root.height * 0.25f
                    main.removeCallbacks(teleprompterTick)
                    main.post(teleprompterTick)
                }
            }.setNegativeButton("CANCEL", null).show()
    }

    private fun showCommentsDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), 0, dp(16), 0) }
        val note = TextView(this).apply { text = "Phase 3 comment monitor is local/manual. Platform comment APIs require the broadcaster's authenticated account integration." }
        val input = EditText(this).apply { hint = "Add monitor comment" }
        box.addView(note); box.addView(input)
        AlertDialog.Builder(this).setTitle("Live comment monitor").setView(box)
            .setPositiveButton("ADD") { _, _ ->
                val c = input.text.toString().trim()
                if (c.isNotBlank()) comments.add(0, c)
                refreshComments()
            }
            .setNeutralButton("PIN LATEST") { _, _ ->
                pinnedComment = comments.firstOrNull()
                refreshComments()
            }
            .setNegativeButton("HIDE") { _, _ -> commentView.visibility = View.GONE }
            .show()
    }

    private fun refreshComments() {
        val pinned = pinnedComment?.let { "📌 $it\n" } ?: ""
        val body = comments.take(4).joinToString("\n") { "• $it" }
        commentView.text = "COMMENT MONITOR\n$pinned$body"
        commentView.visibility = if (comments.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun createBitrateAdapter(p: LiveProfile): BitrateAdapter = BitrateAdapter {
        runCatching { stream.setVideoBitrateOnFly(it) }
    }.apply { setMaxBitrate(p.videoBitrate + 128_000) }

    private fun startLocation() {
        if (!hasPermission(Manifest.permission.ACCESS_FINE_LOCATION)) return
        val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 1000L)
            .setMinUpdateIntervalMillis(1000L).build()
        try { fusedLocation.requestLocationUpdates(request, locationCallback, Looper.getMainLooper()) } catch (_: SecurityException) {}
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 309) {
            if (hasPermission(Manifest.permission.CAMERA) && hasPermission(Manifest.permission.RECORD_AUDIO)) prepareLivePipeline()
            else toast("Camera and microphone permissions are required for LIVE")
            startLocation()
        }
    }

    override fun onConnectionStarted(url: String) {
        reconnecting = false
        runOnUiThread { updateHealth() }
    }

    override fun onConnectionSuccess() {
        connected = true
        reconnecting = false
        runOnUiThread { toast("PULSE LIVE connected") }
    }

    override fun onConnectionFailed(reason: String) {
        connected = false
        reconnecting = true
        if (stream.isStreaming && stream.getStreamClient().reTry(3000, reason, null)) {
            runOnUiThread { updateHealth() }
        } else {
            runOnUiThread {
                toast("LIVE failed: $reason")
                stopLive()
            }
        }
    }

    override fun onNewBitrate(bitrate: Long) {
        currentBitrate = bitrate
        if (adaptiveBitrate && stream.isStreaming) {
            runCatching { bitrateAdapter.adaptBitrate(bitrate, stream.getStreamClient().hasCongestion()) }
        }
    }

    override fun onDisconnect() {
        connected = false
        reconnecting = false
        runOnUiThread { updateHealth() }
    }

    override fun onAuthError() {
        runOnUiThread {
            toast("Stream authentication rejected")
            stopLive()
        }
    }

    override fun onAuthSuccess() = Unit

    override fun onStop() {
        super.onStop()
        // Phase 3 does not perform hidden/background camera capture.
        if (stream.isStreaming || stream.isRecording) stopLive()
    }

    override fun onDestroy() {
        if (::telemetryRecorder.isInitialized && telemetryRecorder.isActive()) telemetryRecorder.stop()
        weatherCache.close()
        main.removeCallbacksAndMessages(null)
        runCatching { fusedLocation.removeLocationUpdates(locationCallback) }
        if (stream.isStreaming || stream.isRecording) stopLive()
        runCatching { stream.release() }
        super.onDestroy()
    }

    private fun networkLabel(): String {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val n = cm.activeNetwork ?: return "OFFLINE"
        val c = cm.getNetworkCapabilities(n) ?: return "OFFLINE"
        return when {
            c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi‑Fi"
            c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> cellularGeneration()
            c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "LAN"
            else -> "NET"
        }
    }

    private fun formatMs(ms: Long): String {
        val total = ms / 1000
        return String.format(Locale.US, "%02d:%02d:%02d", total / 3600, (total / 60) % 60, total % 60)
    }

    private fun Double.format5() = String.format(Locale.US, "%.5f", this)
    private fun hasPermission(p: String) = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun dp(v: Int) = (v * resources.displayMetrics.density).roundToInt()
    private fun horizontal() = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
    private fun weight() = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
    private fun space(w: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(dp(w), 1) }
    private fun label(t: String, s: Float, c: Int, bold: Boolean) = TextView(this).apply {
        text = t; textSize = s; setTextColor(c); typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
    }
    private fun smallButton(t: String) = Button(this).apply {
        text = t; textSize = 10f; setTextColor(Color.WHITE); isAllCaps = false; background = rounded(0xFF263238.toInt(), 12f)
        minWidth = 0; minHeight = 0; setPadding(dp(4), 0, dp(4), 0)
    }
    private fun rounded(fill: Int, radiusDp: Float) = GradientDrawable().apply {
        setColor(fill); cornerRadius = dp(radiusDp.roundToInt()).toFloat()
    }

    enum class LiveProfile(val title: String, val short: String, val width: Int, val height: Int, val fps: Int, val videoBitrate: Int) {
        LOW_LATENCY("Low latency", "720P30", 1280, 720, 30, 2_500_000),
        BALANCED("Balanced", "1080P30", 1920, 1080, 30, 5_000_000),
        QUALITY("Quality", "1080P60", 1920, 1080, 60, 8_000_000)
    }
}
