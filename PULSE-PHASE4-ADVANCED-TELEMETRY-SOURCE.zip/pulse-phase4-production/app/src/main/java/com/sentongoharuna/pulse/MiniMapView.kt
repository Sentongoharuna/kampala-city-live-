package com.sentongoharuna.pulse

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.view.View
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.tan

/**
 * Small network-assisted OpenStreetMap tile preview. It keeps the last tile cached and falls back
 * to a coordinate grid, so recording never depends on map connectivity.
 */
class MiniMapView(context: Context) : View(context) {
    private val executor = Executors.newSingleThreadExecutor()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 22f
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
    }
    @Volatile private var bitmap: Bitmap? = null
    @Volatile private var lat: Double? = null
    @Volatile private var lon: Double? = null
    @Volatile private var heading: Float? = null
    private var lastKey = ""

    fun updateLocation(latitude: Double, longitude: Double, headingDeg: Float?) {
        lat = latitude; lon = longitude; heading = headingDeg
        val z = 15
        val n = 2.0.pow(z)
        val x = floor((longitude + 180.0) / 360.0 * n).toInt()
        val latRad = Math.toRadians(latitude.coerceIn(-85.0511, 85.0511))
        val y = floor((1.0 - ln(tan(latRad) + 1.0 / cos(latRad)) / PI) / 2.0 * n).toInt()
        val key = "$z-$x-$y"
        if (key == lastKey) { invalidate(); return }
        lastKey = key
        executor.execute {
            val cache = File(context.cacheDir, "pulse-map-$key.png")
            val loaded = runCatching {
                if (cache.exists() && cache.length() > 0) BitmapFactory.decodeFile(cache.absolutePath)
                else {
                    val c = URL("https://tile.openstreetmap.org/$z/$x/$y.png").openConnection() as HttpURLConnection
                    c.connectTimeout = 4000; c.readTimeout = 4000
                    c.setRequestProperty("User-Agent", "PULSE-Android/Phase4")
                    try {
                        if (c.responseCode in 200..299) {
                            val bytes = c.inputStream.use { it.readBytes() }
                            cache.writeBytes(bytes)
                            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                        } else null
                    } finally { c.disconnect() }
                }
            }.getOrNull()
            if (loaded != null) bitmap = loaded
            postInvalidate()
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(0xCC101820.toInt())
        bitmap?.let { b -> canvas.drawBitmap(b, null, android.graphics.Rect(0, 0, width, height), paint) }
        paint.color = 0xAA000000.toInt(); canvas.drawRect(0f, height - 42f, width.toFloat(), height.toFloat(), paint)
        paint.color = 0xFFFFD54A.toInt(); paint.strokeWidth = 3f
        val cx = width / 2f; val cy = height / 2f
        canvas.drawLine(cx - 14, cy, cx + 14, cy, paint); canvas.drawLine(cx, cy - 14, cx, cy + 14, paint)
        val hdg = heading
        if (hdg != null) {
            val r = Math.toRadians((hdg - 90f).toDouble())
            canvas.drawLine(cx, cy, cx + (28 * kotlin.math.cos(r)).toFloat(), cy + (28 * kotlin.math.sin(r)).toFloat(), paint)
        }
        val la = lat; val lo = lon
        val line = if (la != null && lo != null) String.format(Locale.US, "%.5f  %.5f", la, lo) else "MAP WAITING"
        canvas.drawText(line, 8f, height - 14f, text)
        text.textSize = 14f
        canvas.drawText("© OpenStreetMap contributors", 8f, 18f, text)
        text.textSize = 22f
    }

    override fun onDetachedFromWindow() {
        executor.shutdownNow()
        super.onDetachedFromWindow()
    }
}
