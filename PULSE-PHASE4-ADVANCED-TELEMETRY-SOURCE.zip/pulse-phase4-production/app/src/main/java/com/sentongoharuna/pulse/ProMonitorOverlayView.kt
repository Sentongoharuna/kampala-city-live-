package com.sentongoharuna.pulse

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.view.View
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicReference
import kotlin.math.abs
import kotlin.math.max

class ProMonitorOverlayView(context: Context) : View(context) {

    data class FrameData(
        val cols: Int,
        val rows: Int,
        val luma: IntArray,
        val edge: BooleanArray,
        val histogram: IntArray,
        val waveform: FloatArray
    )

    private val frameRef = AtomicReference<FrameData?>(null)
    @Volatile var zebraEnabled = false
    @Volatile var peakingEnabled = false
    @Volatile var falseColorEnabled = false
    @Volatile var histogramEnabled = false
    @Volatile var waveformEnabled = false
    @Volatile var gridEnabled = true
    @Volatile var horizonEnabled = true
    @Volatile var rollDegrees = 0f

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        textSize = 22f
    }

    fun updateFrame(data: FrameData) {
        frameRef.set(data)
        postInvalidateOnAnimation()
    }

    fun updateRoll(degrees: Float) {
        rollDegrees = degrees
        postInvalidateOnAnimation()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 1 || h <= 1) return

        val data = frameRef.get()
        if (data != null && (zebraEnabled || peakingEnabled || falseColorEnabled)) {
            drawAnalysisCells(canvas, data, w, h)
        }
        if (gridEnabled) drawGrid(canvas, w, h)
        if (horizonEnabled) drawHorizon(canvas, w, h)
        if (data != null && histogramEnabled) drawHistogram(canvas, data.histogram, w, h)
        if (data != null && waveformEnabled) drawWaveform(canvas, data.waveform, w, h)
    }

    private fun drawAnalysisCells(canvas: Canvas, data: FrameData, w: Float, h: Float) {
        val cellW = w / data.cols
        val cellH = h / data.rows
        for (r in 0 until data.rows) {
            for (c in 0 until data.cols) {
                val i = r * data.cols + c
                val y = data.luma[i]
                val l = c * cellW
                val t = r * cellH
                val rr = l + cellW + 1f
                val bb = t + cellH + 1f

                if (falseColorEnabled) {
                    paint.style = Paint.Style.FILL
                    paint.color = when {
                        y < 32 -> 0x663F51B5
                        y < 80 -> 0x6633B5E5
                        y < 128 -> 0x664CAF50
                        y < 190 -> 0x66FFC107
                        y < 235 -> 0x66FF9800
                        else -> 0x66F44336
                    }.toInt()
                    canvas.drawRect(l, t, rr, bb, paint)
                }

                if (zebraEnabled && y >= 235) {
                    line.color = Color.WHITE
                    line.strokeWidth = max(2f, cellW / 7f)
                    var x = l - cellH
                    while (x < rr) {
                        canvas.drawLine(x, bb, x + cellH, t, line)
                        x += cellW / 2f
                    }
                }

                if (peakingEnabled && data.edge[i]) {
                    paint.style = Paint.Style.FILL
                    paint.color = 0xFFE8FF00.toInt()
                    val cx = l + cellW * 0.5f
                    val cy = t + cellH * 0.5f
                    val radius = max(1.5f, minOf(cellW, cellH) * 0.13f)
                    canvas.drawCircle(cx, cy, radius, paint)
                }
            }
        }
    }

    private fun drawGrid(canvas: Canvas, w: Float, h: Float) {
        line.color = 0x66FFFFFF
        line.strokeWidth = 1.5f
        canvas.drawLine(w / 3f, 0f, w / 3f, h, line)
        canvas.drawLine(2f * w / 3f, 0f, 2f * w / 3f, h, line)
        canvas.drawLine(0f, h / 3f, w, h / 3f, line)
        canvas.drawLine(0f, 2f * h / 3f, w, 2f * h / 3f, line)
    }

    private fun drawHorizon(canvas: Canvas, w: Float, h: Float) {
        val cx = w / 2f
        val cy = h / 2f
        canvas.save()
        canvas.rotate(-rollDegrees, cx, cy)
        line.color = if (abs(rollDegrees) < 1.2f) 0xFF8DFF9A.toInt() else 0xFFFFD54A.toInt()
        line.strokeWidth = 3f
        canvas.drawLine(cx - w * 0.16f, cy, cx - 18f, cy, line)
        canvas.drawLine(cx + 18f, cy, cx + w * 0.16f, cy, line)
        canvas.drawLine(cx, cy - 12f, cx, cy + 12f, line)
        canvas.restore()
        textPaint.color = 0xCCFFFFFF.toInt()
        textPaint.textSize = 18f
        canvas.drawText(String.format("LEVEL %+4.1f°", rollDegrees), 18f, h * 0.52f, textPaint)
    }

    private fun drawHistogram(canvas: Canvas, hist: IntArray, w: Float, h: Float) {
        val boxW = w * 0.42f
        val boxH = h * 0.18f
        val left = 16f
        val top = h - boxH - 230f
        paint.style = Paint.Style.FILL
        paint.color = 0xA0000000.toInt()
        canvas.drawRoundRect(left, top, left + boxW, top + boxH, 12f, 12f, paint)
        val maxBin = hist.maxOrNull()?.coerceAtLeast(1) ?: 1
        line.color = 0xFF8FE8FF.toInt()
        line.strokeWidth = max(1f, boxW / hist.size * 0.7f)
        for (i in hist.indices) {
            val x = left + 8f + (boxW - 16f) * i / (hist.size - 1f)
            val y = top + boxH - 8f
            val bh = (boxH - 25f) * hist[i] / maxBin.toFloat()
            canvas.drawLine(x, y, x, y - bh, line)
        }
        textPaint.color = 0xFF8FE8FF.toInt()
        textPaint.textSize = 17f
        canvas.drawText("HISTOGRAM", left + 8f, top + 19f, textPaint)
    }

    private fun drawWaveform(canvas: Canvas, wave: FloatArray, w: Float, h: Float) {
        val boxW = w * 0.42f
        val boxH = h * 0.18f
        val right = w - 16f
        val left = right - boxW
        val top = h - boxH - 230f
        paint.style = Paint.Style.FILL
        paint.color = 0xA0000000.toInt()
        canvas.drawRoundRect(left, top, right, top + boxH, 12f, 12f, paint)
        val path = Path()
        for (i in wave.indices) {
            val x = left + 8f + (boxW - 16f) * i / (wave.size - 1f)
            val y = top + boxH - 8f - (boxH - 26f) * wave[i].coerceIn(0f, 1f)
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        line.color = 0xFFFFD54A.toInt()
        line.strokeWidth = 2.5f
        canvas.drawPath(path, line)
        textPaint.color = 0xFFFFD54A.toInt()
        textPaint.textSize = 17f
        canvas.drawText("WAVEFORM", left + 8f, top + 19f, textPaint)
    }
}

class LumaFrameAnalyzer(
    private val overlay: ProMonitorOverlayView
) : ImageAnalysis.Analyzer {
    override fun analyze(image: ImageProxy) {
        try {
            val plane = image.planes.firstOrNull() ?: return
            val buffer = plane.buffer
            val rowStride = plane.rowStride
            val pixelStride = plane.pixelStride
            val width = image.width
            val height = image.height
            if (width <= 2 || height <= 2) return

            val cols = 32
            val rows = 18
            val luma = IntArray(cols * rows)
            val edge = BooleanArray(cols * rows)
            val histogram = IntArray(64)
            val waveAccum = FloatArray(64)
            val waveCount = IntArray(64)

            for (r in 0 until rows) {
                val py = ((r + 0.5f) * height / rows).toInt().coerceIn(0, height - 1)
                for (c in 0 until cols) {
                    val px = ((c + 0.5f) * width / cols).toInt().coerceIn(0, width - 1)
                    val y = readY(buffer, rowStride, pixelStride, px, py)
                    val i = r * cols + c
                    luma[i] = y
                    histogram[(y * 63 / 255).coerceIn(0, 63)]++
                    val wx = (c * 64 / cols).coerceIn(0, 63)
                    waveAccum[wx] += y / 255f
                    waveCount[wx]++
                }
            }

            for (r in 1 until rows) {
                for (c in 1 until cols) {
                    val i = r * cols + c
                    val dx = abs(luma[i] - luma[i - 1])
                    val dy = abs(luma[i] - luma[i - cols])
                    edge[i] = dx + dy >= 70
                }
            }

            val waveform = FloatArray(64)
            for (i in waveform.indices) {
                waveform[i] = if (waveCount[i] > 0) waveAccum[i] / waveCount[i] else 0f
            }
            overlay.updateFrame(ProMonitorOverlayView.FrameData(cols, rows, luma, edge, histogram, waveform))
        } finally {
            image.close()
        }
    }

    private fun readY(buffer: ByteBuffer, rowStride: Int, pixelStride: Int, x: Int, y: Int): Int {
        val index = y * rowStride + x * pixelStride
        return if (index in 0 until buffer.limit()) buffer.get(index).toInt() and 0xFF else 0
    }
}
