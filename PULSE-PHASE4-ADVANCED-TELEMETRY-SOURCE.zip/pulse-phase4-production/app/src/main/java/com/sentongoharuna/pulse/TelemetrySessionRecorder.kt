package com.sentongoharuna.pulse

import android.content.Context
import android.os.Environment
import android.os.Handler
import android.os.Looper
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.CopyOnWriteArrayList

/**
 * Records one telemetry sample per second and mirrors it to a crash-resilient JSONL sidecar.
 * The same samples can later be written into an MP4 application-prefixed timed metadata track.
 */
class TelemetrySessionRecorder(private val context: Context) {
    data class Result(val samples: List<TelemetrySnapshot>, val sidecar: File?)

    private val handler = Handler(Looper.getMainLooper())
    private val samples = CopyOnWriteArrayList<TelemetrySnapshot>()
    private var supplier: ((Long) -> TelemetrySnapshot)? = null
    private var startedAtMs = 0L
    private var sidecarFile: File? = null
    private var active = false

    private val tick = object : Runnable {
        override fun run() {
            if (!active) return
            captureNow()
            handler.postDelayed(this, 1000L)
        }
    }

    @Synchronized
    fun start(sessionPrefix: String, snapshotSupplier: (Long) -> TelemetrySnapshot) {
        stop()
        samples.clear()
        supplier = snapshotSupplier
        startedAtMs = System.currentTimeMillis()
        active = true
        val folder = File(context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), "PULSE-Telemetry").apply { mkdirs() }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date(startedAtMs))
        sidecarFile = File(folder, "${sessionPrefix}_${stamp}.jsonl")
        captureNow()
        handler.postDelayed(tick, 1000L)
    }

    @Synchronized
    fun stop(): Result {
        if (active) captureNow()
        active = false
        handler.removeCallbacks(tick)
        supplier = null
        return Result(samples.toList(), sidecarFile)
    }

    fun isActive(): Boolean = active

    private fun captureNow() {
        val s = supplier ?: return
        val elapsedUs = ((System.currentTimeMillis() - startedAtMs).coerceAtLeast(0L)) * 1000L
        val snap = s(elapsedUs)
        samples.add(snap)
        sidecarFile?.let { file ->
            runCatching {
                FileWriter(file, true).use { out ->
                    out.append(snap.toJson().toString()).append('\n')
                }
            }
        }
    }

    companion object {
        fun timezoneId(): String = TimeZone.getDefault().id
        fun timecode(elapsedUs: Long): String {
            val totalMs = elapsedUs / 1000L
            val h = totalMs / 3_600_000L
            val m = (totalMs % 3_600_000L) / 60_000L
            val s = (totalMs % 60_000L) / 1000L
            val ms = totalMs % 1000L
            return String.format(Locale.US, "%02d:%02d:%02d.%03d", h, m, s, ms)
        }
    }
}
