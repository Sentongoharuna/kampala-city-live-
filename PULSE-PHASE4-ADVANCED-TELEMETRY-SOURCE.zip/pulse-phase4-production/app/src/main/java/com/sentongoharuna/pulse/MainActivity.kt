package com.sentongoharuna.pulse

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.params.RggbChannelVector
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.MediaCodecList
import android.media.MediaScannerConnection
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.location.Address
import android.location.Geocoder
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.provider.MediaStore
import android.telephony.TelephonyManager
import android.util.Range
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.camera2.interop.Camera2CameraControl
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.CaptureRequestOptions
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.Camera
import androidx.camera.core.CameraEffect
import androidx.camera.core.CameraSelector
import androidx.camera.core.DynamicRange
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.core.SessionConfig
import androidx.camera.effects.OverlayEffect
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.ExperimentalAudioApi
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.PendingRecording
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.roundToInt

@OptIn(ExperimentalCamera2Interop::class, ExperimentalAudioApi::class)
class MainActivity : AppCompatActivity(), SensorEventListener {

    private lateinit var root: FrameLayout
    private lateinit var previewView: PreviewView
    private lateinit var recordButton: Button
    private lateinit var switchButton: Button
    private lateinit var torchButton: Button
    private lateinit var reportButton: Button
    private lateinit var statusText: TextView
    private lateinit var timeText: TextView
    private lateinit var locationText: TextView
    private lateinit var weatherText: TextView
    private lateinit var deviceText: TextView
    private lateinit var headlineText: TextView
    private lateinit var zoomSeek: SeekBar
    private lateinit var exposureSeek: SeekBar
    private lateinit var proButton: Button
    private lateinit var lensButton: Button
    private lateinit var photoButton: Button
    private lateinit var liveButton: Button
    private lateinit var telemetryButton: Button
    private lateinit var proStatusText: TextView
    private lateinit var monitorOverlay: ProMonitorOverlayView
    private lateinit var miniMapView: MiniMapView

    private var provider: ProcessCameraProvider? = null
    private var camera: Camera? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null
    private var overlayEffect: OverlayEffect? = null
    private var imageCapture: ImageCapture? = null
    private var imageAnalysis: ImageAnalysis? = null
    private var frontCamera = false
    private var torchOn = false
    private var burnInActive = false
    private var locationStarted = false

    private var manualMode = false
    private var manualSensorSupported = false
    private var isoRange: Range<Int>? = null
    private var exposureTimeRange: Range<Long>? = null
    private var minFocusDistance = 0f
    private var isoValue = 200
    private var shutterAngle = 180
    private var wbKelvin = 5600
    private var wbTint = 0
    private var focusPercent = 0
    private var aeLock = false
    private var videoStabilization = false
    private var oisEnabled = false
    private var lowLightBoost = false
    private var targetFps = 30
    private var selectedQuality: Quality = Quality.UHD
    private var rawSupported = false
    private var highSpeedMaxFps = 60
    private var hevcHardware = false
    private var hdr10BitSupported = false
    private var uhdSupported = false
    private var oisSupported = false
    private var eisSupported = false
    private var lowLightSupported = false
    private var lastAudioDb = -60.0
    private var lastAudioAmplitude = 0.0
    @Volatile private var lastMicRoute = "MIC"
    @Volatile private var lastHpRoute = "HP --"
    private var lensIds: List<String?> = listOf(null)
    private var lensLabels: List<String> = listOf("AUTO")
    private var lensIndex = 0
    private var timelapseRunning = false
    private var timelapseIntervalMs = 2000L
    private var timelapseFrame = 0

    private lateinit var sensorManager: SensorManager
    private var rotationSensor: Sensor? = null

    @Volatile private var reporterName = "PULSE REPORTER"
    @Volatile private var headline = "CITIZEN REPORT"
    @Volatile private var placeName = "Location acquiring…"
    @Volatile private var latitude: Double? = null
    @Volatile private var longitude: Double? = null
    @Volatile private var altitude: Double? = null
    @Volatile private var accuracy: Float? = null
    @Volatile private var speedKmh: Float? = null
    @Volatile private var heading: Float? = null
    @Volatile private var temperatureC: Double? = null
    @Volatile private var humidityPct: Int? = null
    @Volatile private var windKmh: Double? = null
    @Volatile private var windDirection: Int? = null
    @Volatile private var weatherCondition = "Weather waiting"
    @Volatile private var recordedDurationNanos = 0L

    private lateinit var fusedLocation: FusedLocationProviderClient
    private lateinit var telemetryRecorder: TelemetrySessionRecorder
    private var telemetrySettings = TelemetryOverlaySettings.Settings()
    private var pendingFinalVideoName: String? = null
    private val io: ExecutorService = Executors.newFixedThreadPool(2)
    private val main = Handler(Looper.getMainLooper())
    private var lastReverseGeocodeAt = 0L
    private var lastWeatherAt = 0L

    private val hudTick = object : Runnable {
        override fun run() {
            refreshHud()
            main.postDelayed(this, 500L)
        }
    }

    private val timelapseTick = object : Runnable {
        override fun run() {
            if (!timelapseRunning) return
            takePhotoInternal("TL_${String.format(Locale.US, "%05d", timelapseFrame++)}", silent = true)
            main.postDelayed(this, timelapseIntervalMs)
        }
    }

    private val locationCallback = object : LocationCallback() {
        override fun onLocationResult(result: LocationResult) {
            val loc = result.lastLocation ?: return
            latitude = loc.latitude
            longitude = loc.longitude
            altitude = if (loc.hasAltitude()) loc.altitude else null
            accuracy = if (loc.hasAccuracy()) loc.accuracy else null
            speedKmh = if (loc.hasSpeed()) loc.speed * 3.6f else null
            heading = if (loc.hasBearing()) loc.bearing else null
            if (::miniMapView.isInitialized && telemetrySettings.map) {
                miniMapView.updateLocation(loc.latitude, loc.longitude, heading)
            }

            val now = System.currentTimeMillis()
            if (now - lastReverseGeocodeAt >= 15_000L) {
                lastReverseGeocodeAt = now
                reverseGeocode(loc.latitude, loc.longitude)
            }
            if (now - lastWeatherAt >= 10 * 60_000L || temperatureC == null) {
                lastWeatherAt = now
                refreshWeather(loc.latitude, loc.longitude)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        fusedLocation = LocationServices.getFusedLocationProviderClient(this)
        telemetryRecorder = TelemetrySessionRecorder(this)
        telemetrySettings = TelemetryOverlaySettings.load(this)
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        rotationSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        hevcHardware = detectHevcHardwareEncoder()
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        buildUi()
        requestPermissionsThenStart()
        main.post(hudTick)
    }

    private fun buildUi() {
        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }

        previewView = PreviewView(this).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
        root.addView(previewView, FrameLayout.LayoutParams(-1, -1))

        monitorOverlay = ProMonitorOverlayView(this).apply {
            isClickable = false
            isFocusable = false
        }
        root.addView(monitorOverlay, FrameLayout.LayoutParams(-1, -1))

        miniMapView = MiniMapView(this).apply {
            visibility = if (telemetrySettings.map) View.VISIBLE else View.GONE
            alpha = 0.94f
        }
        root.addView(miniMapView, FrameLayout.LayoutParams(dp(168), dp(168), Gravity.START or Gravity.BOTTOM).apply {
            leftMargin = dp(8); bottomMargin = dp(186)
        })

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setBackgroundColor(0xB8000000.toInt())
        }
        val brandRow = horizontal()
        brandRow.addView(label("PULSE", 18f, 0xFFFFD54A.toInt(), true), weight())
        statusText = label("CAMERA STARTING", 10f, 0xFF8FE8FF.toInt(), true).apply { gravity = Gravity.END }
        brandRow.addView(statusText, weight())
        top.addView(brandRow)

        headlineText = label(headline, 15f, Color.WHITE, true)
        top.addView(headlineText)
        timeText = label("TC 00:00:00 • --", 10f, 0xFFCCD8DC.toInt(), false)
        locationText = label("GPS waiting", 9f, 0xFFB8F1FF.toInt(), false)
        weatherText = label("WX waiting", 9f, 0xFFCCD8DC.toInt(), false)
        deviceText = label("MIC -- • BAT -- • FREE -- • NET --", 8.5f, 0xFF9DAEB4.toInt(), false)
        proStatusText = label("PRO AUTO • UHD • 30FPS • SDR", 8.5f, 0xFFFFD54A.toInt(), true)
        top.addView(timeText)
        top.addView(locationText)
        top.addView(weatherText)
        top.addView(deviceText)
        top.addView(proStatusText)
        root.addView(top, FrameLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP))

        val rightRail = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        reportButton = smallButton("REPORT")
        proButton = smallButton("PRO")
        lensButton = smallButton("LENS")
        photoButton = smallButton("PHOTO")
        liveButton = smallButton("LIVE")
        telemetryButton = smallButton("DATA")
        switchButton = smallButton("FLIP")
        torchButton = smallButton("TORCH")
        rightRail.addView(reportButton)
        rightRail.addView(space(6))
        rightRail.addView(proButton)
        rightRail.addView(space(6))
        rightRail.addView(lensButton)
        rightRail.addView(space(6))
        rightRail.addView(photoButton)
        rightRail.addView(space(6))
        rightRail.addView(liveButton)
        rightRail.addView(space(6))
        rightRail.addView(telemetryButton)
        rightRail.addView(space(6))
        rightRail.addView(switchButton)
        rightRail.addView(space(6))
        rightRail.addView(torchButton)
        root.addView(rightRail, FrameLayout.LayoutParams(dp(82), ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.END or Gravity.CENTER_VERTICAL).apply {
            marginEnd = dp(8)
        })

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(12))
            setBackgroundColor(0xD9000000.toInt())
        }

        val zoomRow = horizontal()
        zoomRow.addView(label("ZOOM", 9f, Color.WHITE, true), LinearLayout.LayoutParams(dp(64), dp(38)))
        zoomSeek = SeekBar(this).apply { max = 100; progress = 0 }
        zoomRow.addView(zoomSeek, LinearLayout.LayoutParams(0, dp(38), 1f))
        bottom.addView(zoomRow)

        val exposureRow = horizontal()
        exposureRow.addView(label("EXPOSURE", 9f, Color.WHITE, true), LinearLayout.LayoutParams(dp(72), dp(38)))
        exposureSeek = SeekBar(this).apply { max = 12; progress = 6 }
        exposureRow.addView(exposureSeek, LinearLayout.LayoutParams(0, dp(38), 1f))
        bottom.addView(exposureRow)

        val recordRow = horizontal().apply { gravity = Gravity.CENTER }
        recordButton = Button(this).apply {
            text = "●  RECORD"
            textSize = 17f
            setTextColor(Color.WHITE)
            isAllCaps = false
            background = rounded(0xFFE53935.toInt(), 28f)
            minHeight = 0
            minWidth = 0
        }
        recordRow.addView(recordButton, LinearLayout.LayoutParams(dp(190), dp(58)))
        bottom.addView(recordRow)
        root.addView(bottom, FrameLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))

        setContentView(root)

        recordButton.setOnClickListener { toggleRecording() }
        switchButton.setOnClickListener {
            if (recording != null) {
                toast("Stop recording before switching camera")
            } else {
                frontCamera = !frontCamera
                bindCamera()
            }
        }
        torchButton.setOnClickListener { toggleTorch() }
        reportButton.setOnClickListener { editReportInfo() }
        proButton.setOnClickListener { showProPanel() }
        lensButton.setOnClickListener { cycleLens() }
        photoButton.setOnClickListener { takePhotoInternal("PHOTO") }
        liveButton.setOnClickListener {
            if (recording != null) toast("Stop camera recording before entering LIVE")
            else startActivity(Intent(this, LiveActivity::class.java))
        }
        telemetryButton.setOnClickListener {
            TelemetryOverlaySettings.show(this) { settings ->
                telemetrySettings = settings
                miniMapView.visibility = if (settings.map) View.VISIBLE else View.GONE
                if (settings.map && latitude != null && longitude != null) miniMapView.updateLocation(latitude!!, longitude!!, heading)
                statusText.text = "PHASE 4 • DATA OVERLAY UPDATED"
            }
        }
        photoButton.setOnLongClickListener { takeBurst(5); true }
        zoomSeek.setOnSeekBarChangeListener(seekListener { value ->
            camera?.cameraControl?.setLinearZoom(value / 100f)
        })
        exposureSeek.setOnSeekBarChangeListener(seekListener { value ->
            val c = camera ?: return@seekListener
            val range = c.cameraInfo.exposureState.exposureCompensationRange
            if (range.lower <= range.upper) {
                val index = range.lower + ((range.upper - range.lower) * (value / 100f)).roundToInt()
                c.cameraControl.setExposureCompensationIndex(index.coerceIn(range.lower, range.upper))
            }
        })
    }

    private fun requestPermissionsThenStart() {
        val permissions = arrayOf(
            Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.ACCESS_FINE_LOCATION
        )
        val missing = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) {
            startServices()
        } else {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), 1001)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1001) startServices()
    }

    private fun startServices() {
        if (hasPermission(Manifest.permission.CAMERA)) startCamera()
        else statusText.text = "CAMERA PERMISSION NEEDED"
        if (hasPermission(Manifest.permission.ACCESS_FINE_LOCATION) || hasPermission(Manifest.permission.ACCESS_COARSE_LOCATION)) {
            startLocation()
        }
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                provider = future.get()
                bindCamera()
            } catch (t: Throwable) {
                statusText.text = "CAMERA ERROR"
                toast("Camera could not start: ${t.message ?: "unknown error"}")
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun bindCamera() {
        val p = provider ?: return
        p.unbindAll()
        overlayEffect?.close()
        overlayEffect = null
        burnInActive = false
        torchOn = false

        discoverLensOptions()
        val selector = activeCameraSelector()
        val cameraInfo = try { p.getCameraInfo(selector) } catch (_: Throwable) {
            if (frontCamera) p.getCameraInfo(CameraSelector.DEFAULT_FRONT_CAMERA)
            else p.getCameraInfo(CameraSelector.DEFAULT_BACK_CAMERA)
        }
        updateCapabilities(cameraInfo)

        // Keep the profile label truthful. Phase 2 only applies quality/FPS combinations that
        // CameraX reports for this active lens; unsupported requests degrade without blocking Phase 1.
        if (selectedQuality == Quality.UHD && !uhdSupported) {
            selectedQuality = Quality.FHD
            statusText.text = "4K UNSUPPORTED • USING 1080P"
        }
        val reportedFps = cameraInfo.supportedFrameRateRanges
        if (reportedFps.isNotEmpty() && reportedFps.none { targetFps in it }) {
            targetFps = 30
            statusText.text = "FPS UNSUPPORTED • USING 30FPS"
        }

        val preview = Preview.Builder().build().also {
            it.setSurfaceProvider(previewView.surfaceProvider)
        }

        val qualitySelector = QualitySelector.from(
            selectedQuality,
            FallbackStrategy.lowerQualityOrHigherThan(Quality.HD)
        )
        val recorder = Recorder.Builder()
            .setQualitySelector(qualitySelector)
            .build()
        val captureBuilder = VideoCapture.Builder(recorder)
            .setVideoStabilizationEnabled(videoStabilization)
        val supportedFps = cameraInfo.supportedFrameRateRanges
        if (supportedFps.any { targetFps in it }) {
            captureBuilder.setTargetFrameRate(Range(targetFps, targetFps))
        }
        val capture = captureBuilder.build()
        videoCapture = capture

        val photoCapture = ImageCapture.Builder()
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
            .setOutputFormat(ImageCapture.OUTPUT_FORMAT_JPEG)
            .build()
        imageCapture = photoCapture

        val analysis = ImageAnalysis.Builder()
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            .build()
        analysis.setAnalyzer(io, LumaFrameAnalyzer(monitorOverlay))
        imageAnalysis = analysis

        val effect = OverlayEffect(
            CameraEffect.PREVIEW or CameraEffect.VIDEO_CAPTURE,
            0,
            Handler(Looper.getMainLooper())
        ) { error ->
            main.post {
                statusText.text = "CAMERA • OVERLAY WARNING"
                toast("News overlay warning: ${error.message ?: "device limitation"}")
            }
        }
        effect.setOnDrawListener { frame ->
            drawBurnIn(frame.overlayCanvas, frame.size.width.toFloat(), frame.size.height.toFloat())
            true
        }

        val fullUseCases = arrayOf(preview, capture, photoCapture, analysis)
        var bound = false
        try {
            val session = SessionConfig.Builder(*fullUseCases)
                .addEffect(effect)
                .build()
            camera = p.bindToLifecycle(this, selector, session)
            overlayEffect = effect
            burnInActive = true
            bound = true
            statusText.text = "READY • PHASE 4 PRO • BURN-IN + DATA"
        } catch (_: Throwable) {
            effect.close()
            try {
                val plainSession = SessionConfig.Builder(*fullUseCases).build()
                camera = p.bindToLifecycle(this, selector, plainSession)
                burnInActive = false
                bound = true
                statusText.text = "READY • PHASE 4 PRO • BURN-IN UNSUPPORTED"
            } catch (_: Throwable) {
                // Some phones cannot sustain Preview + Video + ImageCapture + Analysis together.
                // Preserve every Phase 1 function first, then keep as many Phase 2 tools as possible.
                try {
                    val coreEffect = OverlayEffect(
                        CameraEffect.PREVIEW or CameraEffect.VIDEO_CAPTURE,
                        0,
                        Handler(Looper.getMainLooper())
                    ) { }
                    coreEffect.setOnDrawListener { frame ->
                        drawBurnIn(frame.overlayCanvas, frame.size.width.toFloat(), frame.size.height.toFloat())
                        true
                    }
                    val coreSession = SessionConfig.Builder(preview, capture).addEffect(coreEffect).build()
                    camera = p.bindToLifecycle(this, selector, coreSession)
                    overlayEffect = coreEffect
                    burnInActive = true
                    imageCapture = null
                    imageAnalysis = null
                    bound = true
                    statusText.text = "READY • CORE PRO • LIMITED MONITORS"
                } catch (t: Throwable) {
                    try {
                        val corePlain = SessionConfig.Builder(preview, capture).build()
                        camera = p.bindToLifecycle(this, selector, corePlain)
                        burnInActive = false
                        imageCapture = null
                        imageAnalysis = null
                        bound = true
                        statusText.text = "READY • PHASE 1 CORE FALLBACK"
                    } catch (finalError: Throwable) {
                        if (selectedQuality != Quality.FHD || targetFps != 30 || videoStabilization) {
                            selectedQuality = Quality.FHD
                            targetFps = 30
                            videoStabilization = false
                            statusText.text = "PROFILE UNSUPPORTED • FALLING BACK TO 1080P30"
                            toast("That quality/FPS/stabilization combination is not supported. Using 1080p30.")
                            main.postDelayed({ bindCamera() }, 150L)
                            return
                        }
                        statusText.text = "CAMERA BIND ERROR"
                        toast("Camera bind failed: ${finalError.message ?: t.message ?: "unknown error"}")
                        return
                    }
                }
            }
        }

        if (bound) {
            syncExposureControl()
            applyProCaptureOptions(showError = false)
            refreshProStatus()
        }
    }

    private fun discoverLensOptions() {
        val p = provider ?: return
        if (frontCamera) {
            lensIds = listOf(null)
            lensLabels = listOf("FRONT")
            lensIndex = 0
            lensButton.text = "FRONT"
            return
        }
        try {
            val logical = p.getCameraInfo(CameraSelector.DEFAULT_BACK_CAMERA)
            val physical = logical.physicalCameraInfos.toList()
            if (physical.isEmpty()) {
                lensIds = listOf(null)
                lensLabels = listOf("AUTO")
                lensIndex = 0
            } else {
                val entries = physical.mapNotNull { info ->
                    try {
                        val c2 = Camera2CameraInfo.from(info)
                        val focal = c2.getCameraCharacteristic(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)
                            ?.firstOrNull() ?: 0f
                        c2.cameraId to focal
                    } catch (_: Throwable) { null }
                }.distinctBy { it.first }.sortedBy { it.second }
                val minFocal = entries.minOfOrNull { it.second.takeIf { f -> f > 0f } ?: Float.MAX_VALUE }
                    ?.takeIf { it != Float.MAX_VALUE } ?: 1f
                val ids = mutableListOf<String?>(null)
                val labels = mutableListOf("AUTO")
                entries.forEach { (id, focal) ->
                    ids.add(id)
                    labels.add(if (focal > 0f) String.format(Locale.US, "%.1fx", focal / minFocal) else "LENS")
                }
                lensIds = ids
                lensLabels = labels
                lensIndex = lensIndex.coerceIn(0, lensIds.lastIndex)
            }
            lensButton.text = lensLabels.getOrElse(lensIndex) { "LENS" }
        } catch (_: Throwable) {
            lensIds = listOf(null)
            lensLabels = listOf("AUTO")
            lensIndex = 0
            lensButton.text = "LENS"
        }
    }

    private fun activeCameraSelector(): CameraSelector {
        if (frontCamera) return CameraSelector.DEFAULT_FRONT_CAMERA
        val physicalId = lensIds.getOrNull(lensIndex)
        return if (physicalId.isNullOrBlank()) CameraSelector.DEFAULT_BACK_CAMERA
        else CameraSelector.Builder()
            .requireLensFacing(CameraSelector.LENS_FACING_BACK)
            .setPhysicalCameraId(physicalId)
            .build()
    }

    private fun cycleLens() {
        if (recording != null || timelapseRunning) {
            toast("Stop recording or timelapse before changing lens")
            return
        }
        discoverLensOptions()
        if (lensIds.size <= 1) {
            toast("No separate physical lenses were exposed to CameraX")
            return
        }
        lensIndex = (lensIndex + 1) % lensIds.size
        lensButton.text = lensLabels.getOrElse(lensIndex) { "LENS" }
        bindCamera()
    }

    private fun updateCapabilities(info: androidx.camera.core.CameraInfo) {
        try {
            val c2 = Camera2CameraInfo.from(info)
            val caps = c2.getCameraCharacteristic(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES) ?: intArrayOf()
            manualSensorSupported = caps.contains(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_SENSOR)
            rawSupported = caps.contains(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_RAW) &&
                ImageCapture.getImageCaptureCapabilities(info).supportedOutputFormats.contains(ImageCapture.OUTPUT_FORMAT_RAW)
            isoRange = c2.getCameraCharacteristic(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)
            exposureTimeRange = c2.getCameraCharacteristic(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)
            minFocusDistance = c2.getCameraCharacteristic(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f
            val oisModes = c2.getCameraCharacteristic(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION) ?: intArrayOf()
            oisSupported = oisModes.contains(CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_ON)
            val eisModes = c2.getCameraCharacteristic(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES) ?: intArrayOf()
            eisSupported = eisModes.contains(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_ON)
            val map = c2.getCameraCharacteristic(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
            highSpeedMaxFps = try {
                map?.highSpeedVideoSizes
                    ?.flatMap { size -> map.getHighSpeedVideoFpsRangesFor(size).toList() }
                    ?.maxOfOrNull { it.upper } ?: 60
            } catch (_: Throwable) { 60 }
        } catch (_: Throwable) {
            manualSensorSupported = false
            rawSupported = false
            oisSupported = false
            eisSupported = false
            highSpeedMaxFps = 60
        }

        try {
            val caps = Recorder.getVideoCapabilities(info)
            val ranges = caps.supportedDynamicRanges
            hdr10BitSupported = ranges.any { it.bitDepth == DynamicRange.BIT_DEPTH_10_BIT && it != DynamicRange.SDR }
            uhdSupported = caps.isQualitySupported(Quality.UHD, DynamicRange.SDR)
        } catch (_: Throwable) {
            hdr10BitSupported = false
            uhdSupported = QualitySelector.isQualitySupported(info, Quality.UHD)
        }
        lowLightSupported = try { info.isLowLightBoostSupported } catch (_: Throwable) { false }

        isoRange?.let { isoValue = isoValue.coerceIn(it.lower, it.upper) }
        if (!manualSensorSupported) manualMode = false
        if (!oisSupported) oisEnabled = false
        if (!eisSupported) videoStabilization = false
    }

    private fun applyProCaptureOptions(showError: Boolean = true) {
        val c = camera ?: return
        try {
            val options = CaptureRequestOptions.Builder()
            if (manualMode && manualSensorSupported) {
                options.setCaptureRequestOption(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
                options.setCaptureRequestOption(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_OFF)
                options.setCaptureRequestOption(CaptureRequest.CONTROL_AWB_MODE, CaptureRequest.CONTROL_AWB_MODE_OFF)
                isoRange?.let {
                    options.setCaptureRequestOption(CaptureRequest.SENSOR_SENSITIVITY, isoValue.coerceIn(it.lower, it.upper))
                }
                exposureTimeRange?.let {
                    val desired = shutterAngleToExposureNs(shutterAngle, targetFps).coerceIn(it.lower, it.upper)
                    options.setCaptureRequestOption(CaptureRequest.SENSOR_EXPOSURE_TIME, desired)
                }
                if (minFocusDistance > 0f) {
                    val diopters = minFocusDistance * (focusPercent.coerceIn(0, 100) / 100f)
                    options.setCaptureRequestOption(CaptureRequest.LENS_FOCUS_DISTANCE, diopters)
                }
                val gains = kelvinToGains(wbKelvin, wbTint)
                options.setCaptureRequestOption(CaptureRequest.COLOR_CORRECTION_MODE, CaptureRequest.COLOR_CORRECTION_MODE_TRANSFORM_MATRIX)
                options.setCaptureRequestOption(CaptureRequest.COLOR_CORRECTION_GAINS, gains)
            } else {
                options.setCaptureRequestOption(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
                options.setCaptureRequestOption(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO)
                options.setCaptureRequestOption(CaptureRequest.CONTROL_AWB_MODE, CaptureRequest.CONTROL_AWB_MODE_AUTO)
                options.setCaptureRequestOption(CaptureRequest.CONTROL_AE_LOCK, aeLock)
            }
            if (oisSupported) {
                options.setCaptureRequestOption(
                    CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE,
                    if (oisEnabled) CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_ON
                    else CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_OFF
                )
            }
            Camera2CameraControl.from(c.cameraControl)
                .setCaptureRequestOptions(options.build())
                .addListener({ main.post { refreshProStatus() } }, ContextCompat.getMainExecutor(this))
        } catch (t: Throwable) {
            if (showError) toast("Manual control not accepted by this lens: ${t.message ?: "device limit"}")
        }
    }

    private fun shutterAngleToExposureNs(angle: Int, fps: Int): Long {
        val safeFps = fps.coerceAtLeast(1)
        val seconds = (angle.coerceIn(1, 360) / 360.0) / safeFps
        return (seconds * 1_000_000_000.0).toLong().coerceAtLeast(1L)
    }

    private fun kelvinToGains(kelvin: Int, tint: Int): RggbChannelVector {
        val temp = (kelvin.coerceIn(2000, 10000) / 100.0)
        val red255 = if (temp <= 66.0) 255.0 else 329.698727446 * (temp - 60.0).pow(-0.1332047592)
        val green255 = if (temp <= 66.0) 99.4708025861 * ln(temp) - 161.1195681661
            else 288.1221695283 * (temp - 60.0).pow(-0.0755148492)
        val blue255 = when {
            temp >= 66.0 -> 255.0
            temp <= 19.0 -> 0.0
            else -> 138.5177312231 * ln(temp - 10.0) - 305.0447927307
        }
        val r = red255.coerceIn(1.0, 255.0)
        val g = green255.coerceIn(1.0, 255.0)
        val b = blue255.coerceIn(1.0, 255.0)
        val base = g
        val tintScale = (1.0 + tint.coerceIn(-50, 50) / 250.0).coerceIn(0.8, 1.2)
        val redGain = (r / base).coerceIn(0.5, 4.0).toFloat()
        val blueGain = (b / base).coerceIn(0.5, 4.0).toFloat()
        val greenGain = (1.0 / tintScale).coerceIn(0.5, 4.0).toFloat()
        return RggbChannelVector(redGain, greenGain, greenGain, blueGain)
    }

    private fun refreshProStatus() {
        if (!::proStatusText.isInitialized) return
        val mode = if (manualMode) "MANUAL" else "AUTO"
        val quality = when (selectedQuality) {
            Quality.UHD -> "UHD/4K"
            Quality.FHD -> "FHD"
            Quality.HD -> "HD"
            else -> "VIDEO"
        }
        val hdr = if (hdr10BitSupported) "HDR10 CAP" else "SDR"
        val codec = if (hevcHardware) "HEVC CAP" else "H264"
        val stab = if (videoStabilization) "EIS ON" else if (oisEnabled) "OIS ON" else "STAB OFF"
        proStatusText.text = "$mode • $quality • ${targetFps}FPS • $hdr • $codec • $stab"
    }

    private fun syncExposureControl() {
        val c = camera ?: return
        val state = c.cameraInfo.exposureState
        exposureSeek.isEnabled = state.isExposureCompensationSupported && !manualMode
        exposureSeek.max = 100
        if (state.isExposureCompensationSupported) {
            val range = state.exposureCompensationRange
            val fraction = if (range.upper == range.lower) 0.5f
            else (state.exposureCompensationIndex - range.lower).toFloat() / (range.upper - range.lower).toFloat()
            exposureSeek.progress = (fraction * 100f).roundToInt().coerceIn(0, 100)
        }
    }

    private fun toggleRecording() {
        if (timelapseRunning) {
            toast("Stop timelapse before video recording")
            return
        }
        val current = recording
        if (current != null) {
            current.stop()
            return
        }

        val capture = videoCapture ?: run {
            toast("Camera is not ready")
            return
        }

        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        pendingFinalVideoName = "PULSE_$stamp.mp4"
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "PULSE_${stamp}_RAW.mp4")
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/PULSE")
        }
        val output = MediaStoreOutputOptions.Builder(
            contentResolver,
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        ).setContentValues(values).build()

        var pending: PendingRecording = capture.output.prepareRecording(this, output)
        if (hasPermission(Manifest.permission.RECORD_AUDIO)) {
            pending = pending.withAudioEnabled()
        }

        recordedDurationNanos = 0L
        recording = pending.start(ContextCompat.getMainExecutor(this)) { event ->
            when (event) {
                is VideoRecordEvent.Start -> {
                    telemetryRecorder.start("CAMERA") { elapsedUs -> telemetrySnapshot(elapsedUs, "CAMERA", null) }
                    recordButton.text = "■  STOP"
                    recordButton.background = rounded(0xFFB71C1C.toInt(), 28f)
                    statusText.text = if (burnInActive) "● REC • BURN-IN ON" else "● REC • NO BURN-IN"
                }
                is VideoRecordEvent.Status -> {
                    recordedDurationNanos = event.recordingStats.recordedDurationNanos
                    val amp = event.recordingStats.audioStats.audioAmplitude
                    lastAudioAmplitude = amp
                    lastAudioDb = if (amp > 0.000001) (20.0 * ln(amp) / ln(10.0)).coerceAtLeast(-90.0) else -90.0
                }
                is VideoRecordEvent.Finalize -> {
                    recordedDurationNanos = event.recordingStats.recordedDurationNanos
                    recording = null
                    recordButton.text = "●  RECORD"
                    recordButton.background = rounded(0xFFE53935.toInt(), 28f)
                    val telemetry = telemetryRecorder.stop()
                    if (event.hasError()) {
                        statusText.text = "RECORD ERROR • RAW PRESERVED"
                        toast("Recording failed: ${event.cause?.message ?: "code ${event.error}"}")
                    } else {
                        val sourceUri = event.outputResults.outputUri
                        val finalName = pendingFinalVideoName ?: "PULSE_${System.currentTimeMillis()}.mp4"
                        statusText.text = "FINALIZING • EMBEDDING DATA TRACK"
                        io.execute {
                            val result = TelemetryMp4Muxer.embedMediaStoreSource(this, sourceUri, telemetry.samples, finalName)
                            main.post {
                                if (result.success) {
                                    statusText.text = if (burnInActive) "SAVED • BURN-IN + TIMED DATA" else "SAVED • TIMED DATA"
                                    toast("Saved to Gallery → Movies/PULSE with editable timed telemetry")
                                } else {
                                    TelemetryMp4Muxer.publishSidecarOnly(this, telemetry.samples, finalName.removeSuffix(".mp4") + ".telemetry.jsonl")
                                    statusText.text = "SAVED RAW • DATA SIDECAR KEPT"
                                    toast("Video preserved; timed metadata could not be embedded: ${result.message}")
                                }
                            }
                        }
                    }
                    pendingFinalVideoName = null
                }
            }
        }
    }

    private fun toggleTorch() {
        val c = camera ?: return
        if (!c.cameraInfo.hasFlashUnit()) {
            toast("Torch is not available on this camera")
            return
        }
        torchOn = !torchOn
        c.cameraControl.enableTorch(torchOn)
        torchButton.text = if (torchOn) "TORCH ON" else "TORCH"
    }

    private fun showProPanel() {
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(8), dp(18), dp(18))
        }
        scroll.addView(box)

        val capability = label(
            buildString {
                append("CAMERA CAPABILITIES\n")
                append(if (manualSensorSupported) "Manual sensor ✓" else "Manual sensor —")
                append("  • RAW ").append(if (rawSupported) "✓" else "—")
                append("  • 4K ").append(if (uhdSupported) "✓" else "—")
                append("\n10-bit HDR ").append(if (hdr10BitSupported) "✓" else "—")
                append("  • HEVC HW ").append(if (hevcHardware) "✓" else "—")
                append("  • HS max ${highSpeedMaxFps}fps")
                append("\nOIS ").append(if (oisSupported) "✓" else "—")
                append("  • EIS ").append(if (eisSupported) "✓" else "—")
                append("  • RAW photo ").append(if (rawSupported) "DNG" else "unavailable")
            },
            11f, 0xFFB8F1FF.toInt(), false
        )
        box.addView(capability)
        box.addView(space(10))

        val modeButton = panelButton(if (manualMode) "MANUAL SENSOR: ON" else "MANUAL SENSOR: OFF")
        modeButton.isEnabled = manualSensorSupported
        modeButton.setOnClickListener {
            manualMode = !manualMode
            modeButton.text = if (manualMode) "MANUAL SENSOR: ON" else "MANUAL SENSOR: OFF"
            syncExposureControl()
            applyProCaptureOptions()
        }
        box.addView(modeButton)

        val isoLabel = label("ISO $isoValue", 11f, Color.WHITE, true)
        val isoSeek = SeekBar(this).apply { max = 100 }
        isoRange?.let { r ->
            isoSeek.progress = if (r.upper == r.lower) 0 else (((isoValue - r.lower) * 100f) / (r.upper - r.lower)).roundToInt().coerceIn(0, 100)
        }
        isoSeek.isEnabled = manualSensorSupported
        isoSeek.setOnSeekBarChangeListener(seekListener { p ->
            val r = isoRange ?: return@seekListener
            isoValue = (r.lower + (r.upper - r.lower) * (p / 100f)).roundToInt().coerceIn(r.lower, r.upper)
            isoLabel.text = "ISO $isoValue"
            if (manualMode) applyProCaptureOptions(showError = false)
        })
        box.addView(isoLabel); box.addView(isoSeek)

        val shutterLabel = label("SHUTTER ${shutterAngle}°", 11f, Color.WHITE, true)
        val shutterSeek = SeekBar(this).apply { max = 359; progress = (shutterAngle - 1).coerceIn(0, 359) }
        shutterSeek.isEnabled = manualSensorSupported
        shutterSeek.setOnSeekBarChangeListener(seekListener { p ->
            shutterAngle = p + 1
            val ns = shutterAngleToExposureNs(shutterAngle, targetFps)
            val denom = if (ns > 0) (1_000_000_000.0 / ns).roundToInt() else 0
            shutterLabel.text = "SHUTTER ${shutterAngle}°  ≈ 1/${denom.coerceAtLeast(1)}s"
            if (manualMode) applyProCaptureOptions(showError = false)
        })
        box.addView(shutterLabel); box.addView(shutterSeek)

        val wbLabel = label("WB ${wbKelvin}K", 11f, Color.WHITE, true)
        val wbSeek = SeekBar(this).apply { max = 8000; progress = (wbKelvin - 2000).coerceIn(0, 8000) }
        wbSeek.isEnabled = manualSensorSupported
        wbSeek.setOnSeekBarChangeListener(seekListener { p ->
            wbKelvin = 2000 + p
            wbLabel.text = "WB ${wbKelvin}K"
            if (manualMode) applyProCaptureOptions(showError = false)
        })
        box.addView(wbLabel); box.addView(wbSeek)

        val tintLabel = label("TINT ${if (wbTint >= 0) "+" else ""}$wbTint", 11f, Color.WHITE, true)
        val tintSeek = SeekBar(this).apply { max = 100; progress = wbTint + 50 }
        tintSeek.isEnabled = manualSensorSupported
        tintSeek.setOnSeekBarChangeListener(seekListener { p ->
            wbTint = p - 50
            tintLabel.text = "TINT ${if (wbTint >= 0) "+" else ""}$wbTint"
            if (manualMode) applyProCaptureOptions(showError = false)
        })
        box.addView(tintLabel); box.addView(tintSeek)

        val focusLabel = label("FOCUS ${focusPercent}%  (0 = ∞)", 11f, Color.WHITE, true)
        val focusSeek = SeekBar(this).apply { max = 100; progress = focusPercent }
        focusSeek.isEnabled = manualSensorSupported && minFocusDistance > 0f
        focusSeek.setOnSeekBarChangeListener(seekListener { p ->
            focusPercent = p
            focusLabel.text = "FOCUS ${focusPercent}%  (0 = ∞)"
            if (manualMode) applyProCaptureOptions(showError = false)
        })
        box.addView(focusLabel); box.addView(focusSeek)

        val lock = panelButton(if (aeLock) "AE LOCK: ON" else "AE LOCK: OFF")
        lock.setOnClickListener {
            aeLock = !aeLock
            lock.text = if (aeLock) "AE LOCK: ON" else "AE LOCK: OFF"
            if (!manualMode) applyProCaptureOptions()
        }
        box.addView(lock)

        val ois = panelButton(if (oisEnabled) "OPTICAL STABILIZATION: ON" else "OPTICAL STABILIZATION: OFF")
        ois.isEnabled = oisSupported
        ois.setOnClickListener {
            oisEnabled = !oisEnabled
            ois.text = if (oisEnabled) "OPTICAL STABILIZATION: ON" else "OPTICAL STABILIZATION: OFF"
            applyProCaptureOptions()
        }
        box.addView(ois)

        val eis = panelButton(if (videoStabilization) "VIDEO STABILIZATION: ON" else "VIDEO STABILIZATION: OFF")
        eis.isEnabled = eisSupported
        eis.setOnClickListener {
            if (recording != null) { toast("Stop recording before changing stabilization"); return@setOnClickListener }
            videoStabilization = !videoStabilization
            eis.text = if (videoStabilization) "VIDEO STABILIZATION: ON" else "VIDEO STABILIZATION: OFF"
            bindCamera()
        }
        box.addView(eis)

        val lowLight = panelButton(if (lowLightBoost) "NIGHT / LOW LIGHT BOOST: ON" else "NIGHT / LOW LIGHT BOOST: OFF")
        lowLight.isEnabled = lowLightSupported
        lowLight.setOnClickListener {
            toggleLowLightBoost()
            main.postDelayed({ lowLight.text = if (lowLightBoost) "NIGHT / LOW LIGHT BOOST: ON" else "NIGHT / LOW LIGHT BOOST: OFF" }, 250)
        }
        box.addView(lowLight)

        val profile = panelButton("RECORD PROFILE: ${qualityName(selectedQuality)} • ${targetFps}FPS")
        profile.setOnClickListener { showProfileChooser(profile) }
        box.addView(profile)

        box.addView(label("MONITORING", 12f, 0xFFFFD54A.toInt(), true))
        val zebra = panelButton(toggleTitle("ZEBRA", monitorOverlay.zebraEnabled))
        zebra.setOnClickListener { monitorOverlay.zebraEnabled = !monitorOverlay.zebraEnabled; zebra.text = toggleTitle("ZEBRA", monitorOverlay.zebraEnabled) }
        box.addView(zebra)
        val peaking = panelButton(toggleTitle("FOCUS PEAKING", monitorOverlay.peakingEnabled))
        peaking.setOnClickListener { monitorOverlay.peakingEnabled = !monitorOverlay.peakingEnabled; peaking.text = toggleTitle("FOCUS PEAKING", monitorOverlay.peakingEnabled) }
        box.addView(peaking)
        val falseColor = panelButton(toggleTitle("FALSE COLOR", monitorOverlay.falseColorEnabled))
        falseColor.setOnClickListener { monitorOverlay.falseColorEnabled = !monitorOverlay.falseColorEnabled; falseColor.text = toggleTitle("FALSE COLOR", monitorOverlay.falseColorEnabled) }
        box.addView(falseColor)
        val hist = panelButton(toggleTitle("HISTOGRAM", monitorOverlay.histogramEnabled))
        hist.setOnClickListener { monitorOverlay.histogramEnabled = !monitorOverlay.histogramEnabled; hist.text = toggleTitle("HISTOGRAM", monitorOverlay.histogramEnabled) }
        box.addView(hist)
        val wave = panelButton(toggleTitle("WAVEFORM", monitorOverlay.waveformEnabled))
        wave.setOnClickListener { monitorOverlay.waveformEnabled = !monitorOverlay.waveformEnabled; wave.text = toggleTitle("WAVEFORM", monitorOverlay.waveformEnabled) }
        box.addView(wave)
        val grid = panelButton(toggleTitle("GRID", monitorOverlay.gridEnabled))
        grid.setOnClickListener { monitorOverlay.gridEnabled = !monitorOverlay.gridEnabled; grid.text = toggleTitle("GRID", monitorOverlay.gridEnabled); monitorOverlay.invalidate() }
        box.addView(grid)
        val level = panelButton(toggleTitle("HORIZON LEVEL", monitorOverlay.horizonEnabled))
        level.setOnClickListener { monitorOverlay.horizonEnabled = !monitorOverlay.horizonEnabled; level.text = toggleTitle("HORIZON LEVEL", monitorOverlay.horizonEnabled); monitorOverlay.invalidate() }
        box.addView(level)

        val raw = panelButton("CAPTURE RAW DNG")
        raw.isEnabled = rawSupported
        raw.setOnClickListener { captureRawPhoto() }
        box.addView(raw)

        val tl = panelButton(if (timelapseRunning) "STOP TIMELAPSE SEQUENCE" else "START TIMELAPSE SEQUENCE")
        tl.isEnabled = imageCapture != null
        tl.setOnClickListener {
            toggleTimelapse()
            tl.text = if (timelapseRunning) "STOP TIMELAPSE SEQUENCE" else "START TIMELAPSE SEQUENCE"
        }
        box.addView(tl)

        box.addView(label(
            "PHOTO button = JPEG • hold PHOTO = 5-frame burst. Timelapse saves a JPEG sequence for later assembly. " +
                "Monitoring overlays are preview tools and are not burned into the Phase 1 newsroom video overlay.",
            9f, 0xFF9DAEB4.toInt(), false
        ))

        AlertDialog.Builder(this)
            .setTitle("PULSE Phase 2 • Pro Camera")
            .setView(scroll)
            .setPositiveButton("Done", null)
            .show()
    }

    private fun panelButton(title: String): Button = Button(this).apply {
        text = title
        textSize = 11f
        setTextColor(Color.WHITE)
        isAllCaps = false
        background = rounded(0xCC151A1E.toInt(), 12f, 0x557A8A90)
        minHeight = dp(44)
    }

    private fun toggleTitle(name: String, on: Boolean) = "$name: ${if (on) "ON" else "OFF"}"

    private fun qualityName(q: Quality): String = when (q) {
        Quality.UHD -> "4K/UHD"
        Quality.FHD -> "1080P"
        Quality.HD -> "720P"
        Quality.SD -> "SD"
        else -> "AUTO"
    }

    private fun showProfileChooser(button: Button) {
        if (recording != null) { toast("Stop recording before changing profile"); return }
        val options = arrayOf(
            "4K/UHD • 24 FPS", "4K/UHD • 30 FPS", "4K/UHD • 60 FPS",
            "1080P • 24 FPS", "1080P • 30 FPS", "1080P • 60 FPS",
            "720P • 30 FPS", "720P • 60 FPS"
        )
        AlertDialog.Builder(this)
            .setTitle("Recording profile")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> { selectedQuality = Quality.UHD; targetFps = 24 }
                    1 -> { selectedQuality = Quality.UHD; targetFps = 30 }
                    2 -> { selectedQuality = Quality.UHD; targetFps = 60 }
                    3 -> { selectedQuality = Quality.FHD; targetFps = 24 }
                    4 -> { selectedQuality = Quality.FHD; targetFps = 30 }
                    5 -> { selectedQuality = Quality.FHD; targetFps = 60 }
                    6 -> { selectedQuality = Quality.HD; targetFps = 30 }
                    7 -> { selectedQuality = Quality.HD; targetFps = 60 }
                }
                if (selectedQuality == Quality.UHD && !uhdSupported) {
                    toast("4K/UHD is not exposed by this active lens. Using 1080p.")
                    selectedQuality = Quality.FHD
                }
                val fpsRanges = camera?.cameraInfo?.supportedFrameRateRanges.orEmpty()
                if (fpsRanges.isNotEmpty() && fpsRanges.none { targetFps in it }) {
                    toast("${targetFps} FPS is not exposed by this lens in the current CameraX session. Using 30 FPS.")
                    targetFps = 30
                }
                button.text = "RECORD PROFILE: ${qualityName(selectedQuality)} • ${targetFps}FPS"
                bindCamera()
            }
            .show()
    }

    private fun toggleLowLightBoost() {
        val c = camera ?: return
        if (!lowLightSupported) { toast("Low-light boost is not supported by this camera"); return }
        val desired = !lowLightBoost
        try {
            val future = c.cameraControl.enableLowLightBoostAsync(desired)
            future.addListener({
                try {
                    future.get()
                    lowLightBoost = desired
                    main.post { refreshProStatus() }
                } catch (t: Throwable) {
                    main.post { toast("Low-light boost unavailable in this current camera mode: ${t.message ?: "device limit"}") }
                }
            }, ContextCompat.getMainExecutor(this))
        } catch (t: Throwable) {
            toast("Low-light boost unavailable: ${t.message ?: "device limit"}")
        }
    }

    private fun takePhotoInternal(prefix: String, silent: Boolean = false) {
        if (recording != null) {
            if (!silent) toast("Stop video recording before taking a still photo")
            return
        }
        val capture = imageCapture ?: run {
            if (!silent) toast("Still-photo use case is unavailable in this camera combination")
            return
        }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(Date())
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "PULSE_${prefix}_$stamp.jpg")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/PULSE")
        }
        val output = ImageCapture.OutputFileOptions.Builder(
            contentResolver,
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            values
        ).build()
        capture.takePicture(output, ContextCompat.getMainExecutor(this), object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                if (!silent) toast("Photo saved to Gallery → Pictures/PULSE")
            }
            override fun onError(exception: ImageCaptureException) {
                if (!silent) toast("Photo failed: ${exception.message ?: "camera error"}")
            }
        })
    }

    private fun takeBurst(count: Int) {
        if (recording != null || timelapseRunning) { toast("Stop recording/timelapse before burst"); return }
        if (imageCapture == null) { toast("Burst unavailable in this camera combination"); return }
        toast("Burst: $count frames")
        repeat(count) { i ->
            main.postDelayed({ takePhotoInternal("BURST_${i + 1}", silent = true) }, i * 220L)
        }
    }

    private fun toggleTimelapse() {
        if (recording != null) { toast("Stop video recording before timelapse"); return }
        if (imageCapture == null) { toast("Timelapse still capture is unavailable in this camera combination"); return }
        timelapseRunning = !timelapseRunning
        if (timelapseRunning) {
            timelapseFrame = 0
            statusText.text = "TIMELAPSE • ${timelapseIntervalMs / 1000.0}s INTERVAL"
            main.removeCallbacks(timelapseTick)
            main.post(timelapseTick)
        } else {
            main.removeCallbacks(timelapseTick)
            statusText.text = "TIMELAPSE SAVED • JPEG SEQUENCE"
            toast("Timelapse sequence saved to Pictures/PULSE")
        }
    }

    private fun captureRawPhoto() {
        if (!rawSupported) { toast("RAW/DNG is not exposed by this camera"); return }
        if (recording != null || timelapseRunning) { toast("Stop recording/timelapse before RAW capture"); return }
        val p = provider ?: return
        val selector = activeCameraSelector()
        try {
            p.unbindAll()
            overlayEffect?.close()
            overlayEffect = null
            val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
            val raw = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                .setOutputFormat(ImageCapture.OUTPUT_FORMAT_RAW)
                .build()
            val session = SessionConfig.Builder(preview, raw).build()
            camera = p.bindToLifecycle(this, selector, session)

            val baseDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES) ?: filesDir
            val dir = File(baseDir, "PULSE_RAW").apply { mkdirs() }
            val file = File(dir, "PULSE_RAW_${SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(Date())}.dng")
            val output = ImageCapture.OutputFileOptions.Builder(file).build()
            raw.takePicture(output, ContextCompat.getMainExecutor(this), object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                    MediaScannerConnection.scanFile(this@MainActivity, arrayOf(file.absolutePath), arrayOf("image/x-adobe-dng"), null)
                    toast("RAW DNG captured")
                    main.postDelayed({ bindCamera() }, 300L)
                }
                override fun onError(exception: ImageCaptureException) {
                    toast("RAW capture failed: ${exception.message ?: "device limitation"}")
                    main.postDelayed({ bindCamera() }, 300L)
                }
            })
        } catch (t: Throwable) {
            toast("RAW session unavailable with this lens: ${t.message ?: "device limitation"}")
            main.postDelayed({ bindCamera() }, 250L)
        }
    }

    private fun detectHevcHardwareEncoder(): Boolean {
        return try {
            MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.any { info ->
                info.isEncoder && info.supportedTypes.any { it.equals("video/hevc", ignoreCase = true) } &&
                    if (Build.VERSION.SDK_INT >= 29) info.isHardwareAccelerated else true
            }
        } catch (_: Throwable) { false }
    }

    private fun audioRouteLabel(): String {
        return try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val inputs = am.getDevices(AudioManager.GET_DEVICES_INPUTS)
            val external = inputs.firstOrNull { d ->
                d.type == AudioDeviceInfo.TYPE_USB_DEVICE ||
                    d.type == AudioDeviceInfo.TYPE_USB_HEADSET ||
                    d.type == AudioDeviceInfo.TYPE_WIRED_HEADSET ||
                    d.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
                    (Build.VERSION.SDK_INT >= 31 && d.type == AudioDeviceInfo.TYPE_BLE_HEADSET)
            }
            if (external != null) "EXT INPUT" else "BUILT-IN MIC"
        } catch (_: Throwable) { "MIC" }
    }

    private fun headphoneRouteLabel(): String {
        return try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val outputs = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
            val hp = outputs.any { d ->
                d.type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES ||
                    d.type == AudioDeviceInfo.TYPE_WIRED_HEADSET ||
                    d.type == AudioDeviceInfo.TYPE_USB_HEADSET ||
                    d.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
                    (Build.VERSION.SDK_INT >= 31 && d.type == AudioDeviceInfo.TYPE_BLE_HEADSET)
            }
            if (hp) "HP PRESENT" else "NO HP"
        } catch (_: Throwable) { "HP --" }
    }

    private fun editReportInfo() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        val reporter = EditText(this).apply {
            hint = "Reporter / source"
            setText(reporterName)
            setSingleLine(true)
        }
        val title = EditText(this).apply {
            hint = "Headline"
            setText(headline)
            setSingleLine(true)
        }
        box.addView(reporter)
        box.addView(title)
        AlertDialog.Builder(this)
            .setTitle("PULSE report information")
            .setView(box)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Apply") { _, _ ->
                reporterName = reporter.text.toString().trim().ifBlank { "PULSE REPORTER" }.take(40)
                headline = title.text.toString().trim().ifBlank { "CITIZEN REPORT" }.take(70)
                headlineText.text = headline
            }
            .show()
    }

    private fun startLocation() {
        if (locationStarted) return
        if (!hasPermission(Manifest.permission.ACCESS_FINE_LOCATION) && !hasPermission(Manifest.permission.ACCESS_COARSE_LOCATION)) return
        val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 1000L)
            .setMinUpdateIntervalMillis(1000L)
            .setMaxUpdateDelayMillis(1000L)
            .build()
        try {
            fusedLocation.requestLocationUpdates(request, locationCallback, Looper.getMainLooper())
            locationStarted = true
        } catch (_: SecurityException) {
            locationStarted = false
        }
    }

    private fun reverseGeocode(lat: Double, lon: Double) {
        val geocoder = Geocoder(this, Locale.getDefault())
        if (Build.VERSION.SDK_INT >= 33) {
            geocoder.getFromLocation(lat, lon, 1, object : Geocoder.GeocodeListener {
                override fun onGeocode(addresses: MutableList<Address>) {
                    addresses.firstOrNull()?.let { applyAddress(it) }
                }
                override fun onError(errorMessage: String?) = Unit
            })
        } else {
            io.execute {
                try {
                    @Suppress("DEPRECATION")
                    geocoder.getFromLocation(lat, lon, 1)?.firstOrNull()?.let { applyAddress(it) }
                } catch (_: Throwable) { }
            }
        }
    }

    private fun applyAddress(a: Address) {
        val text = listOfNotNull(
            a.subLocality,
            a.locality,
            a.subAdminArea,
            a.adminArea,
            a.countryName
        ).filter { it.isNotBlank() }.distinct().joinToString(", ")
        if (text.isNotBlank()) placeName = text
    }

    private fun refreshWeather(lat: Double, lon: Double) {
        io.execute {
            try {
                val endpoint = "https://api.open-meteo.com/v1/forecast" +
                    "?latitude=$lat&longitude=$lon" +
                    "&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m,wind_direction_10m" +
                    "&timezone=auto"
                val connection = URL(endpoint).openConnection() as HttpURLConnection
                connection.connectTimeout = 7000
                connection.readTimeout = 7000
                connection.requestMethod = "GET"
                try {
                    if (connection.responseCode in 200..299) {
                        val body = connection.inputStream.bufferedReader().use { it.readText() }
                        val current = JSONObject(body).getJSONObject("current")
                        temperatureC = current.optDouble("temperature_2m").takeUnless { it.isNaN() }
                        humidityPct = current.optInt("relative_humidity_2m").takeIf { it >= 0 }
                        windKmh = current.optDouble("wind_speed_10m").takeUnless { it.isNaN() }
                        windDirection = current.optInt("wind_direction_10m").takeIf { it >= 0 }
                        weatherCondition = weatherCodeText(current.optInt("weather_code", -1))
                    }
                } finally {
                    connection.disconnect()
                }
            } catch (_: Throwable) {
                // Keep the last successful weather value. Recording never depends on network.
            }
        }
    }

    private fun weatherCodeText(code: Int): String = when (code) {
        0 -> "Clear"
        1 -> "Mostly clear"
        2 -> "Partly cloudy"
        3 -> "Cloudy"
        45, 48 -> "Fog"
        51, 53, 55 -> "Drizzle"
        56, 57 -> "Freezing drizzle"
        61, 63, 65 -> "Rain"
        66, 67 -> "Freezing rain"
        71, 73, 75, 77 -> "Snow"
        80, 81, 82 -> "Rain showers"
        85, 86 -> "Snow showers"
        95 -> "Thunderstorm"
        96, 99 -> "Storm / hail"
        else -> "Weather"
    }

    private fun refreshHud() {
        headlineText.text = headline
        val tc = if (recording == null) "00:00:00" else formatDuration(recordedDurationNanos)
        val localClock = SimpleDateFormat("yyyy-MM-dd HH:mm:ss z", Locale.US).format(Date())
        timeText.text = "TC $tc • $localClock"

        val lat = latitude
        val lon = longitude
        locationText.text = if (lat != null && lon != null) {
            val altText = altitude?.let { " ALT ${it.roundToInt()}m" } ?: ""
            val accText = accuracy?.let { " ±${it.roundToInt()}m" } ?: ""
            val speedText = speedKmh?.let { " ${it.roundToInt()}km/h" } ?: ""
            val headingText = heading?.let { " ${it.roundToInt()}°" } ?: ""
            "$placeName\nLAT ${"%.5f".format(Locale.US, lat)}  LON ${"%.5f".format(Locale.US, lon)}$altText$accText$speedText$headingText"
        } else "GPS waiting"

        weatherText.text = buildString {
            append("WX ")
            temperatureC?.let { append("${"%.1f".format(Locale.US, it)}°C • ") }
            append(weatherCondition)
            humidityPct?.let { append(" • RH ${it}%") }
            windKmh?.let { append(" • WIND ${"%.1f".format(Locale.US, it)}km/h") }
            windDirection?.let { append(" ${it}°") }
        }

        val mic = if (hasPermission(Manifest.permission.RECORD_AUDIO)) "MIC ON" else "MIC OFF"
        val level = if (recording != null) String.format(Locale.US, "%.0fdB", lastAudioDb) else "LEVEL --"
        lastMicRoute = audioRouteLabel()
        lastHpRoute = headphoneRouteLabel()
        deviceText.text = "$mic • $level • $lastMicRoute • $lastHpRoute • BAT ${batteryPercent()}% • FREE ${freeStorageGb()}GB • NET ${networkLabel()}"
        refreshProStatus()
    }

    private fun drawBurnIn(canvas: Canvas, width: Float, height: Float) {
        if (width <= 1f || height <= 1f) return
        canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)
        val u = (minOf(width, height) / 1000f).coerceAtLeast(0.4f)
        val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        }

        fill.color = 0xD9000000.toInt()
        canvas.drawRoundRect(26*u, 28*u, 302*u, 100*u, 14*u, 14*u, fill)
        text.color = 0xFFFFD54A.toInt()
        text.textSize = 38*u
        canvas.drawText("PULSE NEWS", 48*u, 76*u, text)

        if (recording != null) {
            fill.color = 0xE6E53935.toInt()
            canvas.drawRoundRect(320*u, 28*u, 478*u, 100*u, 14*u, 14*u, fill)
            text.color = Color.WHITE
            text.textSize = 34*u
            canvas.drawText("● REC", 346*u, 76*u, text)
        }

        val stripTop = if (telemetrySettings.top) 118*u else height - 308*u
        val bottomY = stripTop + 272*u
        val alpha = (telemetrySettings.opacity * 255f).roundToInt().coerceIn(50, 255)
        fill.color = (alpha shl 24) or 0x000000
        canvas.drawRoundRect(26*u, stripTop, width - 26*u, bottomY, 18*u, 18*u, fill)

        text.color = 0xFFFFD54A.toInt()
        text.textSize = 28*u
        canvas.drawText(reporterName.uppercase(Locale.US).take(42), 48*u, stripTop + 42*u, text)

        text.color = Color.WHITE
        text.textSize = 36*u
        canvas.drawText(headline.uppercase(Locale.US).take(56), 48*u, stripTop + 88*u, text)

        text.color = 0xFFD8E9ED.toInt()
        text.textSize = 22*u
        canvas.drawText(placeName.take(80), 48*u, stripTop + 126*u, text)

        val lat = latitude
        val lon = longitude
        val gpsLine = if (!telemetrySettings.gps) "" else if (lat != null && lon != null) {
            "LAT ${"%.5f".format(Locale.US, lat)}  LON ${"%.5f".format(Locale.US, lon)}" +
                (if (telemetrySettings.altitude) altitude?.let { "  ALT ${it.roundToInt()}m" } ?: "" else "") +
                (if (telemetrySettings.altitude) accuracy?.let { "  ±${it.roundToInt()}m" } ?: "" else "") +
                (if (telemetrySettings.motion) speedKmh?.let { "  ${it.roundToInt()}km/h" } ?: "" else "") +
                (if (telemetrySettings.motion) heading?.let { "  ${it.roundToInt()}deg" } ?: "" else "")
        } else "GPS ACQUIRING"
        canvas.drawText(gpsLine.take(95), 48*u, stripTop + 160*u, text)

        val wx = if (!telemetrySettings.weather) "" else buildString {
            temperatureC?.let { append("${"%.1f".format(Locale.US, it)}C ") }
            append(weatherCondition.uppercase(Locale.US))
            humidityPct?.let { append(" RH${it}%") }
            windKmh?.let { append(" WIND${"%.0f".format(Locale.US, it)}km/h") }
        }
        val tc = if (recording == null) "00:00:00" else formatDuration(recordedDurationNanos)
        val clock = if (telemetrySettings.time) SimpleDateFormat("yyyy-MM-dd HH:mm:ss z", Locale.US).format(Date()) else ""
        canvas.drawText("$clock  ${if (telemetrySettings.time) "TC $tc" else ""}  $wx".trim().take(100), 48*u, stripTop + 196*u, text)

        val proLine = buildString {
            append(if (manualMode) "MAN " else "AUTO ")
            if (manualMode) {
                append("ISO$isoValue ")
                append("SH${shutterAngle}deg ")
                append("WB${wbKelvin}K T${if (wbTint >= 0) "+" else ""}$wbTint ")
                append("F${focusPercent}% ")
            }
            append("${qualityName(selectedQuality)} ${targetFps}FPS ")
            if (videoStabilization) append("EIS ")
            if (oisEnabled) append("OIS ")
            if (recording != null) append(String.format(Locale.US, "AUD %.0fdB ", lastAudioDb))
            append(lastMicRoute)
            if (telemetrySettings.network) append(" NET ${networkLabel()} ${upstreamKbps() ?: 0}kbps")
            if (telemetrySettings.device) append(" BAT${batteryPercent()}% FREE${freeStorageGb()}GB")
        }
        text.color = 0xFFFFD54A.toInt()
        text.textSize = 20*u
        canvas.drawText(proLine.take(110), 48*u, stripTop + 232*u, text)
    }


    private fun telemetrySnapshot(elapsedUs: Long, mode: String, droppedFrames: Long?): TelemetrySnapshot {
        return TelemetrySnapshot(
            epochMs = System.currentTimeMillis(),
            elapsedUs = elapsedUs,
            timezone = TelemetrySessionRecorder.timezoneId(),
            timecode = TelemetrySessionRecorder.timecode(elapsedUs),
            mode = mode,
            reporter = reporterName,
            headline = headline,
            place = placeName,
            latitude = latitude, longitude = longitude, altitudeM = altitude, accuracyM = accuracy,
            speedKmh = speedKmh, headingDeg = heading,
            temperatureC = temperatureC, condition = weatherCondition, humidityPct = humidityPct,
            windKmh = windKmh, windDirectionDeg = windDirection,
            network = networkLabel(), upstreamKbps = upstreamKbps(), droppedFrames = droppedFrames,
            batteryPct = batteryPercent(), freeStorageGb = freeStorageGb()
        )
    }

    private fun upstreamKbps(): Int? {
        return try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            cm.getNetworkCapabilities(cm.activeNetwork)?.linkUpstreamBandwidthKbps?.takeIf { it > 0 }
        } catch (_: Throwable) { null }
    }

    private fun formatDuration(nanos: Long): String {
        val total = nanos / 1_000_000_000L
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return String.format(Locale.US, "%02d:%02d:%02d", h, m, s)
    }

    private fun batteryPercent(): Int {
        val intent: Intent = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return -1
        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        return if (level >= 0 && scale > 0) (level * 100f / scale).roundToInt() else -1
    }

    private fun freeStorageGb(): Int {
        return try {
            val stat = StatFs(Environment.getExternalStorageDirectory().absolutePath)
            (stat.availableBytes / 1_073_741_824L).toInt()
        } catch (_: Throwable) { -1 }
    }

    private fun networkLabel(): String {
        return try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return "OFFLINE"
            when {
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "WIFI"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> cellularGeneration()
                caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "ETH"
                else -> "NETWORK"
            }
        } catch (_: Throwable) { "--" }
    }

    private fun cellularGeneration(): String = try {
        val tm = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
        when (tm.dataNetworkType) {
            TelephonyManager.NETWORK_TYPE_NR -> "5G"
            TelephonyManager.NETWORK_TYPE_LTE -> "4G"
            TelephonyManager.NETWORK_TYPE_HSPAP, TelephonyManager.NETWORK_TYPE_HSPA,
            TelephonyManager.NETWORK_TYPE_HSUPA, TelephonyManager.NETWORK_TYPE_HSDPA,
            TelephonyManager.NETWORK_TYPE_UMTS -> "3G"
            TelephonyManager.NETWORK_TYPE_EDGE, TelephonyManager.NETWORK_TYPE_GPRS -> "2G"
            else -> "CELL"
        }
    } catch (_: Throwable) { "CELL" }

    private fun hasPermission(permission: String): Boolean =
        ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    private fun horizontal() = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun label(textValue: String, size: Float, color: Int, bold: Boolean): TextView = TextView(this).apply {
        text = textValue
        textSize = size
        setTextColor(color)
        typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.MONOSPACE
        maxLines = 3
    }

    private fun smallButton(title: String): Button = Button(this).apply {
        text = title
        textSize = 10f
        setTextColor(Color.WHITE)
        isAllCaps = false
        minWidth = 0
        minHeight = 0
        background = rounded(0xB812171A.toInt(), 16f, 0x55FFFFFF)
        layoutParams = LinearLayout.LayoutParams(dp(78), dp(48))
    }

    private fun rounded(fill: Int, radiusDp: Float, stroke: Int? = null): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        setColor(fill)
        cornerRadius = dp(radiusDp.toInt()).toFloat()
        stroke?.let { setStroke(dp(1), it) }
    }

    private fun weight() = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)

    private fun space(heightDp: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(heightDp))
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).roundToInt()

    private fun seekListener(onChange: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
            if (fromUser) onChange(progress)
        }
        override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
        override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
    }

    override fun onResume() {
        super.onResume()
        rotationSensor?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_UI) }
    }

    override fun onPause() {
        sensorManager.unregisterListener(this)
        super.onPause()
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event?.sensor?.type != Sensor.TYPE_ROTATION_VECTOR) return
        try {
            val rotationMatrix = FloatArray(9)
            val orientation = FloatArray(3)
            SensorManager.getRotationMatrixFromVector(rotationMatrix, event.values)
            SensorManager.getOrientation(rotationMatrix, orientation)
            val roll = Math.toDegrees(orientation[2].toDouble()).toFloat()
            monitorOverlay.updateRoll(roll)
        } catch (_: Throwable) { }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    override fun onDestroy() {
        if (::telemetryRecorder.isInitialized && telemetryRecorder.isActive()) telemetryRecorder.stop()
        super.onDestroy()
        main.removeCallbacksAndMessages(null)
        timelapseRunning = false
        sensorManager.unregisterListener(this)
        recording?.stop()
        recording = null
        imageAnalysis?.clearAnalyzer()
        overlayEffect?.close()
        if (locationStarted) fusedLocation.removeLocationUpdates(locationCallback)
        io.shutdownNow()
    }
}
