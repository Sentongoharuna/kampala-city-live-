# PULSE Phase 4 — Advanced Telemetry + Timed Metadata

This is the cumulative native Android project: Phase 1 + Phase 2 + Phase 3 + Phase 4.

## Added in Phase 4

- GPS telemetry sampled every second while recording/LIVE.
- Latitude, longitude, altitude, accuracy, speed and heading.
- Reverse-geocoded place information retained from the camera/live layers.
- Weather snapshot with a 10-minute refresh/cache cycle so the last valid weather remains available if connectivity drops.
- Date/time/timezone/timecode synchronized with each telemetry sample.
- Network transport/upstream estimate, battery and free-storage fields.
- Customizable visible telemetry strip: choose which fields are shown, position and opacity.
- Optional mini-map thumbnail driven by the current GPS position.
- Real MP4 timed metadata track using MIME `application/vnd.pulse.telemetry+json`.
- JSONL telemetry sidecar is also published for portability.
- Metadata processing is non-destructive: if the remux step fails, the original video is preserved and only the sidecar is used.

## Continuity

Phase 1 camera/reporting, Phase 2 professional controls and Phase 3 LIVE broadcasting remain in the same cumulative project.

## Timed metadata format

The MP4 metadata track stores one UTF-8 JSON sample per telemetry tick. The presentation timestamp uses elapsed microseconds from the beginning of the recording. See `PHASE4-TELEMETRY-SCHEMA.md`.

## Build

Use the supplied GitHub Actions workflow. It produces an installable debug APK named `PULSE-PHASE4-ADVANCED-TELEMETRY.apk`.

A signed Play Store APK/AAB is reserved for the final release phase.
