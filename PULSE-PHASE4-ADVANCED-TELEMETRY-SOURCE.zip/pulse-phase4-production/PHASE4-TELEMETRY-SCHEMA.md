# PULSE timed telemetry schema v1

Track MIME: `application/vnd.pulse.telemetry+json`

Each MP4 metadata sample is UTF-8 JSON. `presentationTimeUs` is the elapsed time from the start of the recording session. A typical payload is:

```json
{
  "schema":"pulse.telemetry.v1",
  "epoch_ms":1787470000000,
  "elapsed_us":12000000,
  "timezone":"Africa/Kampala",
  "timecode":"00:00:12.000",
  "mode":"CAMERA",
  "reporter":"PULSE REPORTER",
  "headline":"CITIZEN REPORT",
  "place":"Kampala, Central Region, Uganda",
  "latitude":0.3136,
  "longitude":32.5811,
  "altitude_m":1190.0,
  "accuracy_m":5.0,
  "speed_kmh":0.0,
  "heading_deg":90.0,
  "temperature_c":25.1,
  "condition":"Partly cloudy",
  "humidity_pct":64,
  "wind_kmh":11.2,
  "wind_direction_deg":135,
  "network":"5G",
  "upstream_kbps":18000,
  "dropped_frames":0,
  "battery_pct":73,
  "free_storage_gb":81
}
```

Null values mean the device/provider did not expose a valid reading at that instant. Consumers must keep recording usable when any optional value is null.
