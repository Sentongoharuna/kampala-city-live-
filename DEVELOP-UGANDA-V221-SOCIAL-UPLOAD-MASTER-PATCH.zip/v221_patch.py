from pathlib import Path
import re
import shutil

ROOT = Path("v172-source/app")
SRC = ROOT / "src/main/java/com/sentongoharuna/pulse"
EDITOR = SRC / "DevelopUgandaEditorActivity.kt"
REPORT = SRC / "DevelopUgandaCameraActivity.kt"
LIVE = SRC / "DevelopUgandaLiveActivity.kt"
HOME = SRC / "DevelopUgandaNewsroomActivity.kt"
GRADLE = ROOT / "build.gradle.kts"

PAYLOAD = Path(__file__).resolve().parent

gradle = GRADLE.read_text(encoding="utf-8")

if 'versionCode = 22000' not in gradle:
    raise SystemExit("V221 expects V220 Shot Finder + Media3 Editor first")

if 'versionName = "220.0-shot-finder-media3-editor"' not in gradle:
    raise SystemExit("V221 expects V220 versionName")

editor_source = PAYLOAD / "DevelopUgandaEditorActivityV221.kt"

if not editor_source.exists():
    raise SystemExit("V221 editor source payload missing")

shutil.copyfile(
    editor_source,
    EDITOR
)

# Keep all V205-V215 camera functionality, but make new saved recordings
# identify the installed V221 app version rather than V220.
report = REPORT.read_text(encoding="utf-8")
report = report.replace(
    "V220",
    "V221"
)
REPORT.write_text(
    report,
    encoding="utf-8"
)

live = LIVE.read_text(encoding="utf-8")
live = live.replace(
    "V220",
    "V221"
)
LIVE.write_text(
    live,
    encoding="utf-8"
)

home = HOME.read_text(encoding="utf-8")

top_anchor = '"SHOT FINDER + MEDIA3 EDITOR • V220"'

if top_anchor not in home:
    raise SystemExit("V221 HOME V220 top anchor missing")

home = home.replace(
    top_anchor,
    '"SOCIAL UPLOAD MASTER • V221\\nSHOT FINDER + MEDIA3 EDITOR"',
    1
)

home = home.replace(
    '"EDIT DESK • MEDIA3"',
    '"EDIT + SOCIAL MASTER"',
    1
)

home = home.replace(
    '"Reliable Android video pickup + playback + editing"',
    '"Edit normally, then create TikTok or Reels upload masters without touching the original"',
    1
)

home = home.replace(
    '"GALLERY • FILES • RECENT • LAST CLIP • Media3 ExoPlayer preview • SET IN/OUT • Media3 Transformer cut • mute • save • share"',
    '"GALLERY • FILES • RECENT • LAST CLIP • Media3 preview/edit • TIKTOK MASTER 16 Mbps • REELS MASTER 14 Mbps • original preserved"',
    1
)

HOME.write_text(
    home,
    encoding="utf-8"
)

gradle = re.sub(
    r"versionCode\s*=\s*\d+",
    "versionCode = 22100",
    gradle,
    count=1
)

gradle = re.sub(
    r'versionName\s*=\s*"[^"]+"',
    'versionName = "221.0-social-upload-master"',
    gradle,
    count=1
)

GRADLE.write_text(
    gradle,
    encoding="utf-8"
)

print("V221 Social Upload Master applied.")
