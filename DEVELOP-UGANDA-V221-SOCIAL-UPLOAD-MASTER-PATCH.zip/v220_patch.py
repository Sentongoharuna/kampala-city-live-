from pathlib import Path
import json
import re
import shutil

ROOT = Path("v172-source/app")
SRC = ROOT / "src/main/java/com/sentongoharuna/pulse"
EDITOR = SRC / "DevelopUgandaEditorActivity.kt"
REPORT = SRC / "DevelopUgandaCameraActivity.kt"
LIVE = SRC / "DevelopUgandaLiveActivity.kt"
HOME = SRC / "DevelopUgandaNewsroomActivity.kt"
GRADLE = ROOT / "build.gradle.kts"

PAYLOAD = Path(__file__).resolve().parent

gradle = GRADLE.read_text(encoding="utf-8")

if 'versionCode = 21900' not in gradle:
    raise SystemExit("V220 expects V219 base")

if 'versionName = "219.0-live-badge-separation-pro"' not in gradle:
    raise SystemExit("V220 expects V219 Live Badge Separation Pro")

# Replace only the editor implementation file.
editor_source = PAYLOAD / "DevelopUgandaEditorActivity.kt"
if not editor_source.exists():
    raise SystemExit("V220 editor payload missing")

shutil.copyfile(editor_source, EDITOR)

# Add official Media3 modules, all on 1.11.0.
media3_lines = (
    '    implementation("androidx.media3:media3-common:1.11.0")\n'
    '    implementation("androidx.media3:media3-exoplayer:1.11.0")\n'
    '    implementation("androidx.media3:media3-ui:1.11.0")\n'
    '    implementation("androidx.media3:media3-transformer:1.11.0")\n'
    '    implementation("androidx.media3:media3-effect:1.11.0")\n'
)

if 'androidx.media3:media3-exoplayer' not in gradle:
    anchor = '    implementation("androidx.activity:activity-ktx:1.11.0")\n'

    if anchor not in gradle:
        raise SystemExit("V220 Gradle Media3 anchor missing")

    gradle = gradle.replace(
        anchor,
        anchor + media3_lines,
        1
    )

# Camera use-case labels. Real first-run defaults and CameraX bind engine remain.
report = REPORT.read_text(encoding="utf-8")

name_map = json.loads(
    (PAYLOAD / "camera_name_map.json").read_text(encoding="utf-8")
)

for old, new in name_map.items():
    if old not in report:
        raise SystemExit("V220 REPORT name anchor missing: " + old)

    report = report.replace(old, new)

instruction_map = json.loads(
    (PAYLOAD / "camera_instruction_map.json").read_text(encoding="utf-8")
)

for old, new in instruction_map.items():
    if old not in report:
        raise SystemExit("V220 REPORT instruction anchor missing: " + old)

    report = report.replace(old, new)

best_for_fn = (
    PAYLOAD / "camera_best_for.txt"
).read_text(encoding="utf-8")

accent_anchor = '    private fun cameraExperienceAccentColor(): Int {\n'

if 'private fun cameraExperienceBestFor()' not in report:
    if accent_anchor not in report:
        raise SystemExit("V220 REPORT accent anchor missing")

    report = report.replace(
        accent_anchor,
        best_for_fn + accent_anchor,
        1
    )

old_banner = (
    '            cameraExperienceBannerView.text =\n'
    '                "${cameraExperienceDisplayName()}\\n${cameraExperienceInstruction()}"\n'
)

new_banner = (
    '            cameraExperienceBannerView.text =\n'
    '                "${cameraExperienceDisplayName()}\\nBEST FOR • ${cameraExperienceBestFor()}\\n${cameraExperienceInstruction()}"\n'
)

if old_banner not in report:
    raise SystemExit("V220 REPORT camera banner anchor missing")

report = report.replace(
    old_banner,
    new_banner,
    1
)

# Newly recorded REPORT files should identify V220.
report = report.replace(
    '"app_version",\n                            "V217"',
    '"app_version",\n                            "V220"',
    1
)

report = report.replace(
    '"camera_engine",\n                            "V217 FIX1 FULL FRAME HUD PRO"',
    '"camera_engine",\n                            "V217 FULL FRAME HUD + V220 SHOT FINDER"',
    1
)

report = report.replace(
    '"${sceneTag()} • V217"',
    '"${sceneTag()} • V220"',
    1
)

report = report.replace(
    '•   V217   •   THERM',
    '•   V220   •   THERM',
    1
)

report = report.replace(
    '"DEVELOP_UGANDA_V217_${cameraExperienceId}_',
    '"DEVELOP_UGANDA_V220_${cameraExperienceId}_',
    1
)

report = report.replace(
    '• V214"',
    '• V220"',
    1
)

REPORT.write_text(report, encoding="utf-8")

# LIVE version identity only.
live = LIVE.read_text(encoding="utf-8")
live = live.replace("V219", "V220")
LIVE.write_text(live, encoding="utf-8")

# Home: use-case-first Shot Finder, still direct-launch cards.
home = HOME.read_text(encoding="utf-8")

top_anchor = '"LIVE BADGE SAFE LAYOUT • V219\\nEDITOR • V218"'
if top_anchor not in home:
    raise SystemExit("V220 HOME top-version anchor missing")

home = home.replace(
    top_anchor,
    '"SHOT FINDER + MEDIA3 EDITOR • V220"',
    1
)

section_anchor = (
    PAYLOAD / "home_section_anchor.txt"
).read_text(encoding="utf-8")

shot_finder = (
    PAYLOAD / "home_shot_finder.txt"
).read_text(encoding="utf-8")

if section_anchor not in home:
    raise SystemExit("V220 HOME independent-camera section anchor missing")

home = home.replace(
    section_anchor,
    shot_finder,
    1
)

home_map = json.loads(
    (PAYLOAD / "home_map.json").read_text(encoding="utf-8")
)

for old, new in home_map.items():
    if old in home:
        home = home.replace(old, new, 1)

HOME.write_text(home, encoding="utf-8")

gradle = re.sub(
    r"versionCode\s*=\s*\d+",
    "versionCode = 22000",
    gradle,
    count=1
)

gradle = re.sub(
    r'versionName\s*=\s*"[^"]+"',
    'versionName = "220.0-shot-finder-media3-editor"',
    gradle,
    count=1
)

GRADLE.write_text(gradle, encoding="utf-8")

print("V220 Shot Finder + Media3 Editor applied.")
