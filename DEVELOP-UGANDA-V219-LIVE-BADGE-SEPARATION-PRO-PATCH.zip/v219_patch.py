from pathlib import Path
import re

ROOT = Path("v172-source/app")
SRC = ROOT / "src/main/java/com/sentongoharuna/pulse"
LIVE = SRC / "DevelopUgandaLiveActivity.kt"
HOME = SRC / "DevelopUgandaNewsroomActivity.kt"
GRADLE = ROOT / "build.gradle.kts"

gradle = GRADLE.read_text(encoding="utf-8")

if 'versionCode = 21800' not in gradle:
    raise SystemExit("V219 expects V218 Editor Pickup Pro first")

if 'versionName = "218.0-editor-pickup-pro"' not in gradle:
    raise SystemExit("V219 expects V218 editor base")

live = LIVE.read_text(encoding="utf-8")

if '"develop.uganda • V217"' in live:
    live = live.replace(
        '"develop.uganda • V217"',
        '"develop.uganda • V219"',
        1
    )

pattern = re.compile(
    r"        val liveOn =\n.*?        paint\.textSize =\n            12f \* u\n",
    re.S
)

replacement = r"""        val liveOn =
            recording != null

        val blink =
            (
                SystemClock.elapsedRealtime() /
                    500L
                ) %
                2L ==
                0L

        // V219: brand/build and blinking LIVE status use separate lanes.
        // The build capsule never receives the LIVE glow.
        val brandX =
            safeLeft +
                (23f * u)

        paint.textSize =
            38f * u

        paint.color =
            amber

        val brandText =
            "develop.uganda"

        drawStrongLiveText(
            canvas,
            brandText,
            brandX,
            safeTop,
            paint
        )

        val buildText =
            "V219"

        val brandWidth =
            paint.measureText(
                brandText
            )

        val buildLeft =
            brandX +
                brandWidth +
                (13f * u)

        val buildTop =
            safeTop -
                (25f * u)

        val buildRight =
            buildLeft +
                (72f * u)

        val buildBottom =
            safeTop +
                (4f * u)

        val buildPlate =
            Paint(
                Paint.ANTI_ALIAS_FLAG
            ).apply {
                color =
                    0xD9163B5A.toInt()

                style =
                    Paint.Style.FILL
            }

        val buildStroke =
            Paint(
                Paint.ANTI_ALIAS_FLAG
            ).apply {
                color =
                    cyan

                style =
                    Paint.Style.STROKE

                strokeWidth =
                    1.4f * u
            }

        canvas.drawRoundRect(
            buildLeft,
            buildTop,
            buildRight,
            buildBottom,
            8f * u,
            8f * u,
            buildPlate
        )

        canvas.drawRoundRect(
            buildLeft,
            buildTop,
            buildRight,
            buildBottom,
            8f * u,
            8f * u,
            buildStroke
        )

        val buildPaint =
            Paint(
                Paint.ANTI_ALIAS_FLAG
            ).apply {
                color =
                    white

                textSize =
                    12.4f * u

                typeface =
                    Typeface.create(
                        Typeface.MONOSPACE,
                        Typeface.BOLD
                    )
            }

        canvas.drawText(
            buildText,
            buildLeft +
                (14f * u),
            safeTop -
                (6f * u),
            buildPaint
        )

        val badgeLeft =
            safeRight -
                (160f * u)

        val badgeTop =
            safeTop +
                (17f * u)

        val badgeRight =
            safeRight

        val badgeBottom =
            safeTop +
                (51f * u)

        val badgeGlow =
            Paint(
                Paint.ANTI_ALIAS_FLAG
            ).apply {
                color =
                    Color.argb(
                        if (
                            liveOn &&
                            blink
                        ) {
                            95
                        } else if (liveOn) {
                            34
                        } else {
                            18
                        },
                        255,
                        59,
                        50
                    )

                style =
                    Paint.Style.FILL
            }

        canvas.drawRoundRect(
            badgeLeft -
                (5f * u),
            badgeTop -
                (5f * u),
            badgeRight +
                (2f * u),
            badgeBottom +
                (5f * u),
            13f * u,
            13f * u,
            badgeGlow
        )

        val badgeBackground =
            Paint(
                Paint.ANTI_ALIAS_FLAG
            ).apply {
                color =
                    Color.argb(
                        if (
                            liveOn &&
                            blink
                        ) {
                            245
                        } else if (liveOn) {
                            145
                        } else {
                            105
                        },
                        184,
                        48,
                        44
                    )

                style =
                    Paint.Style.FILL
            }

        canvas.drawRoundRect(
            badgeLeft,
            badgeTop,
            badgeRight,
            badgeBottom,
            11f * u,
            11f * u,
            badgeBackground
        )

        val badgeCenterY =
            (
                badgeTop +
                    badgeBottom
                ) /
                2f

        val signalDot =
            Paint(
                Paint.ANTI_ALIAS_FLAG
            ).apply {
                color =
                    Color.argb(
                        if (
                            liveOn &&
                            blink
                        ) {
                            255
                        } else {
                            160
                        },
                        255,
                        255,
                        255
                    )

                style =
                    Paint.Style.FILL
            }

        canvas.drawCircle(
            badgeLeft +
                (15f * u),
            badgeCenterY,
            5.1f * u,
            signalDot
        )

        val pulseRing =
            Paint(
                Paint.ANTI_ALIAS_FLAG
            ).apply {
                color =
                    Color.argb(
                        if (
                            liveOn &&
                            blink
                        ) {
                            230
                        } else {
                            92
                        },
                        255,
                        255,
                        255
                    )

                style =
                    Paint.Style.STROKE

                strokeWidth =
                    1.5f * u
            }

        canvas.drawCircle(
            badgeLeft +
                (15f * u),
            badgeCenterY,
            if (
                liveOn &&
                blink
            ) {
                9.2f * u
            } else {
                7.0f * u
            },
            pulseRing
        )

        val badgeText =
            Paint(
                Paint.ANTI_ALIAS_FLAG
            ).apply {
                color =
                    Color.argb(
                        if (
                            liveOn &&
                            blink
                        ) {
                            255
                        } else {
                            188
                        },
                        255,
                        255,
                        255
                    )

                textSize =
                    14.2f * u

                typeface =
                    Typeface.create(
                        Typeface.MONOSPACE,
                        Typeface.BOLD
                    )
            }

        canvas.drawText(
            if (liveOn) {
                "LIVE  •  REC"
            } else {
                "LIVE  •  READY"
            },
            badgeLeft +
                (29f * u),
            badgeCenterY +
                (5f * u),
            badgeText
        )

        val rule =
            Paint(
                Paint.ANTI_ALIAS_FLAG
            ).apply {
                color =
                    0xB0FF3B32.toInt()

                strokeWidth =
                    1.5f * u
            }

        canvas.drawLine(
            safeLeft,
            safeTop +
                (63f * u),
            safeRight,
            safeTop +
                (63f * u),
            rule
        )

        paint.textSize =
            12f * u
"""

live, n = pattern.subn(lambda _m: replacement, live, count=1)

if n != 1:
    raise SystemExit("V219 LIVE header/badge anchor missing")

pairs = [
    (
        "            safeTop +\n                (38f * u),",
        "            safeTop +\n                (84f * u),"
    ),
    (
        "            safeTop +\n                (57f * u),",
        "            safeTop +\n                (104f * u),"
    ),
    (
        "            safeTop +\n                (77f * u),",
        "            safeTop +\n                (126f * u),"
    ),
]

for old, new in pairs:
    if old not in live:
        raise SystemExit("V219 metadata row anchor missing")
    live = live.replace(old, new, 1)

if "MANUAL LIVE   |   V215" not in live:
    raise SystemExit("V219 stale V215 tech anchor missing")

live = live.replace(
    "MANUAL LIVE   |   V215",
    "MANUAL LIVE   |   V219",
    1
)

if "develop.uganda • V215" not in live:
    raise SystemExit("V219 stale V215 lower-third anchor missing")

live = live.replace(
    "develop.uganda • V215",
    "develop.uganda • V219",
    1
)

live = live.replace(
    '"DEVELOP_UGANDA_V217_LIVE_',
    '"DEVELOP_UGANDA_V219_LIVE_',
    1
)

LIVE.write_text(live, encoding="utf-8")

home = HOME.read_text(encoding="utf-8")

if '"EDITOR PICKUP PRO • V218\\nCAMERA CORE • V217"' in home:
    home = home.replace(
        '"EDITOR PICKUP PRO • V218\\nCAMERA CORE • V217"',
        '"LIVE BADGE SAFE LAYOUT • V219\\nEDITOR • V218"',
        1
    )

home = home.replace(
    '"SHORT TELEMETRY RAIL • WIDER READABLE COLUMN • SOFT PANEL • CLEAR CAMERA/MODE ROWS • FULL-OPACITY COLOURS"',
    '"SHORT TELEMETRY RAIL • WIDER READABLE COLUMN • LIVE BUILD TAG AND BLINKING REC BADGE USE SEPARATE SAFE LANES"',
    1
)

HOME.write_text(home, encoding="utf-8")

gradle = re.sub(
    r"versionCode\s*=\s*\d+",
    "versionCode = 21900",
    gradle,
    count=1
)

gradle = re.sub(
    r'versionName\s*=\s*"[^"]+"',
    'versionName = "219.0-live-badge-separation-pro"',
    gradle,
    count=1
)

GRADLE.write_text(gradle, encoding="utf-8")

print("V219 Live Badge Separation Pro applied.")
