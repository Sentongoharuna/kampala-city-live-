develop.uganda V230 • Cinema Color Engine 2.0

WHAT CHANGED
- Stronger, visibly different original develop.uganda color recipes.
- Retuned DU CINEMA NATURAL, DU COOL CINEMA and DU FILM BIAS.
- New signature looks:
  * DU URBAN TEAL
  * DU GOLDEN CITY
  * DU STEEL + FIRE
  * DU RETRO AMBER
  * DU BURGUNDY CINEMA
  * DU OLIVE DOCUMENTARY
  * DU DEEP SPACE
- Stronger split-toning across shadows / midtones / highlights.
- Selective teal/cyan, amber/orange and green shaping inside the generated 17^3 LUT.
- Profile-specific highlight shoulders for a more film-like roll-off.
- AUTO routing understands welding/fire, sunset/golden, city/street/urban, construction/building/site, night, people, social, documentary, retro and drama hints.
- Color Studio groups profiles into CORE CINEMA, SIGNATURE CINEMA and DELIVERY / SUBJECT and displays palette targets.

IMPORTANT
- Original CameraX MP4 is never replaced.
- COLOR_MASTER.mp4 remains a separate H.264/AAC Media3 LUT render.
- The optional monitor remains an approximation and is not the master render.
- No proprietary ARRI/Sony/RED/Blackmagic/etc LUT files are copied.
- Internal v229* helper names are deliberately retained to reduce upgrade risk; visible/app version is V230.

BASE REQUIRED
- develop.uganda V229 Professional Color Engine already applied successfully.
- versionCode 22900 / versionName 229.0-professional-color-engine before this patch.
