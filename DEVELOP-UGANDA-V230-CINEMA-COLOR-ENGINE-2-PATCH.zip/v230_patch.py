from pathlib import Path
import shutil

ROOT = Path("v172-source/app")
SRC = ROOT / "src/main/java/com/sentongoharuna/pulse"

REPORT = SRC / "DevelopUgandaCameraActivity.kt"
LIVE = SRC / "DevelopUgandaLiveActivity.kt"
HOME = SRC / "DevelopUgandaNewsroomActivity.kt"
PACKAGER = SRC / "DevelopUgandaStoryPackager.kt"
REVIEW = SRC / "DevelopUgandaInstantReviewDialog.kt"
BRAND = SRC / "DevelopUgandaBrandMetadataStore.kt"
GRADLE = ROOT / "build.gradle.kts"
PAYLOAD = Path(__file__).resolve().parent


def require(text: str, needle: str, label: str):
    if needle not in text:
        raise SystemExit(f"V230 base check failed: {label} missing: {needle}")


def replace_required(text: str, old: str, new: str, label: str, count: int = 1):
    if old not in text:
        raise SystemExit(f"V230 anchor missing: {label}: {old}")
    return text.replace(old, new, count)


# ---------------------------------------------------------------------------
# Require the proven V229 base. V230 changes only the color recipe layer,
# visible version labels and app version. CameraX bind engines are untouched.
# ---------------------------------------------------------------------------
gradle = GRADLE.read_text(encoding="utf-8")
require(gradle, "versionCode = 22900", "V229 versionCode")
require(gradle, 'versionName = "229.0-professional-color-engine"', "V229 versionName")

for path in [REPORT, LIVE, HOME, PACKAGER, REVIEW, BRAND]:
    if not path.exists():
        raise SystemExit(f"V230 required source missing: {path}")

engine_path = SRC / "DevelopUgandaColorEngine.kt"
studio_path = SRC / "DevelopUgandaColorStudioActivity.kt"
if not engine_path.exists() or not studio_path.exists():
    raise SystemExit("V230 requires the V229 Professional Color Engine files")

old_engine = engine_path.read_text(encoding="utf-8")
for needle in [
    "DU CINEMA NATURAL",
    "DU COOL CINEMA",
    "DU FILM BIAS",
    "SingleColorLut.createFromCube",
    "DEVELOP_UGANDA_V229_",
]:
    require(old_engine, needle, "V229 color engine")

# Replace the engine/studio with V230 Cinema Color Engine 2.0.
shutil.copyfile(PAYLOAD / "DevelopUgandaColorEngine.kt", engine_path)
shutil.copyfile(PAYLOAD / "DevelopUgandaColorStudioActivity.kt", studio_path)

# ---------------------------------------------------------------------------
# Visible V230 integration. Internal v229* helper function names stay unchanged
# so the upgrade is low-risk and does not rewire the proven recording pipeline.
# ---------------------------------------------------------------------------
report = REPORT.read_text(encoding="utf-8")
require(report, "ACTION_COLOR_ENGINE", "REPORT V229 color integration")
require(report, "scheduleV229ColorMaster", "REPORT V229 color scheduling")
report = report.replace("V229", "V230")
REPORT.write_text(report, encoding="utf-8")

live = LIVE.read_text(encoding="utf-8")
require(live, "liveColorButton", "LIVE V229 color integration")
require(live, "scheduleV229LiveColorMaster", "LIVE V229 color scheduling")
live = live.replace("V229", "V230")
LIVE.write_text(live, encoding="utf-8")

home = HOME.read_text(encoding="utf-8")
require(home, "V229 • PROFESSIONAL COLOR ENGINE", "V229 home module label")
home = home.replace(
    "V229 • PROFESSIONAL COLOR ENGINE",
    "V230 • CINEMA COLOR ENGINE 2.0"
)
home = home.replace("V229", "V230")
HOME.write_text(home, encoding="utf-8")

packager = PACKAGER.read_text(encoding="utf-8")
require(packager, "COLOR_MASTER.mp4", "Story Package color master")
require(packager, "COLOR_PROFILE.json", "Story Package color profile")
packager = packager.replace("V229", "V230")
packager = packager.replace(
    "Professional Color Engine",
    "Cinema Color Engine 2.0"
)
PACKAGER.write_text(packager, encoding="utf-8")

review = REVIEW.read_text(encoding="utf-8")
require(review, '"COLOR MASTER"', "Instant Review color master")
require(review, '"COLOR STUDIO"', "Instant Review color studio")
review = review.replace("V229", "V230")
REVIEW.write_text(review, encoding="utf-8")

brand = BRAND.read_text(encoding="utf-8")
require(brand, "Recorded with develop.uganda • V229", "V229 brand credit")
brand = brand.replace(
    "Recorded with develop.uganda • V229",
    "Recorded with develop.uganda • V230"
)
BRAND.write_text(brand, encoding="utf-8")

# App version.
gradle = replace_required(
    gradle,
    "versionCode = 22900",
    "versionCode = 23000",
    "versionCode"
)
gradle = replace_required(
    gradle,
    'versionName = "229.0-professional-color-engine"',
    'versionName = "230.0-cinema-color-engine-2"',
    "versionName"
)
GRADLE.write_text(gradle, encoding="utf-8")

print("PASS: V230 Cinema Color Engine 2.0 patch applied.")
print("PASS: V229 recording/social/story/brand architecture retained.")
