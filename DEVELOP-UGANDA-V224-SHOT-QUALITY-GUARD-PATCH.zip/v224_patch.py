from pathlib import Path
import re
import shutil

ROOT = Path("v172-source/app")
SRC = ROOT / "src/main/java/com/sentongoharuna/pulse"
REPORT = SRC / "DevelopUgandaCameraActivity.kt"
LIVE = SRC / "DevelopUgandaLiveActivity.kt"
HOME = SRC / "DevelopUgandaNewsroomActivity.kt"
GRADLE = ROOT / "build.gradle.kts"

PAYLOAD = Path(__file__).resolve().parent

def replace_once(text, old, new, label):
    if old not in text:
        raise SystemExit("V224 anchor missing: " + label)
    return text.replace(old, new, 1)

gradle = GRADLE.read_text(encoding="utf-8")

if 'versionCode = 22302' not in gradle:
    raise SystemExit("V224 expects V223 FIX2 versionCode 22302")

if 'versionName = "223.2-all-cameras-auto-view-fix2"' not in gradle:
    raise SystemExit("V224 expects V223 FIX2 base")

shutil.copyfile(
    PAYLOAD / "DevelopUgandaShotAssistView.kt",
    SRC / "DevelopUgandaShotAssistView.kt"
)

report = REPORT.read_text(encoding="utf-8")

report = replace_once(
    report,
    "        const val ACTION_AUTO_DIRECTOR = 22\n",
    "        const val ACTION_AUTO_DIRECTOR = 22\n"
    "        const val ACTION_SHOT_ASSIST = 23\n",
    "ACTION_SHOT_ASSIST"
)

report = replace_once(
    report,
    "    private lateinit var autoViewDescriptionView: TextView\n",
    "    private lateinit var autoViewDescriptionView: TextView\n"
    "    private lateinit var shotQualityGuardView: TextView\n"
    "    private lateinit var shotAssistView: DevelopUgandaShotAssistView\n",
    "shot guard views"
)

report = replace_once(
    report,
    "    private lateinit var autoDirectorButton: Button\n",
    "    private lateinit var autoDirectorButton: Button\n"
    "    private lateinit var assistButton: Button\n",
    "assist button field"
)

report = replace_once(
    report,
    "    private var focusLockActive = false\n",
    "    private var focusLockActive = false\n"
    "    private var focusAttempted = false\n"
    "    private var focusSuccessful: Boolean? = null\n"
    "    private var preflightApprovedOnce = false\n"
    "    private var shotAssistModeIndex = DevelopUgandaShotAssistView.MODE_OFF\n"
    "    private val shotAssistModeLabels = arrayOf(\"OFF\", \"PEAK\", \"ZEBRA\", \"BOTH\")\n",
    "focus preflight state"
)

handler_anchor = "    private val uiHandler = Handler(Looper.getMainLooper())\n"

assist_runnable = handler_anchor + '''
    private val shotAssistRunnable =
        object : Runnable {
            override fun run() {
                if (
                    shotAssistModeIndex !=
                        DevelopUgandaShotAssistView.MODE_OFF &&
                    ::previewView.isInitialized &&
                    ::shotAssistView.isInitialized
                ) {
                    val bitmap =
                        try {
                            previewView.bitmap
                        } catch (_: Exception) {
                            null
                        }

                    if (bitmap != null) {
                        shotAssistView.submitFrame(
                            bitmap
                        )
                    }
                }

                uiHandler.postDelayed(
                    this,
                    700L
                )
            }
        }

'''

report = replace_once(
    report,
    handler_anchor,
    assist_runnable,
    "shot assist runnable"
)

report = replace_once(
    report,
    "        buildUi()\n"
    "        startAutoViewDescription()\n"
    "        requestPermissionsAndStart()\n",
    "        buildUi()\n"
    "        showRecordingRecoveryNoticeIfNeeded()\n"
    "        startAutoViewDescription()\n"
    "        startShotAssistLoop()\n"
    "        requestPermissionsAndStart()\n",
    "report onCreate hooks"
)

tone_add = (
    "        root.addView(\n"
    "            previewModeToneView,\n"
    "            FrameLayout.LayoutParams(\n"
    "                ViewGroup.LayoutParams.MATCH_PARENT,\n"
    "                ViewGroup.LayoutParams.MATCH_PARENT\n"
    "            )\n"
    "        )\n"
)

assist_add = tone_add + '''
        shotAssistView =
            DevelopUgandaShotAssistView(
                this
            ).apply {
                setAssistMode(
                    shotAssistModeIndex
                )

                isClickable =
                    false

                isFocusable =
                    false
            }

        root.addView(
            shotAssistView,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

'''

report = replace_once(
    report,
    tone_add,
    assist_add,
    "assist overlay"
)

auto_ui = (
    "        previewNarrationPanel.addView(\n"
    "            autoViewDescriptionView,\n"
    "            LinearLayout.LayoutParams(\n"
    "                ViewGroup.LayoutParams.MATCH_PARENT,\n"
    "                dp(24)\n"
    "            )\n"
    "        )\n"
)

guard_ui = auto_ui + '''
        shotQualityGuardView =
            hud(
                "SHOT GUARD • READY",
                7.0f,
                0xFF91B6A0.toInt(),
                bold = true
            ).apply {
                maxLines =
                    2
            }

        previewNarrationPanel.addView(
            shotQualityGuardView,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(30)
            )
        )

'''

report = replace_once(
    report,
    auto_ui,
    guard_ui,
    "shot guard UI"
)

clean_button_end = (
    "        cleanModeButton =\n"
    "            deckButton(\n"
    "                \"CLEAN ▾\\nOFF\",\n"
    "                0xFF83B995.toInt()\n"
    "            )\n"
)

assist_button = clean_button_end + '''
        assistButton =
            deckButton(
                "ASSIST ▾\\n${shotAssistModeLabels[shotAssistModeIndex]}",
                0xFF62D8C9.toInt()
            )

'''

report = replace_once(
    report,
    clean_button_end,
    assist_button,
    "assist button creation"
)

report = replace_once(
    report,
    "        listOf(\n"
    "            autoUiButton,\n"
    "            lockButton,\n"
    "            cleanModeButton\n"
    "        ).forEachIndexed { index, button ->\n",
    "        listOf(\n"
    "            autoUiButton,\n"
    "            lockButton,\n"
    "            cleanModeButton,\n"
    "            assistButton\n"
    "        ).forEachIndexed { index, button ->\n",
    "assist button row"
)

report = replace_once(
    report,
    "        autoDirectorButton.setOnTouchListener(\n"
    "            DeckTouchListener(ACTION_AUTO_DIRECTOR)\n"
    "        )\n",
    "        autoDirectorButton.setOnTouchListener(\n"
    "            DeckTouchListener(ACTION_AUTO_DIRECTOR)\n"
    "        )\n\n"
    "        assistButton.setOnTouchListener(\n"
    "            DeckTouchListener(ACTION_SHOT_ASSIST)\n"
    "        )\n",
    "assist listener"
)

report = replace_once(
    report,
    "                        ACTION_AUTO_DIRECTOR ->\n"
    "                            toggleAutoDirector()\n",
    "                        ACTION_AUTO_DIRECTOR ->\n"
    "                            toggleAutoDirector()\n\n"
    "                        ACTION_SHOT_ASSIST ->\n"
    "                            cycleShotAssist()\n",
    "assist action"
)

helpers = (
    PAYLOAD /
    "report_v224_helpers.txt"
).read_text(
    encoding="utf-8"
)

report = replace_once(
    report,
    "    private fun recordingHealthText(): String {\n",
    helpers +
    "    private fun recordingHealthText(): String {\n",
    "report V224 helpers"
)

old_focus = (
    "            cam.cameraControl\n"
    "                .startFocusAndMetering(\n"
    "                    action\n"
    "                )\n\n"
    "            focusLockActive =\n"
    "                true\n"
)

new_focus = '''
            val focusFuture =
                cam.cameraControl
                    .startFocusAndMetering(
                        action
                    )

            focusAttempted =
                true

            focusSuccessful =
                null

            focusFuture.addListener(
                {
                    focusSuccessful =
                        try {
                            focusFuture.get()
                                .isFocusSuccessful
                        } catch (_: Exception) {
                            false
                        }

                    runOnUiThread {
                        updateShotQualityGuard()

                        if (
                            focusSuccessful ==
                                false
                        ) {
                            toast(
                                "Subject focus not confirmed"
                            )
                        }
                    }
                },
                ContextCompat.getMainExecutor(
                    this
                )
            )

            focusLockActive =
                true
'''

report = replace_once(
    report,
    old_focus,
    new_focus,
    "persistent focus result"
)

old_tap = (
    "            cam.cameraControl\n"
    "                .startFocusAndMetering(action)\n\n"
    "            toast(\"Focus\")\n"
)

new_tap = '''
            val focusFuture =
                cam.cameraControl
                    .startFocusAndMetering(
                        action
                    )

            focusAttempted =
                true

            focusSuccessful =
                null

            focusFuture.addListener(
                {
                    focusSuccessful =
                        try {
                            focusFuture.get()
                                .isFocusSuccessful
                        } catch (_: Exception) {
                            false
                        }

                    runOnUiThread {
                        updateShotQualityGuard()

                        toast(
                            if (
                                focusSuccessful ==
                                    true
                            ) {
                                "Focus confirmed"
                            } else {
                                "Subject focus not confirmed"
                            }
                        )
                    }
                },
                ContextCompat.getMainExecutor(
                    this
                )
            )
'''

report = replace_once(
    report,
    old_tap,
    new_tap,
    "tap focus result"
)

report = replace_once(
    report,
    "        updateThermalGuard()\n\n"
    "        timecodeView.text =\n",
    "        updateThermalGuard()\n"
    "        updateShotQualityGuard()\n\n"
    "        timecodeView.text =\n",
    "refresh shot guard"
)

preflight_anchor = (
    "        if (recording != null) {\n"
    "            recording?.stop()\n"
    "            return\n"
    "        }\n\n"
    "        reportId = newReportId()\n"
)

preflight_insert = (
    "        if (recording != null) {\n"
    "            recording?.stop()\n"
    "            return\n"
    "        }\n\n"
    "        if (\n"
    "            !runFieldPreflightBeforeRecording()\n"
    "        ) {\n"
    "            return\n"
    "        }\n\n"
    "        reportId = newReportId()\n"
)

report = replace_once(
    report,
    preflight_anchor,
    preflight_insert,
    "recording preflight"
)

report = replace_once(
    report,
    "                    recordStartUtc =\n"
    "                        Instant.ofEpochMilli(\n"
    "                            recStarted\n"
    "                        ).toString()\n"
    "                    distanceTravelledM = 0f\n",
    "                    recordStartUtc =\n"
    "                        Instant.ofEpochMilli(\n"
    "                            recStarted\n"
    "                        ).toString()\n"
    "                    markRecordingJournalStarted()\n"
    "                    distanceTravelledM = 0f\n",
    "record journal start"
)

report = replace_once(
    report,
    "                    if (hadError) {\n",
    "                    markRecordingJournalFinished(\n"
    "                        hadError\n"
    "                    )\n\n"
    "                    if (hadError) {\n",
    "record journal finish"
)

report = report.replace(
    "DEVELOP_UGANDA_V223_",
    "DEVELOP_UGANDA_V224_"
)

report = report.replace(
    "• V223",
    "• V224"
)

report = report.replace(
    "•   V223   •",
    "•   V224   •"
)

report = report.replace(
    '"app_version",\n                            "V223"',
    '"app_version",\n                            "V224"'
)

REPORT.write_text(
    report,
    encoding="utf-8"
)

live = LIVE.read_text(
    encoding="utf-8"
)

if (
    "import android.os.StatFs\n"
    not in live
):
    live = replace_once(
        live,
        "import android.os.SystemClock\n",
        "import android.os.SystemClock\n"
        "import android.os.StatFs\n",
        "LIVE StatFs import"
    )

live = replace_once(
    live,
    "    private var liveBlinkOn = true\n",
    "    private var liveBlinkOn = true\n"
    "    private var livePreflightApprovedOnce = false\n",
    "LIVE preflight state"
)

live = replace_once(
    live,
    "        buildLiveUi()\n"
    "        startLiveAutoViewDescription()\n",
    "        buildLiveUi()\n"
    "        showLiveRecoveryNoticeIfNeeded()\n"
    "        startLiveAutoViewDescription()\n",
    "LIVE recovery onCreate"
)

live_helpers = (
    PAYLOAD /
    "live_v224_helpers.txt"
).read_text(
    encoding="utf-8"
)

live = replace_once(
    live,
    "    private fun beginLiveRecordSequence() {\n",
    live_helpers +
    "    private fun beginLiveRecordSequence() {\n",
    "LIVE helpers"
)

live = replace_once(
    live,
    "    private fun beginLiveRecordSequence() {\n"
    "        if (\n"
    "            countdownRunning\n"
    "        ) {\n"
    "            return\n"
    "        }\n",
    "    private fun beginLiveRecordSequence() {\n"
    "        if (\n"
    "            countdownRunning\n"
    "        ) {\n"
    "            return\n"
    "        }\n\n"
    "        if (\n"
    "            recording == null &&\n"
    "            !runLivePreflightBeforeCountdown()\n"
    "        ) {\n"
    "            return\n"
    "        }\n",
    "LIVE preflight gate"
)

live = replace_once(
    live,
    "                        recordStartMs =\n"
    "                            SystemClock.elapsedRealtime()\n\n"
    "                        recordButton.setRecordingState(\n",
    "                        recordStartMs =\n"
    "                            SystemClock.elapsedRealtime()\n\n"
    "                        markLiveJournalStarted()\n\n"
    "                        recordButton.setRecordingState(\n",
    "LIVE journal start"
)

live = replace_once(
    live,
    "                        if (\n"
    "                            event.hasError()\n"
    "                        ) {\n",
    "                        markLiveJournalFinished(\n"
    "                            event.hasError()\n"
    "                        )\n\n"
    "                        if (\n"
    "                            event.hasError()\n"
    "                        ) {\n",
    "LIVE journal finish"
)

live = live.replace(
    "V223",
    "V224"
)

LIVE.write_text(
    live,
    encoding="utf-8"
)

home = HOME.read_text(
    encoding="utf-8"
)

top = (
    '"ALL CAMERAS RETAINED • V223\\n'
    'AUTO VIEW • CAMERA ID IN SAVED VIDEO"'
)

if top in home:
    home = home.replace(
        top,
        '"SHOT QUALITY GUARD • V224\\nALL CAMERAS + AUTO VIEW RETAINED"',
        1
    )

creator_anchor = (
    "        page.addView(\n"
    "            compactStatus(\n"
    '                "CREATOR CAMERA ENGINE",\n'
)

if (
    "SHOT QUALITY GUARD • REAL SIGNALS"
    not in home
):
    if (
        creator_anchor
        not in home
    ):
        raise SystemExit(
            "V224 HOME creator anchor missing"
        )

    card = (
        "        page.addView(\n"
        "            compactStatus(\n"
        '                "SHOT QUALITY GUARD • REAL SIGNALS",\n'
        '                "TOO DARK • MIC CLIPPING • SHAKE HIGH • HORIZON OFF • THERMAL RISK • STORAGE LOW • GPS WEAK • FOCUS NOT CONFIRMED • FIELD PREFLIGHT • RECOVERY JOURNAL • SCREEN-ONLY PEAK/ZEBRA",\n'
        "                0xFF62D8C9.toInt()\n"
        "            )\n"
        "        )\n\n"
    )

    home = home.replace(
        creator_anchor,
        card +
        creator_anchor,
        1
    )

HOME.write_text(
    home,
    encoding="utf-8"
)

gradle = re.sub(
    r"versionCode\s*=\s*\d+",
    "versionCode = 22400",
    gradle,
    count=1
)

gradle = re.sub(
    r'versionName\s*=\s*"[^"]+"',
    'versionName = "224.0-shot-quality-guard"',
    gradle,
    count=1
)

GRADLE.write_text(
    gradle,
    encoding="utf-8"
)

print("V224 Shot Quality Guard applied.")
