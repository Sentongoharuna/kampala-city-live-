develop.uganda V229 Professional Color Engine

Required base
-------------
V228 Brand & Metadata Studio
versionCode 22800
versionName 228.0-brand-metadata-studio

What V229 adds
--------------
- Separate COLOR stage; old LOOK controls stay.
- AUTO / ORIGINAL plus 13 original develop.uganda professional color profiles.
- Real Media3 SingleColorLut 17^3 output transform.
- Separate COLOR_MASTER.mp4; original CameraX recording is never replaced.
- H.264/AAC high-quality re-encode.
- HDR original remains untouched; Color Master uses OpenGL HDR->SDR tone mapping on API 29+ when needed.
- Optional preview monitor approximation, OFF by default to protect the proven CameraX preview.
- REPORT and all REPORT-derived independent cameras get COLOR control.
- LIVE keeps old VIDEO FX and gets a separate COLOR control.
- V222 Social Master exporter stays byte-for-byte protected by the workflow.
- Story Package gains COLOR_MASTER.mp4, COLOR_MASTER_STATUS.txt and COLOR_PROFILE.json.
- Instant Review gains COLOR MASTER and COLOR STUDIO.

Profiles
--------
DU CINEMA NATURAL
DU COOL CINEMA
DU FILM BIAS
DU EXTENDED VIDEO
DU SOFT FILM
DU WARM 709
DU NIGHT CINEMA
DU BLEACH DRAMA
DU GOLDEN HOUR
DU CLEAN SOCIAL
DU CONSTRUCTION
DU PEOPLE
DU MONO CINEMA

Honesty
-------
These are original develop.uganda color transforms. They are not copied ARRI,
Sony, RED, Blackmagic, Canon, Panasonic, Fujifilm or Nikon LUT files, and V229
does not claim software can give a phone the sensor/lens/ISP of a cinema camera.
