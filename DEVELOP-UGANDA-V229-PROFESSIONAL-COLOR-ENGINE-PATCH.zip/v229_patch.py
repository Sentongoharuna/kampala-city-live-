from pathlib import Path
import re
import shutil

ROOT = Path("v172-source/app")
SRC = ROOT / "src/main/java/com/sentongoharuna/pulse"

REPORT = SRC / "DevelopUgandaCameraActivity.kt"
LIVE = SRC / "DevelopUgandaLiveActivity.kt"
PHOTO = SRC / "DevelopUgandaPhotoSuiteActivity.kt"
HOME = SRC / "DevelopUgandaNewsroomActivity.kt"
PACKAGER = SRC / "DevelopUgandaStoryPackager.kt"
REVIEW = SRC / "DevelopUgandaInstantReviewDialog.kt"
BRAND = SRC / "DevelopUgandaBrandMetadataStore.kt"
MANIFEST = ROOT / "src/main/AndroidManifest.xml"
GRADLE = ROOT / "build.gradle.kts"
PAYLOAD = Path(__file__).resolve().parent


def replace_once(text, old, new, label):
    if old not in text:
        raise SystemExit("V229 anchor missing: " + label)
    return text.replace(old, new, 1)


def insert_before(text, marker, addition, label):
    if marker not in text:
        raise SystemExit("V229 insertion anchor missing: " + label)
    return text.replace(marker, addition + marker, 1)


def function_bounds(text, function_name):
    marker = f"fun {function_name}"
    start = text.find(marker)
    if start < 0:
        raise SystemExit("V229 function missing: " + function_name)

    line_start = text.rfind("\n", 0, start) + 1
    brace = text.find("{", start)
    if brace < 0:
        raise SystemExit("V229 opening brace missing: " + function_name)

    depth = 0
    quote = None
    escaped = False

    for index in range(brace, len(text)):
        char = text[index]

        if quote is not None:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == quote:
                quote = None
            continue

        if char in ('"', "'"):
            quote = char
            continue

        if char == "{":
            depth += 1
        elif char == "}":
            depth -= 1
            if depth == 0:
                return line_start, index + 1

    raise SystemExit("V229 closing brace missing: " + function_name)


gradle = GRADLE.read_text(encoding="utf-8")

if 'versionCode = 22800' not in gradle:
    raise SystemExit("V229 requires V228 versionCode 22800")

if 'versionName = "228.0-brand-metadata-studio"' not in gradle:
    raise SystemExit("V229 requires V228 Brand & Metadata Studio base")

for name in [
    "DevelopUgandaColorEngine.kt",
    "DevelopUgandaColorStudioActivity.kt",
]:
    shutil.copyfile(PAYLOAD / name, SRC / name)

# ---------------------------------------------------------------------------
# REPORT — V229 is additive. Existing LOOK remains; COLOR is a separate stage.
# CameraX bindCamera() is intentionally untouched.
# ---------------------------------------------------------------------------
report = REPORT.read_text(encoding="utf-8")

report = replace_once(
    report,
    "        const val ACTION_BRAND_METADATA = 27\n",
    "        const val ACTION_BRAND_METADATA = 27\n"
    "        const val ACTION_COLOR_ENGINE = 28\n",
    "REPORT color action"
)

report = replace_once(
    report,
    "    private lateinit var captureModeButton: Button\n",
    "    private lateinit var captureModeButton: Button\n"
    "    private lateinit var colorButton: Button\n",
    "REPORT color button field"
)

report = replace_once(
    report,
    "    private var directorEnabled = true\n",
    "    private var directorEnabled = true\n"
    "    private var lastV229ColorMonitorKey = \"\"\n"
    "    private var v229ColorOverlayLabel = \"AUTO\"\n",
    "REPORT color state"
)

capture_block = '''        captureModeButton = deckButton(
            "CAPTURE ▾\\n${captureModes[captureModeIndex]}",
            0xFF83B995.toInt()
        )
'''

color_button_block = capture_block + '''        colorButton = deckButton(
            "COLOR ▾\\n${v229ColorDeckLabel()}",
            0xFFA793D8.toInt()
        )
'''

report = replace_once(
    report,
    capture_block,
    color_button_block,
    "REPORT color button creation"
)

report = replace_once(
    report,
    '''            sceneButton,
            lookButton,
            qualityButton,
            captureModeButton
''',
    '''            sceneButton,
            lookButton,
            qualityButton,
            captureModeButton,
            colorButton
''',
    "REPORT mode row color button"
)

report = replace_once(
    report,
    '''        captureModeButton.setOnTouchListener(
            DeckTouchListener(ACTION_CAPTURE_MODE)
        )
''',
    '''        captureModeButton.setOnTouchListener(
            DeckTouchListener(ACTION_CAPTURE_MODE)
        )

        colorButton.setOnTouchListener(
            DeckTouchListener(ACTION_COLOR_ENGINE)
        )
''',
    "REPORT color touch listener"
)

report = replace_once(
    report,
    '''                        ACTION_BRAND_METADATA ->
                            openV228BrandMetadataStudio()
''',
    '''                        ACTION_BRAND_METADATA ->
                            openV228BrandMetadataStudio()

                        ACTION_COLOR_ENGINE ->
                            showV229ColorDropdown(
                                colorButton
                            )
''',
    "REPORT color action dispatch"
)

report_helpers = (PAYLOAD / "report_v229_helpers.txt").read_text(encoding="utf-8")
report = insert_before(
    report,
    "    private fun refreshV228BrandUi() {\n",
    report_helpers,
    "REPORT color helpers"
)

report = replace_once(
    report,
    '''    private fun refreshHud() {
        applyAutoDirectorIfNeeded()
''',
    '''    private fun refreshHud() {
        refreshV229ColorMonitor()
        applyAutoDirectorIfNeeded()
''',
    "REPORT color monitor refresh"
)

report = replace_once(
    report,
    '''        refreshV228BrandUi()

        rotationVectorSensor''',
    '''        refreshV228BrandUi()
        lastV229ColorMonitorKey = ""
        refreshV229ColorMonitor()

        rotationVectorSensor''',
    "REPORT color refresh on resume"
)

# Settings summary gets a distinct COLOR stage; the old LOOK stage remains.
summary_anchor = '''            append(" • FORMAT ")
            append(
                qualityModes[
                    qualityIndex
                ]
            )
            append("\\n")
'''
summary_color = '''            append(" • FORMAT ")
            append(
                qualityModes[
                    qualityIndex
                ]
            )
            append(" • COLOR ")
            append(
                v229ColorResolved().statusLabel()
            )
            append("\\n")
'''
report = replace_once(
    report,
    summary_anchor,
    summary_color,
    "REPORT settings COLOR summary"
)

# Saved-video mode telemetry records which V229 color master profile belongs
# to the clip. The original overlay itself stays in the original CameraX MP4.
report = replace_once(
    report,
    '''                "MODE • ${qualityModes[qualityIndex]}   •   SCENE ${sceneModes[sceneIndex]}   •   LOOK ${lookModes[lookIndex]}",''',
    '''                "MODE • ${qualityModes[qualityIndex]}   •   SCENE ${sceneModes[sceneIndex]}   •   LOOK ${lookModes[lookIndex]}   •   COLOR $v229ColorOverlayLabel",''',
    "REPORT saved color label"
)

# Schedule the separate Color Master only after Story Package creation has
# already been queued. V222 Social Master remains independent and untouched.
report = replace_once(
    report,
    '''                        saveV227ContinuitySnapshot()
''',
    '''                        val v229ColorPackageId =
                            reportId.ifBlank {
                                baseName.ifBlank {
                                    "DU_${System.currentTimeMillis()}"
                                }
                            }

                        scheduleV229ColorMaster(
                            event.outputResults.outputUri,
                            v229ColorPackageId
                        )

                        saveV227ContinuitySnapshot()
''',
    "REPORT color master scheduling"
)

# The integrity record now records the V229 color profile as metadata without
# changing the SHA-256 meaning.
report = replace_once(
    report,
    '''        val lookSnapshot =
            lookModes[
                lookIndex
            ]

        val thermalSnapshot =''',
    '''        val lookSnapshot =
            lookModes[
                lookIndex
            ]

        val colorProfileSnapshot =
            v229ColorResolved().statusLabel()

        val thermalSnapshot =''',
    "REPORT integrity color snapshot"
)

report = replace_once(
    report,
    '''                        put(
                            "look",
                            lookSnapshot
                        )
                        put(
                            "latitude",''',
    '''                        put(
                            "look",
                            lookSnapshot
                        )
                        put(
                            "color_profile",
                            colorProfileSnapshot
                        )
                        put(
                            "latitude",''',
    "REPORT integrity color field"
)

report = report.replace(
    '''                        put(
                            "app_version",
                            "V227"
                        )''',
    '''                        put(
                            "app_version",
                            "V229"
                        )''',
    1
)

# Update only visible/recorded build labels; keep V228 function names intact.
report = report.replace(
    '"${sceneTag()} • V228"',
    '"${sceneTag()} • V229"'
)
report = report.replace(
    '''                "V228"
            )''',
    '''                "V229"
            )'''
)
report = report.replace(
    '''                    "V228"
                ),''',
    '''                    "V229"
                ),'''
)

REPORT.write_text(report, encoding="utf-8")

# ---------------------------------------------------------------------------
# LIVE — old VIDEO FX remains. V229 COLOR is a separate output stage.
# bindCamera() stays unchanged.
# ---------------------------------------------------------------------------
live = LIVE.read_text(encoding="utf-8")

live = replace_once(
    live,
    "    private lateinit var liveEffectButton: Button\n",
    "    private lateinit var liveEffectButton: Button\n"
    "    private lateinit var liveColorButton: Button\n",
    "LIVE color button field"
)

live = replace_once(
    live,
    '''    private var liveAutoViewSummary = "AUTO VIEW • analysing scene"
''',
    '''    private var liveAutoViewSummary = "AUTO VIEW • analysing scene"
    private var lastV229LiveColorMonitorKey = ""
    private var v229LiveColorOverlayLabel = "AUTO"
''',
    "LIVE color state"
)

live_color_button = '''        liveColorButton =
            liveSettingButton(
                "COLOR ▾\\n${v229LiveColorDeckLabel()}",
                0xFFA793D8.toInt()
            ) {
                showV229LiveColorDropdown(
                    liveColorButton
                )
            }

'''

live = insert_before(
    live,
    "        liveSafeInfoButton =\n",
    live_color_button,
    "LIVE color button creation"
)

live = replace_once(
    live,
    '''            liveHudBackingButton,
            liveEffectButton,
            liveSafeInfoButton
''',
    '''            liveHudBackingButton,
            liveEffectButton,
            liveColorButton,
            liveSafeInfoButton
''',
    "LIVE color output row"
)

live_helpers = (PAYLOAD / "live_v229_helpers.txt").read_text(encoding="utf-8")
live = insert_before(
    live,
    "    private fun showLivePillDropdown(\n",
    live_helpers,
    "LIVE color helpers"
)

live = replace_once(
    live,
    '''    private fun updateSignals() {
        updateLiveModePreviewTuning()
''',
    '''    private fun updateSignals() {
        refreshV229LiveColorMonitor()
        updateLiveModePreviewTuning()
''',
    "LIVE color monitor refresh"
)

# Package has already been scheduled when this QC block runs.
live = replace_once(
    live,
    '''                        if (
                            !event.hasError()
                        ) {
                            DevelopUgandaClipQc.inspect(
''',
    '''                        if (
                            !event.hasError()
                        ) {
                            scheduleV229LiveColorMaster(
                                event.outputResults.outputUri,
                                liveRecordingName.ifBlank {
                                    "LIVE_${System.currentTimeMillis()}"
                                }
                            )

                            DevelopUgandaClipQc.inspect(
''',
    "LIVE color master scheduling"
)

live = replace_once(
    live,
    '''            statusParts.add(
                "LOOK • ${liveEffectLabels[liveEffectIndex]}"
            )
''',
    '''            statusParts.add(
                "LOOK • ${liveEffectLabels[liveEffectIndex]}"
            )

            statusParts.add(
                "COLOR • $v229LiveColorOverlayLabel"
            )
''',
    "LIVE saved color label"
)

live = live.replace(
    '''            statusParts.add(
                "V228"
            )''',
    '''            statusParts.add(
                "V229"
            )''',
    1
)

LIVE.write_text(live, encoding="utf-8")

# ---------------------------------------------------------------------------
# Story Package — add COLOR_MASTER output, status and real profile metadata.
# ---------------------------------------------------------------------------
packager = PACKAGER.read_text(encoding="utf-8")

color_status_init = '''                writeText(
                    appContext,
                    relative,
                    "COLOR_MASTER_STATUS.txt",
                    "WAITING • V229 color engine will resolve the selected profile after the original Story Package is ready"
                )

'''

packager = insert_before(
    packager,
    '''                writeText(
                    appContext,
                    relative,
                    "TRANSCRIPT_STATUS.txt",
''',
    color_status_init,
    "Story Package initial color status"
)

packager = replace_once(
    packager,
    '''                                    "SOCIAL_MASTER_STATUS.txt",
                                    "TRANSCRIPT_STATUS.txt"
''',
    '''                                    "SOCIAL_MASTER_STATUS.txt",
                                    "COLOR_MASTER.mp4",
                                    "COLOR_MASTER_STATUS.txt",
                                    "COLOR_PROFILE.json",
                                    "TRANSCRIPT_STATUS.txt"
''',
    "Story Package color manifest files"
)

color_methods = r'''    fun markColorMasterBuilding(
        context: Context,
        packageId: String,
        profileLabel: String,
        strength: Int
    ) {
        val appContext = context.applicationContext
        executor.execute {
            val safeId = safeSegment(packageId)
            val relative = packageRelativePath(safeId)
            try {
                writeText(
                    appContext,
                    relative,
                    "COLOR_MASTER_STATUS.txt",
                    "BUILDING • $profileLabel • STRENGTH ${strength}% • ORIGINAL VIDEO REMAINS SAFE"
                )
            } catch (_: Exception) {
            }
        }
    }

    fun attachColorMaster(
        context: Context,
        packageId: String,
        colorUri: Uri,
        profileLabel: String,
        strength: Int,
        width: Int?,
        height: Int?,
        durationMs: Long?,
        bitrate: Long?
    ) {
        val appContext = context.applicationContext
        executor.execute {
            val safeId = safeSegment(packageId)
            val relative = packageRelativePath(safeId)

            try {
                val copy = copyUriToPackage(
                    appContext,
                    colorUri,
                    relative,
                    "COLOR_MASTER.mp4",
                    "video/mp4"
                )

                val hash = sha256OfUri(
                    appContext,
                    copy
                )

                writeJson(
                    appContext,
                    relative,
                    "COLOR_PROFILE.json",
                    JSONObject()
                        .put("engine", "develop.uganda V229 Professional Color Engine")
                        .put("profile_label", profileLabel)
                        .put("strength_percent", strength)
                        .put("master_file", "COLOR_MASTER.mp4")
                        .put("gallery_uri", colorUri.toString())
                        .put("package_copy_uri", copy.toString())
                        .put("width", width ?: JSONObject.NULL)
                        .put("height", height ?: JSONObject.NULL)
                        .put("duration_ms", durationMs ?: JSONObject.NULL)
                        .put("bitrate", bitrate ?: JSONObject.NULL)
                        .put("sha256", hash ?: JSONObject.NULL)
                        .put("lut_pipeline", "Media3 SingleColorLut 17^3")
                        .put("output_codec", "H.264/AAC")
                        .put(
                            "note",
                            "The original CameraX recording is preserved unchanged. The Color Master is a separate rendered delivery copy."
                        )
                        .put("generated_utc", Instant.now().toString())
                )

                writeText(
                    appContext,
                    relative,
                    "COLOR_MASTER_STATUS.txt",
                    "READY • COLOR_MASTER.mp4 • $profileLabel • ${strength}% • SHA-256 ${hash ?: "unavailable"}"
                )

                updateRegistryState(
                    appContext,
                    safeId,
                    "READY • COLOR MASTER"
                )

                showToast(
                    appContext,
                    "Story Package updated • V229 color master attached"
                )
            } catch (e: Exception) {
                markColorMasterFailed(
                    appContext,
                    safeId,
                    e.javaClass.simpleName
                )
            }
        }
    }

    fun markColorMasterSkipped(
        context: Context,
        packageId: String,
        reason: String
    ) {
        val appContext = context.applicationContext
        executor.execute {
            val safeId = safeSegment(packageId)
            val relative = packageRelativePath(safeId)
            try {
                writeText(
                    appContext,
                    relative,
                    "COLOR_MASTER_STATUS.txt",
                    "NOT REQUESTED • $reason"
                )
            } catch (_: Exception) {
            }
        }
    }

    fun markColorMasterFailed(
        context: Context,
        packageId: String,
        reason: String
    ) {
        val appContext = context.applicationContext
        executor.execute {
            val safeId = safeSegment(packageId)
            val relative = packageRelativePath(safeId)
            try {
                writeText(
                    appContext,
                    relative,
                    "COLOR_MASTER_STATUS.txt",
                    "FAILED • $reason • ORIGINAL VIDEO REMAINS SAFE"
                )
                updateRegistryState(
                    appContext,
                    safeId,
                    "READY • COLOR MASTER FAILED"
                )
            } catch (_: Exception) {
            }
        }
    }

'''

packager = insert_before(
    packager,
    "    fun attachSocialMaster(\n",
    color_methods,
    "Story Package color methods"
)

packager = packager.replace('"V228"', '"V229"')
packager = packager.replace("AUTO STORY PACKAGE • V228", "AUTO STORY PACKAGE • V229")
PACKAGER.write_text(packager, encoding="utf-8")

# ---------------------------------------------------------------------------
# Instant Review — Color Master becomes a first-class post-record action.
# ---------------------------------------------------------------------------
review = REVIEW.read_text(encoding="utf-8")

color_review_row = '''        val colorRow =
            row(
                context
            )

        colorRow.addView(
            button(
                context,
                "COLOR MASTER"
            ) {
                val color =
                    DevelopUgandaStoryPackager
                        .findPackageFile(
                            context,
                            packageId,
                            "COLOR_MASTER.mp4"
                        )

                if (
                    color !=
                        null
                ) {
                    play(
                        context,
                        color,
                        "V229 COLOR MASTER"
                    )
                } else {
                    toast(
                        context,
                        "V229 Color Master is still preparing, ORIGINAL was selected, or export was unavailable"
                    )
                }
            },
            weight()
        )

        colorRow.addView(
            button(
                context,
                "COLOR STUDIO"
            ) {
                context.startActivity(
                    Intent(
                        context,
                        DevelopUgandaColorStudioActivity::class.java
                    )
                )
            },
            weight(
                dp(
                    context,
                    6
                )
            )
        )

        panel.addView(
            colorRow
        )

'''

review = insert_before(
    review,
    '''        if (
            onMatchLastShot !=
''',
    color_review_row,
    "Instant Review color row"
)

review = review.replace("develop.uganda • V228 REVIEW", "develop.uganda • V229 REVIEW")
review = review.replace("current V228 burn-in profile", "current V229 burn-in profile")
REVIEW.write_text(review, encoding="utf-8")

# ---------------------------------------------------------------------------
# Brand credit follows the app build, but the v228 preference key stays intact
# so no saved user brand/tag settings are lost.
# ---------------------------------------------------------------------------
brand = BRAND.read_text(encoding="utf-8")
brand = replace_once(
    brand,
    '"Recorded with develop.uganda • V228"',
    '"Recorded with develop.uganda • V229"',
    "Brand credit V229"
)
BRAND.write_text(brand, encoding="utf-8")

# ---------------------------------------------------------------------------
# HOME — first-class V229 Color Studio while every older camera remains.
# ---------------------------------------------------------------------------
home = HOME.read_text(encoding="utf-8")

home = replace_once(
    home,
    '''                "BRAND & METADATA STUDIO • V228\\nV227 DIRECTOR/QC + V226 FIX2 NEWSROOM RETAINED",''',
    '''                "PROFESSIONAL COLOR ENGINE • V229\\nV228 BRAND/METADATA + V227 DIRECTOR/QC RETAINED",''',
    "Home V229 header"
)

v228_card = '''        page.addView(
            launchCard(
                "V228 • BRAND & METADATA",
                "Make the camera yours without losing the professional system",
                "Change the main saved-video name • optional organization • choose exactly which telemetry is visibly burned into NEW recordings • privacy-aware PUBLIC/SOCIAL profile • VERIFIED MASTER defaults to the full V227 experience",
                0xFFD0B06F.toInt(),
                "OPEN BRAND & TAG STUDIO"
            ) {
                openIndependentCamera(
                    DevelopUgandaBrandMetadataActivity::class.java
                )
            }
        )

'''

v229_home = v228_card + '''        page.addView(
            compactStatus(
                "V229 • PROFESSIONAL COLOR ENGINE",
                "ORIGINAL VIDEO ALWAYS PRESERVED • REAL MEDIA3 SingleColorLut 17³ COLOR MASTER • AUTO BY CAMERA/SCENE • 13 ORIGINAL DU COLOR PROFILES • OPTIONAL MONITOR APPROXIMATION • STORY PACKAGE COLOR_PROFILE.json",
                0xFFA793D8.toInt()
            )
        )

        page.addView(
            launchCard(
                "V229 • PROFESSIONAL COLOR",
                "Professional color without pretending a phone sensor is an ARRI / RED / Sony cinema sensor",
                "DU CINEMA NATURAL • COOL CINEMA • FILM BIAS • EXTENDED VIDEO • SOFT FILM • WARM 709 • NIGHT CINEMA • BLEACH DRAMA • GOLDEN HOUR • CLEAN SOCIAL • CONSTRUCTION • PEOPLE • MONO CINEMA • real separate COLOR_MASTER.mp4",
                0xFFA793D8.toInt(),
                "OPEN COLOR STUDIO"
            ) {
                openIndependentCamera(
                    DevelopUgandaColorStudioActivity::class.java
                )
            }
        )

'''

home = replace_once(
    home,
    v228_card,
    v229_home,
    "Home V229 color card"
)
HOME.write_text(home, encoding="utf-8")

# ---------------------------------------------------------------------------
# Manifest / build identity.
# ---------------------------------------------------------------------------
manifest = MANIFEST.read_text(encoding="utf-8")
brand_activity = '''        <activity
            android:name=".DevelopUgandaBrandMetadataActivity"
            android:screenOrientation="portrait"
            android:exported="false"/>

'''
manifest = replace_once(
    manifest,
    brand_activity,
    brand_activity + '''        <activity
            android:name=".DevelopUgandaColorStudioActivity"
            android:screenOrientation="portrait"
            android:exported="false"/>

''',
    "Manifest V229 Color Studio"
)
MANIFEST.write_text(manifest, encoding="utf-8")

gradle = re.sub(
    r"versionCode\s*=\s*\d+",
    "versionCode = 22900",
    gradle,
    count=1
)
gradle = re.sub(
    r'versionName\s*=\s*"[^"]+"',
    'versionName = "229.0-professional-color-engine"',
    gradle,
    count=1
)
GRADLE.write_text(gradle, encoding="utf-8")

print("V229 Professional Color Engine applied.")
