from pathlib import Path
import shutil

ROOT = Path("v172-source/app")
SRC = ROOT / "src/main/java/com/sentongoharuna/pulse"

REPORT = SRC / "DevelopUgandaCameraActivity.kt"
LIVE = SRC / "DevelopUgandaLiveActivity.kt"
HOME = SRC / "DevelopUgandaNewsroomActivity.kt"
PACKAGER = SRC / "DevelopUgandaStoryPackager.kt"
REVIEW = SRC / "DevelopUgandaInstantReviewDialog.kt"
BRAND = SRC / "DevelopUgandaBrandMetadataStore.kt"
GRADLE = ROOT / "build.gradle.kts"
PAYLOAD = Path(__file__).resolve().parent


def require(text: str, needle: str, label: str):
    if needle not in text:
        raise SystemExit(f"V231 base check failed: {label} missing: {needle}")


def replace_required(text: str, old: str, new: str, label: str, count: int = 1):
    if old not in text:
        raise SystemExit(f"V231 anchor missing: {label}: {old}")
    return text.replace(old, new, count)


# ---------------------------------------------------------------------------
# Require the proven V230 base. V231 extends only the color studio/recipe
# layer and visible version metadata. CameraX bind engines remain untouched.
# ---------------------------------------------------------------------------
gradle = GRADLE.read_text(encoding="utf-8")
require(gradle, "versionCode = 23000", "V230 versionCode")
require(gradle, 'versionName = "230.0-cinema-color-engine-2"', "V230 versionName")

for path in [REPORT, LIVE, HOME, PACKAGER, REVIEW, BRAND]:
    if not path.exists():
        raise SystemExit(f"V231 required source missing: {path}")

engine_path = SRC / "DevelopUgandaColorEngine.kt"
studio_path = SRC / "DevelopUgandaColorStudioActivity.kt"
tuner_path = SRC / "DevelopUgandaColorTuner.kt"

if not engine_path.exists() or not studio_path.exists():
    raise SystemExit("V231 requires the V230 Cinema Color Engine 2.0 files")

old_engine = engine_path.read_text(encoding="utf-8")
for needle in [
    "DU URBAN TEAL",
    "DU GOLDEN CITY",
    "DU STEEL + FIRE",
    "DU DEEP SPACE",
    "SingleColorLut.createFromCube",
    "DEVELOP_UGANDA_V230_",
]:
    require(old_engine, needle, "V230 color engine")

# Replace the color engine/studio and add the palette tuner.
shutil.copyfile(PAYLOAD / "DevelopUgandaColorEngine.kt", engine_path)
shutil.copyfile(PAYLOAD / "DevelopUgandaColorStudioActivity.kt", studio_path)
shutil.copyfile(PAYLOAD / "DevelopUgandaColorTuner.kt", tuner_path)

# ---------------------------------------------------------------------------
# Visible V231 integration. Internal v229/v230 helper names are deliberately
# retained where they are already part of the proven recording pipeline.
# ---------------------------------------------------------------------------
report = REPORT.read_text(encoding="utf-8")
require(report, "ACTION_COLOR_ENGINE", "REPORT color integration")
require(report, "scheduleV229ColorMaster", "REPORT color scheduling")
report = report.replace("V230", "V231")
REPORT.write_text(report, encoding="utf-8")

live = LIVE.read_text(encoding="utf-8")
require(live, "liveColorButton", "LIVE color integration")
require(live, "scheduleV229LiveColorMaster", "LIVE color scheduling")
live = live.replace("V230", "V231")
LIVE.write_text(live, encoding="utf-8")

home = HOME.read_text(encoding="utf-8")
require(home, "V230 • CINEMA COLOR ENGINE 2.0", "V230 home module label")
home = home.replace(
    "V230 • CINEMA COLOR ENGINE 2.0",
    "V231 • UGANDA SCENE COLOR LAB"
)
home = home.replace("V230", "V231")
HOME.write_text(home, encoding="utf-8")

packager = PACKAGER.read_text(encoding="utf-8")
require(packager, "COLOR_MASTER.mp4", "Story Package color master")
require(packager, "COLOR_PROFILE.json", "Story Package color profile")
packager = packager.replace("V230", "V231")
packager = packager.replace(
    "Cinema Color Engine 2.0",
    "Uganda Scene Color Lab"
)
PACKAGER.write_text(packager, encoding="utf-8")

review = REVIEW.read_text(encoding="utf-8")
require(review, '"COLOR MASTER"', "Instant Review color master")
require(review, '"COLOR STUDIO"', "Instant Review color studio")
review = review.replace("V230", "V231")
REVIEW.write_text(review, encoding="utf-8")

brand = BRAND.read_text(encoding="utf-8")
require(brand, "Recorded with develop.uganda • V230", "V230 brand credit")
brand = brand.replace(
    "Recorded with develop.uganda • V230",
    "Recorded with develop.uganda • V231"
)
BRAND.write_text(brand, encoding="utf-8")

# App version.
gradle = replace_required(
    gradle,
    "versionCode = 23000",
    "versionCode = 23100",
    "versionCode"
)
gradle = replace_required(
    gradle,
    'versionName = "230.0-cinema-color-engine-2"',
    'versionName = "231.0-uganda-scene-color-lab"',
    "versionName"
)
GRADLE.write_text(gradle, encoding="utf-8")

print("PASS: V231 Uganda Scene Color Lab patch applied.")
print("PASS: V230 real 17^3 LUT engine retained and extended with 5-color tuning.")
print("PASS: CameraX / social / story / brand architecture retained.")
