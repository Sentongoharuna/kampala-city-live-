develop.uganda V231 — UGANDA SCENE COLOR LAB

WHAT V231 ADDS
• Familiar Uganda scene names with numbered variations, e.g. KAMPALA NIGHT 01 / 02.
• Five real palette swatches per LUT, each with an independent 0–200% slider.
• 100% preserves the authored V230 look; below 100 reduces that palette bias; above 100 pushes it harder.
• Per-color tuning is stored independently for each camera scope and each LUT.
• Master LUT strength now runs 0–100% for very subtle grades.
• COLOR_PROFILE.json records the scene name and all five palette control values.
• The real saved COLOR_MASTER.mp4 is generated from a 17^3 Media3 SingleColorLut.

UGANDA SCENE LUT NAMES
KAMPALA NATURAL 01
CITY RAIN 01
KAMPALA FILM 01
KAMPALA STREET 01
NAKASERO GOLD 01
CLOCK TOWER STEEL 01
KISENYI AMBER 01
KAMPALA NIGHT 01
WAKISO GREEN 01
KAMPALA NIGHT 02
KAMPALA SOCIAL 01
KAMPALA CONCRETE 01
UGANDA PEOPLE 01
CITY NIGHT 01
UGANDA DOCUMENTARY 01
KAMPALA MONO 01

PRINCIPLE PROTECTED
The original CameraX MP4 is never replaced. V231 only creates a separate color master. CameraX bind logic, social export/verification, Director/QC, Photo Suite, Brand Studio and the retained story/media systems are intentionally protected by the build workflow.

INSTALLATION
Upload this patch ZIP and BUILD-DEVELOP-UGANDA-V231-UGANDA-SCENE-COLOR-LAB.yml to the same GitHub repository that currently contains the successful V230 source, then run the V231 workflow from Actions.
