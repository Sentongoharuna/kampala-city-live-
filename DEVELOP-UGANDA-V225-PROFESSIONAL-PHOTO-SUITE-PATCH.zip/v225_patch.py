from pathlib import Path
import re
import shutil

ROOT = Path("v172-source/app")
SRC = ROOT / "src/main/java/com/sentongoharuna/pulse"
HOME = SRC / "DevelopUgandaNewsroomActivity.kt"
MANIFEST = ROOT / "src/main/AndroidManifest.xml"
GRADLE = ROOT / "build.gradle.kts"

PAYLOAD = Path(__file__).resolve().parent

def replace_once(text, old, new, label):
    if old not in text:
        raise SystemExit("V225 anchor missing: " + label)
    return text.replace(old, new, 1)

gradle = GRADLE.read_text(encoding="utf-8")

if 'versionCode = 22400' not in gradle:
    raise SystemExit("V225 expects V224 versionCode 22400")

if 'versionName = "224.0-shot-quality-guard"' not in gradle:
    raise SystemExit("V225 expects V224 Shot Quality Guard")

shutil.copyfile(
    PAYLOAD / "DevelopUgandaPhotoSuiteActivity.kt",
    SRC / "DevelopUgandaPhotoSuiteActivity.kt"
)

manifest = MANIFEST.read_text(encoding="utf-8")

manifest_anchor = (
    '        <activity\n'
    '            android:name=".DevelopUgandaCameraActivity"\n'
    '            android:screenOrientation="portrait"\n'
    '            android:exported="false"/>\n'
)

photo_activities = (
    '        <activity\n'
    '            android:name=".DevelopUgandaPhotoProCameraActivity"\n'
    '            android:screenOrientation="portrait"\n'
    '            android:exported="false"/>\n\n'
    '        <activity\n'
    '            android:name=".DevelopUgandaBuildingPhotoCameraActivity"\n'
    '            android:screenOrientation="portrait"\n'
    '            android:exported="false"/>\n\n'
    '        <activity\n'
    '            android:name=".DevelopUgandaPeoplePhotoCameraActivity"\n'
    '            android:screenOrientation="portrait"\n'
    '            android:exported="false"/>\n\n'
    '        <activity\n'
    '            android:name=".DevelopUgandaNightPhotoCameraActivity"\n'
    '            android:screenOrientation="portrait"\n'
    '            android:exported="false"/>\n\n'
    '        <activity\n'
    '            android:name=".DevelopUgandaVerifiedPhotoCameraActivity"\n'
    '            android:screenOrientation="portrait"\n'
    '            android:exported="false"/>\n\n'
)

if ".DevelopUgandaPhotoProCameraActivity" not in manifest:
    manifest = replace_once(
        manifest,
        manifest_anchor,
        photo_activities +
        manifest_anchor,
        "photo manifest activities"
    )

MANIFEST.write_text(
    manifest,
    encoding="utf-8"
)

home = HOME.read_text(encoding="utf-8")

top_old = (
    '"SHOT QUALITY GUARD • V224\\n'
    'ALL CAMERAS + AUTO VIEW RETAINED"'
)

if top_old in home:
    home = home.replace(
        top_old,
        '"PROFESSIONAL PHOTO SUITE • V225\\nVIDEO CAMERAS + V224 GUARD RETAINED"',
        1
    )

capture_section = (
    "        page.addView(\n"
    "            sectionTitle(\n"
    '                "CAPTURE MODES"\n'
    "            )\n"
    "        )\n"
)

photo_section = r'''        page.addView(
            sectionTitle(
                "PROFESSIONAL PHOTO CAMERAS • V225"
            )
        )

        page.addView(
            compactStatus(
                "CAPABILITY-AWARE STILL PHOTOGRAPHY",
                "ONLY FORMATS THE SELECTED LENS REPORTS AS SUPPORTED ARE SHOWN • JPEG • ULTRA HDR JPEG_R • RAW DNG • RAW+JPEG • EDGE PEAK / ZEBRA REMAIN SCREEN-ONLY",
                0xFFD0B06F.toInt()
            )
        )

        page.addView(
            launchCard(
                "V225 • PHOTO PRO",
                "General professional still photography",
                "Maximum-quality CameraX ImageCapture • tap focus • capability-aware JPEG / Ultra HDR / RAW DNG / RAW+JPEG selector • level guide • edge peak / zebra operator assist",
                0xFFD0B06F.toInt(),
                "OPEN PHOTO PRO"
            ) {
                openIndependentCamera(
                    DevelopUgandaPhotoProCameraActivity::class.java
                )
            }
        )

        page.addView(
            launchCard(
                "V225 • BUILDING PHOTO",
                "Architecture • rooms • property • straight lines",
                "Level guide emphasized • Ultra HDR preferred only when this lens reports support • otherwise JPEG fallback • maximum-quality capture • RAW options remain selectable when supported",
                green,
                "OPEN BUILDING PHOTO"
            ) {
                openIndependentCamera(
                    DevelopUgandaBuildingPhotoCameraActivity::class.java
                )
            }
        )

        page.addView(
            launchCard(
                "V225 • PEOPLE PHOTO",
                "People • portraits • interview stills",
                "Tap-to-focus with CameraX focus confirmation • maximum-quality JPEG default • RAW/HDR choices appear only if the device supports them • peaking optional",
                gold,
                "OPEN PEOPLE PHOTO"
            ) {
                openIndependentCamera(
                    DevelopUgandaPeoplePhotoCameraActivity::class.java
                )
            }
        )

        page.addView(
            launchCard(
                "V225 • NIGHT PHOTO",
                "Night • dark rooms • low-light stills",
                "CameraX MAXIMIZE_QUALITY • flash OFF by default • no fake Nightography claim • device-supported RAW/HDR formats remain selectable • zebra/peaking available",
                0xFF8A86B8.toInt(),
                "OPEN NIGHT PHOTO"
            ) {
                openIndependentCamera(
                    DevelopUgandaNightPhotoCameraActivity::class.java
                )
            }
        )

        page.addView(
            launchCard(
                "V225 • VERIFIED PHOTO",
                "Inspections • site records • evidence-style stills",
                "JPEG maximum quality • filename identifies VERIFIED PHOTO • metadata JSON includes capture time/GPS/camera • SHA-256 integrity sidecar detects later file changes without claiming authorship",
                0xFF73B7D9.toInt(),
                "OPEN VERIFIED PHOTO"
            ) {
                openIndependentCamera(
                    DevelopUgandaVerifiedPhotoCameraActivity::class.java
                )
            }
        )

'''

if (
    "OPEN PHOTO PRO"
    not in home
):
    home = replace_once(
        home,
        capture_section,
        photo_section +
        capture_section,
        "photo home section"
    )

HOME.write_text(
    home,
    encoding="utf-8"
)

gradle = re.sub(
    r"versionCode\s*=\s*\d+",
    "versionCode = 22500",
    gradle,
    count=1
)

gradle = re.sub(
    r'versionName\s*=\s*"[^"]+"',
    'versionName = "225.0-professional-photo-suite"',
    gradle,
    count=1
)

GRADLE.write_text(
    gradle,
    encoding="utf-8"
)

print("V225 Professional Photo Suite applied.")
