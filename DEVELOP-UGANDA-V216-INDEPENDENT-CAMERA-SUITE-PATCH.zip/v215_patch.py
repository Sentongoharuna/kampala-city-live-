from pathlib import Path
import re

ROOT = Path("v172-source/app")
REPORT = ROOT / "src/main/java/com/sentongoharuna/pulse/DevelopUgandaCameraActivity.kt"
LIVE = ROOT / "src/main/java/com/sentongoharuna/pulse/DevelopUgandaLiveActivity.kt"
HOME = ROOT / "src/main/java/com/sentongoharuna/pulse/DevelopUgandaNewsroomActivity.kt"
GRADLE = ROOT / "build.gradle.kts"

def must_replace(text, old, new, label):
    if old not in text:
        raise SystemExit(f"V215 patch anchor missing: {label}")
    return text.replace(old, new, 1)

report = REPORT.read_text(encoding="utf-8")

# V215 Smart Auto Director Pro: real sensor-driven REPORT profile switching.
report = must_replace(
    report,
    '''        const val ACTION_HUD_BACKING = 21
''',
    '''        const val ACTION_HUD_BACKING = 21
        const val ACTION_AUTO_DIRECTOR = 22
''',
    "REPORT auto director action",
)

report = must_replace(
    report,
    '''    private lateinit var reportPresetButton: Button
    private lateinit var reportDisplayRow: LinearLayout
''',
    '''    private lateinit var reportPresetButton: Button
    private lateinit var autoDirectorButton: Button
    private lateinit var reportDisplayRow: LinearLayout
''',
    "REPORT auto director button field",
)

report = must_replace(
    report,
    '''    private var reportPresetIndex = 0

    private val reportHudLabels =
''',
    '''    private var reportPresetIndex = 0

    private var autoDirectorEnabled = false
    private var autoDirectorLastSwitchMs = 0L
    private var autoDirectorReason = "MANUAL"

    private val reportHudLabels =
''',
    "REPORT auto director state",
)

report = must_replace(
    report,
    '''        listOf(
            hudContrastButton,
            hudBackingButton,
            reportPresetButton
        ).forEachIndexed { index, button ->
''',
    '''        autoDirectorButton =
            deckButton(
                "AUTO DIRECTOR ▾\\n" +
                    if (
                        autoDirectorEnabled
                    ) {
                        "ON"
                    } else {
                        "OFF"
                    },
                0xFF73B7D9.toInt()
            ).apply {
                isSelected =
                    autoDirectorEnabled
            }

        listOf(
            hudContrastButton,
            hudBackingButton,
            reportPresetButton,
            autoDirectorButton
        ).forEachIndexed { index, button ->
''',
    "REPORT auto director control",
)

report = must_replace(
    report,
    '''        reportPresetButton.setOnTouchListener(
            DeckTouchListener(ACTION_REPORT_PRESET)
        )

        lensButton.setOnTouchListener(
''',
    '''        reportPresetButton.setOnTouchListener(
            DeckTouchListener(ACTION_REPORT_PRESET)
        )

        autoDirectorButton.setOnTouchListener(
            DeckTouchListener(ACTION_AUTO_DIRECTOR)
        )

        lensButton.setOnTouchListener(
''',
    "REPORT auto director touch",
)

report = must_replace(
    report,
    '''                        ACTION_REPORT_PRESET ->
                            showReportPresetDropdown(
                                v ?: reportPresetButton
                            )

                        ACTION_LENS ->
''',
    '''                        ACTION_REPORT_PRESET ->
                            showReportPresetDropdown(
                                v ?: reportPresetButton
                            )

                        ACTION_AUTO_DIRECTOR ->
                            toggleAutoDirector()

                        ACTION_LENS ->
''',
    "REPORT auto director dispatch",
)

report = must_replace(
    report,
    '''    private fun previewLookTintColor(): Int {
''',
    '''    private fun autoDirectorSuggestedMode(): Pair<String, String> {
        if (
            isThermalSevereOrWorse()
        ) {
            return Pair(
                "SOCIAL FHD",
                "THERMAL SAFE"
            )
        }

        val lux =
            ambientLux

        if (
            lux != null &&
            lux < 25f
        ) {
            return Pair(
                "LOW LIGHT",
                "DARK SCENE"
            )
        }

        if (
            cameraShakeScore > 22f &&
            (
                lux == null ||
                lux >= 100f
            )
        ) {
            return Pair(
                "ACTION STAB",
                "HANDHELD MOTION"
            )
        }

        if (
            lux != null &&
            lux >= 500f &&
            cameraShakeScore <= 8f
        ) {
            return Pair(
                "SOCIAL 60",
                "BRIGHT + STEADY"
            )
        }

        return Pair(
            "SOCIAL FHD",
            "BALANCED"
        )
    }

    private fun autoDirectorStateText(): String {
        if (!autoDirectorEnabled) {
            return "AUTO MANUAL"
        }

        val suggestion =
            autoDirectorSuggestedMode()

        return "AUTO ${suggestion.first} • ${suggestion.second}"
    }

    private fun toggleAutoDirector() {
        if (
            recording != null
        ) {
            toast(
                "Stop recording before changing Auto Director"
            )
            return
        }

        autoDirectorEnabled =
            !autoDirectorEnabled

        autoDirectorButton.text =
            "AUTO DIRECTOR ▾\\n" +
                if (
                    autoDirectorEnabled
                ) {
                    "ON"
                } else {
                    "OFF"
                }

        autoDirectorButton.isSelected =
            autoDirectorEnabled

        autoDirectorReason =
            if (
                autoDirectorEnabled
            ) {
                autoDirectorSuggestedMode().second
            } else {
                "MANUAL"
            }

        saveReportCameraPreferences()

        toast(
            if (
                autoDirectorEnabled
            ) {
                "AUTO DIRECTOR ON • ${autoDirectorStateText()}"
            } else {
                "AUTO DIRECTOR OFF • manual camera mode"
            }
        )

        if (
            autoDirectorEnabled
        ) {
            applyAutoDirectorIfNeeded(
                force = true
            )
        }
    }

    private fun applyAutoDirectorIfNeeded(
        force: Boolean = false
    ) {
        if (
            !autoDirectorEnabled ||
            recording != null
        ) {
            return
        }

        val (targetMode, reason) =
            autoDirectorSuggestedMode()

        autoDirectorReason =
            reason

        val now =
            SystemClock.elapsedRealtime()

        if (
            !force &&
            now - autoDirectorLastSwitchMs < 3500L
        ) {
            return
        }

        val targetIndex =
            qualityModes.indexOf(
                targetMode
            )

        if (
            targetIndex < 0 ||
            targetIndex == qualityIndex
        ) {
            return
        }

        qualityIndex =
            targetIndex

        autoDirectorLastSwitchMs =
            now

        if (
            ::qualityButton.isInitialized
        ) {
            qualityButton.text =
                "FORMAT ▾\\n${qualityDeckLabel()}"
        }

        saveReportCameraPreferences()

        toast(
            "AUTO DIRECTOR • $targetMode • $reason"
        )

        bindCamera()
    }

    private fun previewLookTintColor(): Int {
''',
    "REPORT auto director logic",
)

report = must_replace(
    report,
    '''    private fun refreshHud() {
        updateReportModePreviewTuning()
''',
    '''    private fun refreshHud() {
        applyAutoDirectorIfNeeded()
        updateReportModePreviewTuning()
''',
    "REPORT run auto director",
)

report = must_replace(
    report,
    '''            previewTagView.text =
                "${sceneTag()} • ${reportModePurposeLabel()} • ${lookModes[lookIndex]} • V214"
''',
    '''            previewTagView.text =
                "${sceneTag()} • ${reportModePurposeLabel()} • ${lookModes[lookIndex]} • ${autoDirectorStateText()} • V215"
''',
    "REPORT V215 preview tag",
)

report = report.replace(
    'append("V214 VERIFIED")',
    'append("V215 VERIFIED")',
    1,
)

report = must_replace(
    report,
    '''            append(" • THERMAL ")
            append(
                thermalStateLabel()
            )
        }
    }
''',
    '''            append(" • THERMAL ")
            append(
                thermalStateLabel()
            )
            append(" • ")
            append(
                autoDirectorStateText()
            )
        }
    }
''',
    "REPORT verified Auto Director state",
)

report = report.replace(
    '"develop.uganda • V214"',
    '"develop.uganda • V215"',
    1,
)

report = must_replace(
    report,
    '''            "${sceneTag()} • V214",
''',
    '''            "${sceneTag()} • V215",
''',
    "REPORT recorded V215 tag",
)

report = must_replace(
    report,
    '''            "$recState   |   TC ${tc()}   |   V214   |   THERM ${thermalStateLabel()}",
''',
    '''            "$recState   |   TC ${tc()}   |   V215   |   THERM ${thermalStateLabel()}",
''',
    "REPORT recorded V215 identity",
)

report = must_replace(
    report,
    '''            "MODE • ${qualityModes[qualityIndex]}   |   ${reportModePurposeLabel()}   |   SCENE • ${sceneModes[sceneIndex]}   |   LOOK • ${lookModes[lookIndex]}",
''',
    '''            "MODE • ${qualityModes[qualityIndex]}   |   ${reportModePurposeLabel()}   |   SCENE • ${sceneModes[sceneIndex]}   |   LOOK • ${lookModes[lookIndex]}   |   ${autoDirectorStateText()}",
''',
    "REPORT recorded Auto Director state",
)

report = must_replace(
    report,
    '''        reportPresetIndex =
            prefs.getInt(
                "preset_index",
                reportPresetIndex
            )
                .coerceIn(
                    0,
                    reportPresetLabels.lastIndex
                )

        previewGuidesEnabled =
''',
    '''        reportPresetIndex =
            prefs.getInt(
                "preset_index",
                reportPresetIndex
            )
                .coerceIn(
                    0,
                    reportPresetLabels.lastIndex
                )

        autoDirectorEnabled =
            prefs.getBoolean(
                "auto_director",
                autoDirectorEnabled
            )

        previewGuidesEnabled =
''',
    "REPORT load Auto Director pref",
)

report = must_replace(
    report,
    '''            .putInt(
                "preset_index",
                reportPresetIndex
            )
            .putBoolean(
                "guides",
''',
    '''            .putInt(
                "preset_index",
                reportPresetIndex
            )
            .putBoolean(
                "auto_director",
                autoDirectorEnabled
            )
            .putBoolean(
                "guides",
''',
    "REPORT save Auto Director pref",
)

report = report.replace(
    '"DEVELOP_UGANDA_V214_${reportId}_${sceneModes[sceneIndex]}_${lookModes[lookIndex]}_"',
    '"DEVELOP_UGANDA_V215_${reportId}_${sceneModes[sceneIndex]}_${lookModes[lookIndex]}_"',
    1,
)

report = must_replace(
    report,
    '''        val modePurposeSnapshot =
            reportModePurposeLabel()

        val sceneSnapshot =
''',
    '''        val modePurposeSnapshot =
            reportModePurposeLabel()

        val autoDirectorSnapshot =
            autoDirectorStateText()

        val sceneSnapshot =
''',
    "REPORT Auto Director integrity snapshot",
)

report = report.replace(
    '''                            "V214"
''',
    '''                            "V215"
''',
    1,
)

report = report.replace(
    '''                            "V214 MODE SIGNATURE PRO"
''',
    '''                            "V215 SMART AUTO DIRECTOR PRO"
''',
    1,
)

report = report.replace(
    '''                            "V204,V205,V206,V207,V208,V209,V210,V211,V212,V213,V214"
''',
    '''                            "V204,V205,V206,V207,V208,V209,V210,V211,V212,V213,V214,V215"
''',
    1,
)

report = must_replace(
    report,
    '''                        put(
                            "mode_purpose",
                            modePurposeSnapshot
                        )
                        put(
                            "scene",
''',
    '''                        put(
                            "mode_purpose",
                            modePurposeSnapshot
                        )
                        put(
                            "auto_director",
                            autoDirectorSnapshot
                        )
                        put(
                            "scene",
''',
    "REPORT integrity Auto Director",
)

REPORT.write_text(report, encoding="utf-8")

# LIVE remains manual-safe while on air, but carries V215 identity.
live = LIVE.read_text(encoding="utf-8")

live = live.replace(
    '"develop.uganda • V214"',
    '"develop.uganda • V215"',
    1,
)

live = live.replace(
    'append("V214 VERIFIED")',
    'append("V215 VERIFIED")',
    1,
)

live = must_replace(
    live,
    '''                "LIVE STUDIO • ${profiles[profileIndex]} • ${liveQualityProfiles[liveQualityIndex]} • LOOK ${liveEffectLabels[liveEffectIndex]} • V214"
''',
    '''                "LIVE STUDIO • ${profiles[profileIndex]} • ${liveQualityProfiles[liveQualityIndex]} • LOOK ${liveEffectLabels[liveEffectIndex]} • MANUAL LIVE • V215"
''',
    "LIVE V215 subtitle",
)

live = must_replace(
    live,
    '''            "develop.uganda • V214",
''',
    '''            "develop.uganda • V215",
''',
    "LIVE V215 recorded brand",
)

live = must_replace(
    live,
    '''            "${if (liveOn) "ON AIR" else "READY"}   |   TIMECODE • ${liveTimecode()}   |   MODE • ${liveQualityProfiles[liveQualityIndex]}   |   LOOK • ${liveEffectLabels[liveEffectIndex]}   |   V214   |   THERMAL • ${liveThermalStateLabel()}",
''',
    '''            "${if (liveOn) "ON AIR" else "READY"}   |   TIMECODE • ${liveTimecode()}   |   MODE • ${liveQualityProfiles[liveQualityIndex]}   |   LOOK • ${liveEffectLabels[liveEffectIndex]}   |   MANUAL LIVE   |   V215   |   THERMAL • ${liveThermalStateLabel()}",
''',
    "LIVE V215 recorded exact mode",
)

live = must_replace(
    live,
    '''            "REPORTER • $reporterName   |   STORY • $storyId   |   develop.uganda • V214",
''',
    '''            "REPORTER • $reporterName   |   STORY • $storyId   |   develop.uganda • V215",
''',
    "LIVE V215 footer",
)

live = live.replace(
    '"DEVELOP_UGANDA_V214_LIVE_${profiles[profileIndex]}_$stamp"',
    '"DEVELOP_UGANDA_V215_LIVE_${profiles[profileIndex]}_$stamp"',
    1,
)

LIVE.write_text(live, encoding="utf-8")

# Home module hub keeps everything and appends V215.
home = HOME.read_text(encoding="utf-8")

home = home.replace(
    '"MODE SIGNATURE PRO • V214"',
    '"SMART AUTO DIRECTOR PRO • V215"',
    1,
)

home = home.replace(
    '"V204→V214 ALL RETAINED • SOCIAL/HDR/4K/ACTION • AF/METER • HORIZON • STEADYSHOT • NIGHT • AUDIO • VERIFIED • THERMAL • MODE-SPECIFIC PREVIEW • 9:16 SAFE"',
    '"V204→V215 ALL RETAINED • SOCIAL/HDR/4K/ACTION • AF/METER • HORIZON • STEADYSHOT • NIGHT • AUDIO • VERIFIED • THERMAL • MODE PREVIEW • SMART AUTO DIRECTOR • 9:16 SAFE"',
    1,
)

home = home.replace(
    '"FIELD REPORT • V214 MODE-SPECIFIC OPERATOR PREVIEW • ALL V204→V213 RETAINED • REAL MODE/LOOK STATE • RECORDED MODE SIGNATURE • VERSIONED VIDEO • telemetry"',
    '"FIELD REPORT • V215 SMART AUTO DIRECTOR • ALL V204→V214 RETAINED • REAL LUX/MOTION/THERMAL INPUTS CHOOSE REAL CAMERA PROFILE • NEVER SWITCHES DURING RECORDING • telemetry"',
    1,
)

home = home.replace(
    '"✓ ALL PRO • V214"',
    '"✓ ALL PRO • V215"',
    1,
)

home = home.replace(
    '"Every camera module below remains active together. V214 gives each selected camera mode/look a distinct operator preview identity and records the exact mode, without replacing V204–V213."',
    '"Every camera module below remains active together. V215 can opt-in to real automatic REPORT profile selection using V208 motion, V209 lux and V213 thermal state, without replacing V204–V214."',
    1,
)

home = must_replace(
    home,
    '''                Triple(
                    "✓ V214 • MODE SIGNATURE PRO",
                    "Selected look gives the operator preview a subtle matching tone; quality mode gets its own accent/purpose label; REPORT/LIVE recordings burn in the exact mode and V214.",
                    cyan
                )
''',
    '''                Triple(
                    "✓ V214 • MODE SIGNATURE PRO",
                    "Selected look gives the operator preview a subtle matching tone; quality mode gets its own accent/purpose label; REPORT/LIVE recordings burn in the exact mode and V214.",
                    cyan
                ),
                Triple(
                    "✓ V215 • SMART AUTO DIRECTOR PRO",
                    "Opt-in REPORT automation uses real lux, shake and thermal states to switch the actual capture profile between Social FHD, Social 60, Action Stab and Low Light; never switches mid-recording.",
                    green
                )
''',
    "HOME append V215",
)

home = home.replace(
    '"NOTHING DROPPED • V204→V214 RETAINED • MODE PREVIEW CUES ARE TIED TO THE REAL SELECTED MODE/LOOK • RECORDED OUTPUT STATES THE EXACT MODE"',
    '"NOTHING DROPPED • V204→V215 RETAINED • AUTO DIRECTOR CHANGES THE REAL QUALITY INDEX AND REBINDS CAMERAX • ACTIVE MEANS FUNCTIONAL"',
    1,
)

HOME.write_text(home, encoding="utf-8")

gradle = GRADLE.read_text(encoding="utf-8")
gradle = re.sub(r"versionCode\s*=\s*\d+", "versionCode = 21500", gradle, count=1)
gradle = re.sub(
    r'versionName\s*=\s*"[^"]+"',
    'versionName = "215.0-smart-auto-director-pro"',
    gradle,
    count=1,
)
GRADLE.write_text(gradle, encoding="utf-8")

print("V215 Smart Auto Director Pro patch applied.")
