from pathlib import Path
import re

ROOT = Path("v172-source/app")
REPORT = ROOT / "src/main/java/com/sentongoharuna/pulse/DevelopUgandaCameraActivity.kt"
LIVE = ROOT / "src/main/java/com/sentongoharuna/pulse/DevelopUgandaLiveActivity.kt"
HOME = ROOT / "src/main/java/com/sentongoharuna/pulse/DevelopUgandaNewsroomActivity.kt"
GRADLE = ROOT / "build.gradle.kts"

def must_replace(text, old, new, label):
    if old not in text:
        raise SystemExit(f"V204 patch anchor missing: {label}")
    return text.replace(old, new, 1)

# ============================================================
# V204 SOCIAL MASTER PRO
# Adds ACTION 60 + SOCIAL HDR and clearer capability status.
# ============================================================

report = REPORT.read_text(encoding="utf-8")

report = must_replace(
    report,
    '''        "MASTER HDR",
        "ACTION STAB",
        "LOW LIGHT",
''',
    '''        "MASTER HDR",
        "SOCIAL HDR",
        "ACTION STAB",
        "ACTION 60",
        "LOW LIGHT",
''',
    "REPORT new quality modes",
)

report = must_replace(
    report,
    '''            "MASTER HDR" -> "4K HDR"
            "ACTION STAB" -> "ACTION"
            "LOW LIGHT" -> "NIGHT VIDEO"
''',
    '''            "MASTER HDR" -> "4K HDR"
            "SOCIAL HDR" -> "1080 HDR"
            "ACTION STAB" -> "ACTION"
            "ACTION 60" -> "ACTION 60"
            "LOW LIGHT" -> "NIGHT VIDEO"
''',
    "REPORT deck labels",
)

report = must_replace(
    report,
    '''            "MASTER HDR" -> 72_000_000
            "ACTION STAB" -> 30_000_000
            "LOW LIGHT" -> 28_000_000
''',
    '''            "MASTER HDR" -> 72_000_000
            "SOCIAL HDR" -> 34_000_000
            "ACTION STAB" -> 30_000_000
            "ACTION 60" -> 48_000_000
            "LOW LIGHT" -> 28_000_000
''',
    "REPORT bitrates",
)

report = must_replace(
    report,
    '''            "SOCIAL 60",
            "UHD 60" -> 60
''',
    '''            "SOCIAL 60",
            "UHD 60",
            "ACTION 60" -> 60
''',
    "REPORT FPS profiles",
)

report = must_replace(
    report,
    '''        return qualityModes[
            qualityIndex
        ] == "MASTER HDR"
''',
    '''        return qualityModes[
            qualityIndex
        ] in
            setOf(
                "MASTER HDR",
                "SOCIAL HDR"
            )
''',
    "REPORT HDR selector",
)

report = must_replace(
    report,
    '''            "SOCIAL FHD",
            "ACTION STAB",
            "LOW LIGHT" -> true
''',
    '''            "SOCIAL FHD",
            "ACTION STAB",
            "ACTION 60",
            "LOW LIGHT" -> true
''',
    "REPORT stabilization profiles",
)

report = must_replace(
    report,
    '''                "MASTER UHD",
                "UHD 60",
                "MASTER HDR" ->
                    listOf(
                        Quality.UHD,
                        Quality.FHD,
                        Quality.HD
                    )

                "FAST HD" ->
''',
    '''                "MASTER UHD",
                "UHD 60",
                "MASTER HDR" ->
                    listOf(
                        Quality.UHD,
                        Quality.FHD,
                        Quality.HD
                    )

                "SOCIAL HDR" ->
                    listOf(
                        Quality.FHD,
                        Quality.UHD,
                        Quality.HD
                    )

                "FAST HD" ->
''',
    "REPORT SOCIAL HDR quality preference",
)

# Make the capability readout explicit when requested 60fps/stab/HDR falls back.
report = must_replace(
    report,
    '''                        activeVideoFpsLabel =
                            if (exactRange != null) {
                                "${requestedFps} FPS"
                            } else {
                                "${compatibleRange.lower}-${compatibleRange.upper} FPS"
                            }
                    } else {
                        activeVideoFpsLabel =
                            "AUTO FPS"
''',
    '''                        activeVideoFpsLabel =
                            if (exactRange != null) {
                                "${requestedFps} FPS"
                            } else {
                                "${compatibleRange.lower}-${compatibleRange.upper} FPS FALLBACK"
                            }
                    } else {
                        activeVideoFpsLabel =
                            "AUTO FPS FALLBACK"
''',
    "REPORT fallback wording",
)

REPORT.write_text(report, encoding="utf-8")

# ============================================================
# LIVE
# ============================================================
live = LIVE.read_text(encoding="utf-8")

live = must_replace(
    live,
    '''            "HDR UHD",
            "ACTION STAB",
            "LOW LIGHT",
''',
    '''            "HDR UHD",
            "SOCIAL HDR",
            "ACTION STAB",
            "ACTION 60",
            "LOW LIGHT",
''',
    "LIVE new quality profiles",
)

live = must_replace(
    live,
    '''            "HDR UHD" ->
                Quality.UHD

            "HD FAST" ->
''',
    '''            "HDR UHD" ->
                Quality.UHD

            "SOCIAL HDR" ->
                Quality.FHD

            "HD FAST" ->
''',
    "LIVE selected quality",
)

live = must_replace(
    live,
    '''            "HDR UHD" -> 72_000_000
            "ACTION STAB" -> 30_000_000
            "LOW LIGHT" -> 28_000_000
''',
    '''            "HDR UHD" -> 72_000_000
            "SOCIAL HDR" -> 34_000_000
            "ACTION STAB" -> 30_000_000
            "ACTION 60" -> 48_000_000
            "LOW LIGHT" -> 28_000_000
''',
    "LIVE bitrates",
)

live = must_replace(
    live,
    '''            "SOCIAL 60",
            "UHD 60" -> 60
''',
    '''            "SOCIAL 60",
            "UHD 60",
            "ACTION 60" -> 60
''',
    "LIVE FPS profiles",
)

live = must_replace(
    live,
    '''        return liveQualityProfiles[
            liveQualityIndex
        ] == "HDR UHD"
''',
    '''        return liveQualityProfiles[
            liveQualityIndex
        ] in
            setOf(
                "HDR UHD",
                "SOCIAL HDR"
            )
''',
    "LIVE HDR selector",
)

live = must_replace(
    live,
    '''            "SOCIAL 30",
            "ACTION STAB",
            "LOW LIGHT" -> true
''',
    '''            "SOCIAL 30",
            "ACTION STAB",
            "ACTION 60",
            "LOW LIGHT" -> true
''',
    "LIVE stabilization profiles",
)

live = must_replace(
    live,
    '''                                liveActiveFpsLabel =
                                    if (exactRange != null) {
                                        "${requestedFps} FPS"
                                    } else {
                                        "${compatibleRange.lower}-${compatibleRange.upper} FPS"
                                    }
                            } else {
                                liveActiveFpsLabel =
                                    "AUTO FPS"
''',
    '''                                liveActiveFpsLabel =
                                    if (exactRange != null) {
                                        "${requestedFps} FPS"
                                    } else {
                                        "${compatibleRange.lower}-${compatibleRange.upper} FPS FALLBACK"
                                    }
                            } else {
                                liveActiveFpsLabel =
                                    "AUTO FPS FALLBACK"
''',
    "LIVE fallback wording",
)

LIVE.write_text(live, encoding="utf-8")

# ============================================================
# HOME
# ============================================================
home = HOME.read_text(encoding="utf-8")
home = home.replace(
    '"CREATOR CAMERA ENGINE • V203"',
    '"SOCIAL MASTER PRO • V204"',
    1,
)
home = home.replace(
    '"1080P/4K • 30/60 FPS WHEN SUPPORTED • HLG10 HDR • STABILIZED ACTION • LOW-LIGHT AUTO FPS • 9:16 SOCIAL SAFE"',
    '"SOCIAL FHD/60 • SOCIAL HDR • 4K 30/60 • ACTION 30/60 • HLG10 HDR • LOW-LIGHT AUTO FPS • 9:16 SOCIAL SAFE"',
    1,
)
home = home.replace(
    '"FIELD REPORT • SOCIAL 30/60 • 4K 30/60 • HDR master • stabilized action • low-light creator modes • telemetry"',
    '"FIELD REPORT • SOCIAL 30/60 • SOCIAL HDR • 4K 30/60 • ACTION 30/60 • low-light creator mode • telemetry"',
    1,
)
home = home.replace(
    '"LIVE STUDIO • SOCIAL 30/60 • UHD 30/60 • HDR • action stabilization • low-light profile • LIVE graphics"',
    '"LIVE STUDIO • SOCIAL 30/60 • SOCIAL HDR • UHD 30/60 • ACTION 30/60 • low-light profile • LIVE graphics"',
    1,
)
HOME.write_text(home, encoding="utf-8")

# ============================================================
# VERSION
# ============================================================
gradle = GRADLE.read_text(encoding="utf-8")
gradle = re.sub(
    r"versionCode\s*=\s*\d+",
    "versionCode = 20400",
    gradle,
    count=1,
)
gradle = re.sub(
    r'versionName\s*=\s*"[^"]+"',
    'versionName = "204.0-social-master-pro"',
    gradle,
    count=1,
)
GRADLE.write_text(gradle, encoding="utf-8")

print("V204 Social Master Pro patch applied.")
