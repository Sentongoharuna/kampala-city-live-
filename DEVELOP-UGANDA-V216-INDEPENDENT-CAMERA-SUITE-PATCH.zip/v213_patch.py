from pathlib import Path
import re

ROOT = Path("v172-source/app")
REPORT = ROOT / "src/main/java/com/sentongoharuna/pulse/DevelopUgandaCameraActivity.kt"
LIVE = ROOT / "src/main/java/com/sentongoharuna/pulse/DevelopUgandaLiveActivity.kt"
HOME = ROOT / "src/main/java/com/sentongoharuna/pulse/DevelopUgandaNewsroomActivity.kt"
GRADLE = ROOT / "build.gradle.kts"

def must_replace(text, old, new, label):
    if old not in text:
        raise SystemExit(f"V213 patch anchor missing: {label}")
    return text.replace(old, new, 1)

# ============================================================
# V213 — THERMAL GUARD PRO
# Real Android PowerManager thermal status drives:
#   1) operator camera UI
#   2) verified runtime state
#   3) recorded REPORT/LIVE burn-in
#   4) automatic safe-profile fallback at SEVERE+
#   5) V213 filename / integrity metadata
# No fake temperature is invented.
# ============================================================

report = REPORT.read_text(encoding="utf-8")

# Android PowerManager import.
report = must_replace(
    report,
    "import android.os.Looper\n",
    "import android.os.Looper\nimport android.os.PowerManager\n",
    "REPORT PowerManager import",
)

# UI field.
report = must_replace(
    report,
    '''    private lateinit var lightAdvisorView: TextView
    private lateinit var audioGuardView: TextView

    private lateinit var brandView: TextView
''',
    '''    private lateinit var lightAdvisorView: TextView
    private lateinit var audioGuardView: TextView
    private lateinit var thermalGuardView: TextView

    private lateinit var brandView: TextView
''',
    "REPORT thermal UI field",
)

# Runtime state.
report = must_replace(
    report,
    '''    private lateinit var sensorManager: SensorManager
    private var rotationVectorSensor: Sensor? = null
    private var ambientLightSensor: Sensor? = null
    private lateinit var locationManager: LocationManager
''',
    '''    private lateinit var sensorManager: SensorManager
    private var rotationVectorSensor: Sensor? = null
    private var ambientLightSensor: Sensor? = null
    private lateinit var powerManager: PowerManager
    @Volatile private var thermalStatus =
        PowerManager.THERMAL_STATUS_NONE
    private var thermalListenerRegistered = false

    private val thermalStatusListener =
        PowerManager.OnThermalStatusChangedListener {
                status ->
            thermalStatus =
                status

            runOnUiThread {
                updateThermalGuard()
                refreshHud()
            }
        }

    private lateinit var locationManager: LocationManager
''',
    "REPORT thermal runtime fields",
)

# Initialise PowerManager.
report = must_replace(
    report,
    '''        ambientLightSensor =
            sensorManager.getDefaultSensor(
                Sensor.TYPE_LIGHT
            )

        locationManager =
''',
    '''        ambientLightSensor =
            sensorManager.getDefaultSensor(
                Sensor.TYPE_LIGHT
            )

        powerManager =
            getSystemService(
                Context.POWER_SERVICE
            ) as PowerManager

        if (
            Build.VERSION.SDK_INT >=
                Build.VERSION_CODES.Q
        ) {
            thermalStatus =
                powerManager.currentThermalStatus
        }

        locationManager =
''',
    "REPORT PowerManager init",
)

# Thermal chip below Audio Guard.
report = must_replace(
    report,
    '''        root.addView(
            audioGuardView,
            audioGuardParams
        )

        // V187 PREVIEW HUD:
''',
    '''        root.addView(
            audioGuardView,
            audioGuardParams
        )

        thermalGuardView =
            TextView(this).apply {
                text =
                    "THERMAL • NORMAL"

                textSize =
                    7.8f

                gravity =
                    Gravity.CENTER

                typeface =
                    Typeface.MONOSPACE

                setTextColor(
                    0xFF91B6A0.toInt()
                )

                setPadding(
                    dp(9),
                    dp(4),
                    dp(9),
                    dp(4)
                )

                background =
                    GradientDrawable().apply {
                        shape =
                            GradientDrawable.RECTANGLE

                        cornerRadius =
                            dp(14).toFloat()

                        setColor(
                            0x42031829
                        )

                        setStroke(
                            dp(1),
                            0x607A91A4
                        )
                    }
            }

        val thermalGuardParams =
            FrameLayout.LayoutParams(
                dp(220),
                dp(30),
                Gravity.CENTER
            ).apply {
                topMargin =
                    dp(168)
            }

        root.addView(
            thermalGuardView,
            thermalGuardParams
        )

        // V187 PREVIEW HUD:
''',
    "REPORT thermal chip UI",
)

# Thermal helper functions before verified state.
report = must_replace(
    report,
    '''    private fun verifiedCameraStateText(): String {
''',
    '''    private fun thermalStateLabel(): String {
        if (
            Build.VERSION.SDK_INT <
                Build.VERSION_CODES.Q
        ) {
            return "UNAVAILABLE"
        }

        return when (
            thermalStatus
        ) {
            PowerManager.THERMAL_STATUS_NONE ->
                "NORMAL"

            PowerManager.THERMAL_STATUS_LIGHT ->
                "LIGHT"

            PowerManager.THERMAL_STATUS_MODERATE ->
                "MODERATE"

            PowerManager.THERMAL_STATUS_SEVERE ->
                "SEVERE"

            PowerManager.THERMAL_STATUS_CRITICAL ->
                "CRITICAL"

            PowerManager.THERMAL_STATUS_EMERGENCY ->
                "EMERGENCY"

            PowerManager.THERMAL_STATUS_SHUTDOWN ->
                "SHUTDOWN"

            else ->
                "UNKNOWN"
        }
    }

    private fun isThermalSevereOrWorse(): Boolean {
        return (
            Build.VERSION.SDK_INT >=
                Build.VERSION_CODES.Q &&
            thermalStatus >=
                PowerManager.THERMAL_STATUS_SEVERE
            )
    }

    private fun updateThermalGuard() {
        if (
            !::thermalGuardView.isInitialized
        ) {
            return
        }

        if (
            operatorControlsHidden ||
            cleanModeEnabled
        ) {
            thermalGuardView.visibility =
                View.GONE

            return
        }

        thermalGuardView.visibility =
            View.VISIBLE

        val label =
            thermalStateLabel()

        thermalGuardView.text =
            "THERMAL • $label"

        thermalGuardView.setTextColor(
            when (label) {
                "NORMAL",
                "LIGHT" ->
                    0xFF91B6A0.toInt()

                "MODERATE" ->
                    0xFFAEBDEB.toInt()

                "SEVERE",
                "CRITICAL",
                "EMERGENCY",
                "SHUTDOWN" ->
                    0xFFC76D73.toInt()

                else ->
                    0xFFAEB7C7.toInt()
            }
        )
    }

    private fun applyThermalSafeProfileIfNeeded() {
        if (
            !isThermalSevereOrWorse() ||
            recording !=
                null
        ) {
            return
        }

        val current =
            qualityModes[
                qualityIndex
            ]

        val highDemand =
            current in
                setOf(
                    "MASTER UHD",
                    "UHD 60",
                    "MASTER HDR",
                    "SOCIAL HDR",
                    "ACTION 60"
                )

        if (!highDemand) {
            return
        }

        val safeIndex =
            qualityModes.indexOf(
                "SOCIAL FHD"
            )

        if (
            safeIndex >=
                0 &&
            safeIndex !=
                qualityIndex
        ) {
            qualityIndex =
                safeIndex

            if (
                ::qualityButton.isInitialized
            ) {
                qualityButton.text =
                    "FORMAT ▾\\n${qualityDeckLabel()}"
            }

            toast(
                "THERMAL ${thermalStateLabel()} • switched to SOCIAL FHD"
            )
        }
    }

    private fun verifiedCameraStateText(): String {
''',
    "REPORT thermal helpers",
)

# Add thermal to the true verified runtime summary and advance version.
report = report.replace(
    'append("V212 VERIFIED")',
    'append("V213 VERIFIED")',
    1,
)

report = must_replace(
    report,
    '''            append(" • AUDIO ")
            append(audioGuardLabel())
        }
    }
''',
    '''            append(" • AUDIO ")
            append(audioGuardLabel())
            append(" • THERMAL ")
            append(
                thermalStateLabel()
            )
        }
    }
''',
    "REPORT verified thermal state",
)

# Refresh UI chip.
report = must_replace(
    report,
    '''        updateLightAdvisor()
        updateAudioGuard()

        timecodeView.text =
''',
    '''        updateLightAdvisor()
        updateAudioGuard()
        updateThermalGuard()

        timecodeView.text =
''',
    "REPORT thermal refresh",
)

# Register thermal listener in onResume.
report = must_replace(
    report,
    '''        ambientLightSensor?.let { sensor ->
            sensorManager.registerListener(
                this,
                sensor,
                SensorManager.SENSOR_DELAY_NORMAL
            )
        }
    }
''',
    '''        ambientLightSensor?.let { sensor ->
            sensorManager.registerListener(
                this,
                sensor,
                SensorManager.SENSOR_DELAY_NORMAL
            )
        }

        if (
            Build.VERSION.SDK_INT >=
                Build.VERSION_CODES.Q &&
            !thermalListenerRegistered
        ) {
            try {
                powerManager.addThermalStatusListener(
                    thermalStatusListener
                )

                thermalStatus =
                    powerManager.currentThermalStatus

                thermalListenerRegistered =
                    true
            } catch (_: Exception) {
                thermalListenerRegistered =
                    false
            }
        }
    }
''',
    "REPORT register thermal listener",
)

# Unregister thermal listener on pause.
report = must_replace(
    report,
    '''    override fun onPause() {
        try {
            sensorManager.unregisterListener(this)
        } catch (_: Exception) {
        }

        super.onPause()
    }
''',
    '''    override fun onPause() {
        try {
            sensorManager.unregisterListener(this)
        } catch (_: Exception) {
        }

        if (
            Build.VERSION.SDK_INT >=
                Build.VERSION_CODES.Q &&
            thermalListenerRegistered
        ) {
            try {
                powerManager.removeThermalStatusListener(
                    thermalStatusListener
                )
            } catch (_: Exception) {
            }

            thermalListenerRegistered =
                false
        }

        super.onPause()
    }
''',
    "REPORT unregister thermal listener",
)

# Apply a real automatic fallback before CameraX config is built.
report = must_replace(
    report,
    '''    private fun bindCamera() {
        val p = provider ?: return

        p.unbindAll()
''',
    '''    private fun bindCamera() {
        val p = provider ?: return

        applyThermalSafeProfileIfNeeded()

        p.unbindAll()
''',
    "REPORT thermal safe profile",
)

# Camera operator version labels.
report = report.replace(
    '"develop.uganda • V212"',
    '"develop.uganda • V213"',
    1,
)
report = report.replace(
    '"${sceneTag()} • V212 VERIFIED"',
    '"${sceneTag()} • V213 VERIFIED"',
    1,
)

# Recorded REPORT overlay now visibly carries V213 and real thermal state.
report = must_replace(
    report,
    '''            "${sceneTag()} • V212",
''',
    '''            "${sceneTag()} • V213",
''',
    "REPORT recorded version V213",
)

report = must_replace(
    report,
    '''            "$recState   |   TC ${tc()}",
''',
    '''            "$recState   |   TC ${tc()}   |   V213   |   THERM ${thermalStateLabel()}",
''',
    "REPORT recorded thermal status",
)

# Saved filename.
report = report.replace(
    '"DEVELOP_UGANDA_V212_${reportId}_${sceneModes[sceneIndex]}_${lookModes[lookIndex]}_"',
    '"DEVELOP_UGANDA_V213_${reportId}_${sceneModes[sceneIndex]}_${lookModes[lookIndex]}_"',
    1,
)

# Integrity metadata: real version + thermal snapshot.
report = must_replace(
    report,
    '''        val lookSnapshot =
            lookModes[
                lookIndex
            ]

        Thread {
''',
    '''        val lookSnapshot =
            lookModes[
                lookIndex
            ]

        val thermalSnapshot =
            thermalStateLabel()

        Thread {
''',
    "REPORT thermal integrity snapshot",
)

report = report.replace(
    '''                            "V212"
''',
    '''                            "V213"
''',
    1,
)
report = report.replace(
    '''                            "V212 VERIFIED CAMERA STATE"
''',
    '''                            "V213 THERMAL GUARD PRO"
''',
    1,
)
report = report.replace(
    '''                            "V204,V205,V206,V207,V208,V209,V210,V211,V212"
''',
    '''                            "V204,V205,V206,V207,V208,V209,V210,V211,V212,V213"
''',
    1,
)

report = must_replace(
    report,
    '''                        put(
                            "gps_accuracy_m",
                            accSnapshot
                        )
                        put(
                            "note",
''',
    '''                        put(
                            "gps_accuracy_m",
                            accSnapshot
                        )
                        put(
                            "thermal_status",
                            thermalSnapshot
                        )
                        put(
                            "note",
''',
    "REPORT thermal integrity field",
)

REPORT.write_text(report, encoding="utf-8")

# ============================================================
# LIVE — actual PowerManager thermal state + safe fallback.
# ============================================================

live = LIVE.read_text(encoding="utf-8")

live = must_replace(
    live,
    "import android.os.Looper\n",
    "import android.os.Looper\nimport android.os.PowerManager\n",
    "LIVE PowerManager import",
)

# Runtime fields.
live = must_replace(
    live,
    '''    private var liveAudioPeakAmplitude = 0.0
    private var liveBlinkOn = true
''',
    '''    private var liveAudioPeakAmplitude = 0.0
    private var liveBlinkOn = true

    private lateinit var livePowerManager: PowerManager
    @Volatile private var liveThermalStatus =
        PowerManager.THERMAL_STATUS_NONE
    private var liveThermalListenerRegistered =
        false

    private val liveThermalStatusListener =
        PowerManager.OnThermalStatusChangedListener {
                status ->
            liveThermalStatus =
                status

            runOnUiThread {
                updateSignals()
            }
        }
''',
    "LIVE thermal fields",
)

# Initialise and register at startup.
live = must_replace(
    live,
    '''        loadLiveIdentity()
        loadLiveCameraPreferences()
        buildLiveUi()
        requestNeededPermissions()
''',
    '''        livePowerManager =
            getSystemService(
                Context.POWER_SERVICE
            ) as PowerManager

        if (
            Build.VERSION.SDK_INT >=
                Build.VERSION_CODES.Q
        ) {
            liveThermalStatus =
                livePowerManager.currentThermalStatus

            try {
                livePowerManager.addThermalStatusListener(
                    liveThermalStatusListener
                )

                liveThermalListenerRegistered =
                    true
            } catch (_: Exception) {
                liveThermalListenerRegistered =
                    false
            }
        }

        loadLiveIdentity()
        loadLiveCameraPreferences()
        buildLiveUi()
        requestNeededPermissions()
''',
    "LIVE thermal init",
)

# Unregister on destroy.
live = must_replace(
    live,
    '''        recording?.stop()
        recording = null

        super.onDestroy()
''',
    '''        recording?.stop()
        recording = null

        if (
            Build.VERSION.SDK_INT >=
                Build.VERSION_CODES.Q &&
            liveThermalListenerRegistered
        ) {
            try {
                livePowerManager.removeThermalStatusListener(
                    liveThermalStatusListener
                )
            } catch (_: Exception) {
            }

            liveThermalListenerRegistered =
                false
        }

        super.onDestroy()
''',
    "LIVE thermal unregister",
)

# Helpers before V212 verified helper.
live = must_replace(
    live,
    '''    private fun liveVerifiedStateText(): String {
''',
    '''    private fun liveThermalStateLabel(): String {
        if (
            Build.VERSION.SDK_INT <
                Build.VERSION_CODES.Q
        ) {
            return "UNAVAILABLE"
        }

        return when (
            liveThermalStatus
        ) {
            PowerManager.THERMAL_STATUS_NONE ->
                "NORMAL"

            PowerManager.THERMAL_STATUS_LIGHT ->
                "LIGHT"

            PowerManager.THERMAL_STATUS_MODERATE ->
                "MODERATE"

            PowerManager.THERMAL_STATUS_SEVERE ->
                "SEVERE"

            PowerManager.THERMAL_STATUS_CRITICAL ->
                "CRITICAL"

            PowerManager.THERMAL_STATUS_EMERGENCY ->
                "EMERGENCY"

            PowerManager.THERMAL_STATUS_SHUTDOWN ->
                "SHUTDOWN"

            else ->
                "UNKNOWN"
        }
    }

    private fun applyLiveThermalSafeProfileIfNeeded() {
        if (
            Build.VERSION.SDK_INT <
                Build.VERSION_CODES.Q ||
            liveThermalStatus <
                PowerManager.THERMAL_STATUS_SEVERE ||
            recording !=
                null
        ) {
            return
        }

        val current =
            liveQualityProfiles[
                liveQualityIndex
            ]

        val highDemand =
            current in
                setOf(
                    "UHD 30",
                    "UHD 60",
                    "HDR UHD",
                    "SOCIAL HDR",
                    "ACTION 60"
                )

        if (!highDemand) {
            return
        }

        val safeIndex =
            liveQualityProfiles.indexOf(
                "SOCIAL 30"
            )

        if (
            safeIndex >=
                0 &&
            safeIndex !=
                liveQualityIndex
        ) {
            liveQualityIndex =
                safeIndex

            syncLiveQualityState()

            if (
                ::qualityButton.isInitialized
            ) {
                qualityButton.text =
                    "QUALITY ▾\\n${liveQualityProfiles[liveQualityIndex]}"
            }

            toast(
                "THERMAL ${liveThermalStateLabel()} • LIVE switched to SOCIAL 30"
            )
        }
    }

    private fun liveVerifiedStateText(): String {
''',
    "LIVE thermal helpers",
)

live = live.replace(
    'append("V212 VERIFIED")',
    'append("V213 VERIFIED")',
    1,
)

live = must_replace(
    live,
    '''            append(" • AUDIO ")
            append(liveAudioGuardLabel())
        }
    }
''',
    '''            append(" • AUDIO ")
            append(liveAudioGuardLabel())
            append(" • THERMAL ")
            append(
                liveThermalStateLabel()
            )
        }
    }
''',
    "LIVE verified thermal state",
)

# Apply actual safety before LIVE CameraX session build.
live = must_replace(
    live,
    '''    private fun bindCamera() {
        val future =
            ProcessCameraProvider.getInstance(
                this
            )
''',
    '''    private fun bindCamera() {
        applyLiveThermalSafeProfileIfNeeded()

        val future =
            ProcessCameraProvider.getInstance(
                this
            )
''',
    "LIVE thermal safe profile",
)

# Operator interface version.
live = live.replace(
    '"develop.uganda • V212"',
    '"develop.uganda • V213"',
    1,
)

# Saved LIVE video version + thermal status.
live = must_replace(
    live,
    '''            "develop.uganda • V212",
''',
    '''            "develop.uganda • V213",
''',
    "LIVE recorded brand V213",
)

live = must_replace(
    live,
    '''            "${if (liveOn) "ON AIR" else "READY"}   |   TIMECODE • ${liveTimecode()}   |   FORMAT • $qualityLabel",
''',
    '''            "${if (liveOn) "ON AIR" else "READY"}   |   TIMECODE • ${liveTimecode()}   |   FORMAT • $qualityLabel   |   V213   |   THERMAL • ${liveThermalStateLabel()}",
''',
    "LIVE recorded thermal status",
)

live = must_replace(
    live,
    '''            "REPORTER • $reporterName   |   STORY • $storyId   |   develop.uganda • V212",
''',
    '''            "REPORTER • $reporterName   |   STORY • $storyId   |   develop.uganda • V213",
''',
    "LIVE recorded footer V213",
)

live = live.replace(
    '"DEVELOP_UGANDA_V212_LIVE_${profiles[profileIndex]}_$stamp"',
    '"DEVELOP_UGANDA_V213_LIVE_${profiles[profileIndex]}_$stamp"',
    1,
)

LIVE.write_text(live, encoding="utf-8")

# ============================================================
# HOME — append V213, keep everything else.
# ============================================================

home = HOME.read_text(encoding="utf-8")

home = home.replace(
    '"VERIFIED CAMERA STATE • V212"',
    '"THERMAL GUARD PRO • V213"',
    1,
)

home = home.replace(
    '"V204→V212 ALL RETAINED • SOCIAL/HDR/4K/ACTION • AF/METER • HORIZON • STEADYSHOT • NIGHT INTELLIGENCE • AUDIO GUARD • VERIFIED STATE • 9:16 SAFE"',
    '"V204→V213 ALL RETAINED • SOCIAL/HDR/4K/ACTION • AF/METER • HORIZON • STEADYSHOT • NIGHT INTELLIGENCE • AUDIO • VERIFIED STATE • THERMAL GUARD • 9:16 SAFE"',
    1,
)

home = home.replace(
    '"FIELD REPORT • V212 VERIFIED RUNTIME STATE • ALL V204→V211 MODULES RETAINED • LIVE CAMERA/SENSOR/AUDIO VALUES • VERSIONED VIDEO • telemetry"',
    '"FIELD REPORT • V213 VERIFIED RUNTIME STATE • ALL V204→V212 MODULES RETAINED • REAL THERMAL STATUS • AUTO SAFE PROFILE AT SEVERE+ • VERSIONED VIDEO • telemetry"',
    1,
)

home = home.replace(
    '"✓ ALL PRO • V212"',
    '"✓ ALL PRO • V213"',
    1,
)

home = home.replace(
    '"Every camera module below remains active together. V212 now verifies real runtime state and versions the actual recorded output without replacing V204–V211."',
    '"Every camera module below remains active together. V213 adds real Android thermal monitoring and high-heat safe-profile fallback without replacing V204–V212."',
    1,
)

home = must_replace(
    home,
    '''                Triple(
                    "✓ V212 • VERIFIED CAMERA STATE",
                    "Uses real runtime CameraX, sensor and audio values; interface, saved video, filename and integrity record identify V212.",
                    cyan
                )
''',
    '''                Triple(
                    "✓ V212 • VERIFIED CAMERA STATE",
                    "Uses real runtime CameraX, sensor and audio values; interface, saved video, filename and integrity record identify V212.",
                    cyan
                ),
                Triple(
                    "✓ V213 • THERMAL GUARD PRO",
                    "Reads Android PowerManager thermal status; shows it in REPORT/LIVE, burns it into video, and falls back from high-demand profiles at SEVERE+.",
                    red
                )
''',
    "HOME append V213 module",
)

home = home.replace(
    '"NOTHING DROPPED • V204→V212 RETAINED • NEW MODULES MUST HAVE REAL RUNTIME BEHAVIOUR BEFORE THEY ARE SHOWN AS ACTIVE"',
    '"NOTHING DROPPED • V204→V213 RETAINED • ACTIVE MEANS REAL RUNTIME BEHAVIOUR, NOT DECORATIVE TEXT"',
    1,
)

HOME.write_text(home, encoding="utf-8")

# ============================================================
# VERSION
# ============================================================

gradle = GRADLE.read_text(encoding="utf-8")
gradle = re.sub(
    r"versionCode\s*=\s*\d+",
    "versionCode = 21300",
    gradle,
    count=1,
)
gradle = re.sub(
    r'versionName\s*=\s*"[^"]+"',
    'versionName = "213.0-thermal-guard-pro"',
    gradle,
    count=1,
)
GRADLE.write_text(gradle, encoding="utf-8")

print("V213 Thermal Guard Pro patch applied.")
