from pathlib import Path
import re

ROOT = Path("v172-source/app")
REPORT = ROOT / "src/main/java/com/sentongoharuna/pulse/DevelopUgandaCameraActivity.kt"
HOME = ROOT / "src/main/java/com/sentongoharuna/pulse/DevelopUgandaNewsroomActivity.kt"
GRADLE = ROOT / "build.gradle.kts"

def must_replace(text, old, new, label):
    if old not in text:
        raise SystemExit(f"V209 patch anchor missing: {label}")
    return text.replace(old, new, 1)

report = REPORT.read_text(encoding="utf-8")

report = must_replace(
    report,
    '''    private lateinit var horizonGuardView: TextView
    private lateinit var motionGuardView: TextView

    private lateinit var brandView: TextView
''',
    '''    private lateinit var horizonGuardView: TextView
    private lateinit var motionGuardView: TextView
    private lateinit var lightAdvisorView: TextView

    private lateinit var brandView: TextView
''',
    "REPORT light advisor view field",
)

report = must_replace(
    report,
    '''    private var rotationVectorSensor: Sensor? = null
    private lateinit var locationManager: LocationManager
''',
    '''    private var rotationVectorSensor: Sensor? = null
    private var ambientLightSensor: Sensor? = null
    private lateinit var locationManager: LocationManager
''',
    "REPORT ambient light sensor field",
)

report = must_replace(
    report,
    '''    @Volatile private var cameraShakeScore = 0f
    @Volatile private var lastMotionSampleMs = 0L
    @Volatile private var gnssSatellitesVisible = -1
''',
    '''    @Volatile private var cameraShakeScore = 0f
    @Volatile private var lastMotionSampleMs = 0L
    @Volatile private var ambientLux: Float? = null
    @Volatile private var gnssSatellitesVisible = -1
''',
    "REPORT ambient light state",
)

report = must_replace(
    report,
    '''        rotationVectorSensor =
            sensorManager.getDefaultSensor(
                Sensor.TYPE_ROTATION_VECTOR
            )
        locationManager =
''',
    '''        rotationVectorSensor =
            sensorManager.getDefaultSensor(
                Sensor.TYPE_ROTATION_VECTOR
            )

        ambientLightSensor =
            sensorManager.getDefaultSensor(
                Sensor.TYPE_LIGHT
            )

        locationManager =
''',
    "REPORT ambient light sensor init",
)

report = must_replace(
    report,
    '''        root.addView(
            motionGuardView,
            motionParams
        )

        // V187 PREVIEW HUD:
''',
    '''        root.addView(
            motionGuardView,
            motionParams
        )

        lightAdvisorView =
            TextView(this).apply {
                text =
                    "LIGHT • SENSOR --"

                textSize =
                    7.8f

                gravity =
                    Gravity.CENTER

                typeface =
                    Typeface.MONOSPACE

                setTextColor(
                    0xFFAEB7C7.toInt()
                )

                setPadding(
                    dp(9),
                    dp(4),
                    dp(9),
                    dp(4)
                )

                background =
                    GradientDrawable().apply {
                        shape =
                            GradientDrawable.RECTANGLE

                        cornerRadius =
                            dp(14).toFloat()

                        setColor(
                            0x42031829
                        )

                        setStroke(
                            dp(1),
                            0x607A91A4
                        )
                    }
            }

        val lightParams =
            FrameLayout.LayoutParams(
                dp(220),
                dp(30),
                Gravity.CENTER
            ).apply {
                topMargin =
                    dp(92)
            }

        root.addView(
            lightAdvisorView,
            lightParams
        )

        // V187 PREVIEW HUD:
''',
    "REPORT light advisor UI",
)

report = must_replace(
    report,
    '''    private fun motionGuardLabel(): String {
''',
    '''    private fun ambientLightLabel(): String {
        val lux =
            ambientLux
                ?: return "LIGHT --"

        return when {
            lux <
                25f ->
                    "DARK"

            lux <
                100f ->
                    "DIM"

            lux <
                500f ->
                    "NORMAL"

            else ->
                "BRIGHT"
        }
    }

    private fun ambientLightRecommendation(): String {
        val lux =
            ambientLux
                ?: return "SENSOR --"

        val selected =
            qualityModes[
                qualityIndex
            ]

        return when {
            lux <
                25f ->
                    if (
                        selected ==
                            "LOW LIGHT"
                    ) {
                        "LOW LIGHT ACTIVE"
                    } else {
                        "USE LOW LIGHT"
                    }

            lux <
                100f &&
                (
                    selected ==
                        "SOCIAL 60" ||
                    selected ==
                        "UHD 60" ||
                    selected ==
                        "ACTION 60"
                    ) ->
                        "30 FPS ADVISED"

            lux >
                500f &&
                (
                    selected ==
                        "SOCIAL FHD" ||
                    selected ==
                        "ACTION STAB"
                    ) ->
                        "60 FPS AVAILABLE"

            else ->
                "EXPOSURE OK"
        }
    }

    private fun updateLightAdvisor() {
        if (
            !::lightAdvisorView.isInitialized
        ) {
            return
        }

        if (
            operatorControlsHidden ||
            cleanModeEnabled
        ) {
            lightAdvisorView.visibility =
                View.GONE

            return
        }

        lightAdvisorView.visibility =
            View.VISIBLE

        val lux =
            ambientLux

        if (
            lux ==
                null
        ) {
            lightAdvisorView.text =
                "LIGHT • SENSOR --"

            lightAdvisorView.setTextColor(
                0xFFAEB7C7.toInt()
            )

            return
        }

        val label =
            ambientLightLabel()

        lightAdvisorView.text =
            String.format(
                Locale.US,
                "LIGHT • %s • %.0f LUX • %s",
                label,
                lux,
                ambientLightRecommendation()
            )

        lightAdvisorView.setTextColor(
            when (label) {
                "BRIGHT" ->
                    0xFFAEBDEB.toInt()

                "NORMAL" ->
                    0xFF91B6A0.toInt()

                "DIM" ->
                    0xFFAEBDEB.toInt()

                else ->
                    0xFFC76D73.toInt()
            }
        )
    }

    private fun motionGuardLabel(): String {
''',
    "REPORT ambient light helper functions",
)

report = must_replace(
    report,
    '''    private fun refreshHud() {
        updateHorizonGuard()
        updateMotionGuard()

        timecodeView.text =
''',
    '''    private fun refreshHud() {
        updateHorizonGuard()
        updateMotionGuard()
        updateLightAdvisor()

        timecodeView.text =
''',
    "REPORT refresh light advisor",
)

report = must_replace(
    report,
    '''        rotationVectorSensor?.let { sensor ->
            sensorManager.registerListener(
                this,
                sensor,
                SensorManager.SENSOR_DELAY_GAME
            )
        }
    }
''',
    '''        rotationVectorSensor?.let { sensor ->
            sensorManager.registerListener(
                this,
                sensor,
                SensorManager.SENSOR_DELAY_GAME
            )
        }

        ambientLightSensor?.let { sensor ->
            sensorManager.registerListener(
                this,
                sensor,
                SensorManager.SENSOR_DELAY_NORMAL
            )
        }
    }
''',
    "REPORT register light sensor",
)

report = must_replace(
    report,
    '''    override fun onSensorChanged(
        event: SensorEvent?
    ) {
        if (
            event == null ||
            event.sensor.type !=
            Sensor.TYPE_ROTATION_VECTOR
        ) {
            return
        }

        try {
''',
    '''    override fun onSensorChanged(
        event: SensorEvent?
    ) {
        if (
            event ==
                null
        ) {
            return
        }

        if (
            event.sensor.type ==
                Sensor.TYPE_LIGHT
        ) {
            ambientLux =
                event.values
                    .firstOrNull()
                    ?.coerceAtLeast(
                        0f
                    )

            updateLightAdvisor()
            return
        }

        if (
            event.sensor.type !=
                Sensor.TYPE_ROTATION_VECTOR
        ) {
            return
        }

        try {
''',
    "REPORT light sensor event branch",
)

report = must_replace(
    report,
    '''            append(" • STEADYSHOT ")
            append(
                motionGuardLabel()
            )
        }
    }
''',
    '''            append(" • STEADYSHOT ")
            append(
                motionGuardLabel()
            )
            append(" • ")
            append(
                ambientLightRecommendation()
            )
        }
    }
''',
    "REPORT creator engine ambient recommendation",
)

REPORT.write_text(report, encoding="utf-8")

home = HOME.read_text(encoding="utf-8")

home = home.replace(
    '"STEADYSHOT GUARD PRO • V208"',
    '"NIGHT INTELLIGENCE PRO • V209"',
    1,
)

home = home.replace(
    '"SOCIAL FHD/60 • SOCIAL HDR • 4K 30/60 • ACTION 30/60 • HLG10 HDR • AF+AE+AWB LOCK • HORIZON + SHAKE GUARDS • 9:16 SOCIAL SAFE"',
    '"SOCIAL FHD/60 • SOCIAL HDR • 4K 30/60 • ACTION 30/60 • HLG10 HDR • HORIZON/SHAKE GUARDS • AMBIENT-LIGHT NIGHT ADVISOR • 9:16 SAFE"',
    1,
)

home = home.replace(
    '"FIELD REPORT • TAP AF • METER LOCK • LIVE HORIZON GUIDE • STEADY/MOVING/SHAKE SENSOR GUARD • SOCIAL/HDR/4K/ACTION/LOW LIGHT • telemetry"',
    '"FIELD REPORT • AF/METER LOCK • HORIZON + SHAKE GUARDS • LIVE LUX SENSOR • LOW-LIGHT/30FPS ADVICE • SOCIAL/HDR/4K/ACTION • telemetry"',
    1,
)

HOME.write_text(home, encoding="utf-8")

gradle = GRADLE.read_text(encoding="utf-8")
gradle = re.sub(
    r"versionCode\s*=\s*\d+",
    "versionCode = 20900",
    gradle,
    count=1,
)
gradle = re.sub(
    r'versionName\s*=\s*"[^"]+"',
    'versionName = "209.0-night-intelligence-pro"',
    gradle,
    count=1,
)
GRADLE.write_text(gradle, encoding="utf-8")

print("V209 Night Intelligence Pro patch applied.")
