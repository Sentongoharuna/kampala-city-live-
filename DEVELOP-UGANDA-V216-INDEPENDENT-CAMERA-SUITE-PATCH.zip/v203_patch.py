from pathlib import Path
import re

ROOT = Path("v172-source/app")
REPORT = ROOT / "src/main/java/com/sentongoharuna/pulse/DevelopUgandaCameraActivity.kt"
LIVE = ROOT / "src/main/java/com/sentongoharuna/pulse/DevelopUgandaLiveActivity.kt"
HOME = ROOT / "src/main/java/com/sentongoharuna/pulse/DevelopUgandaNewsroomActivity.kt"
GRADLE = ROOT / "build.gradle.kts"

def must_replace(text, old, new, label):
    if old not in text:
        raise SystemExit(f"V203 patch anchor missing: {label}")
    return text.replace(old, new, 1)

def must_sub(text, pattern, repl, label):
    new_text, count = re.subn(pattern, repl, text, count=1, flags=re.S)
    if count != 1:
        raise SystemExit(f"V203 regex anchor missing: {label} ({count})")
    return new_text

# ============================================================
# REPORT CAMERA
# ============================================================
report = REPORT.read_text(encoding="utf-8")

report = must_replace(
    report,
    "import androidx.camera.core.CameraSelector\n",
    "import androidx.camera.core.CameraSelector\n"
    "import androidx.camera.core.AspectRatio\n"
    "import androidx.camera.core.DynamicRange\n",
    "REPORT CameraX imports",
)

report = must_replace(
    report,
    '''    private val qualityModes = listOf(
        "SOCIAL FHD",
        "MASTER UHD",
        "FAST HD"
    )
''',
    '''    // V203 capability-driven recording profiles.
    // SOCIAL FHD remains the safest upload master for TikTok/Instagram.
    private val qualityModes = listOf(
        "SOCIAL FHD",
        "SOCIAL 60",
        "MASTER UHD",
        "UHD 60",
        "MASTER HDR",
        "ACTION STAB",
        "LOW LIGHT",
        "FAST HD"
    )
''',
    "REPORT quality modes",
)

report = must_replace(
    report,
    '''    private var sceneExposureTarget = 0

    private val weather = WeatherRepository()
''',
    '''    private var sceneExposureTarget = 0

    private var activeVideoFpsLabel = "AUTO FPS"
    private var activeVideoStabilizationLabel = "STAB AUTO"
    private var activeVideoDynamicRangeLabel = "SDR"
    private var activeVideoAspectLabel = "9:16 SOCIAL SAFE"

    private val weather = WeatherRepository()
''',
    "REPORT active camera state",
)

report = must_replace(
    report,
    "            scaleType = PreviewView.ScaleType.FILL_CENTER\n",
    "            scaleType = PreviewView.ScaleType.FIT_CENTER\n",
    "REPORT social-safe preview",
)

report = must_sub(
    report,
    r'''    private fun qualityDeckLabel\(\): String \{.*?\n    \}\n\n    private fun targetVideoBitrate\(\): Int \{.*?\n    \}\n\n    private fun socialCameraStatus\(\): String \{.*?\n    \}\n''',
    '''    private fun qualityDeckLabel(): String {
        return when (
            qualityModes[
                qualityIndex
            ]
        ) {
            "SOCIAL FHD" -> "1080 SOCIAL"
            "SOCIAL 60" -> "1080 60"
            "MASTER UHD" -> "4K MASTER"
            "UHD 60" -> "4K 60"
            "MASTER HDR" -> "4K HDR"
            "ACTION STAB" -> "ACTION"
            "LOW LIGHT" -> "NIGHT VIDEO"
            "FAST HD" -> "HD FAST"
            else -> "AUTO"
        }
    }

    private fun targetVideoBitrate(): Int {
        return when (
            qualityModes[
                qualityIndex
            ]
        ) {
            "SOCIAL FHD" -> 24_000_000
            "SOCIAL 60" -> 42_000_000
            "MASTER UHD" -> 64_000_000
            "UHD 60" -> 90_000_000
            "MASTER HDR" -> 72_000_000
            "ACTION STAB" -> 30_000_000
            "LOW LIGHT" -> 28_000_000
            "FAST HD" -> 12_000_000
            else -> 24_000_000
        }
    }

    private fun requestedVideoFps(): Int {
        return when (
            qualityModes[
                qualityIndex
            ]
        ) {
            "SOCIAL 60",
            "UHD 60" -> 60
            "LOW LIGHT" -> 0
            else -> 30
        }
    }

    private fun wantsVideoHdr(): Boolean {
        return qualityModes[
            qualityIndex
        ] == "MASTER HDR"
    }

    private fun wantsVideoStabilization(): Boolean {
        return when (
            qualityModes[
                qualityIndex
            ]
        ) {
            "SOCIAL FHD",
            "ACTION STAB",
            "LOW LIGHT" -> true
            else -> false
        }
    }

    private fun socialCameraStatus(): String {
        return buildString {
            append("CREATOR ENGINE • ")
            append(qualityDeckLabel())
            append(" • ")
            append(activeVideoFpsLabel)
            append(" • ")
            append(activeVideoStabilizationLabel)
            append(" • ")
            append(activeVideoDynamicRangeLabel)
            append(" • ")
            append(activeVideoAspectLabel)
            append(" • ")
            append(targetVideoBitrate() / 1_000_000)
            append("Mbps TARGET")
        }
    }
''',
    "REPORT quality helpers",
)

report = must_sub(
    report,
    r'''    private fun buildQualitySelector\(\):\n        QualitySelector \{.*?\n    \}\n\n    private fun applyScenePreset''',
    '''    private fun buildQualitySelector():
        QualitySelector {

        val ordered =
            when (
                qualityModes[
                    qualityIndex
                ]
            ) {
                "MASTER UHD",
                "UHD 60",
                "MASTER HDR" ->
                    listOf(
                        Quality.UHD,
                        Quality.FHD,
                        Quality.HD
                    )

                "FAST HD" ->
                    listOf(
                        Quality.HD,
                        Quality.FHD,
                        Quality.UHD
                    )

                else ->
                    listOf(
                        Quality.FHD,
                        Quality.UHD,
                        Quality.HD
                    )
            }

        return QualitySelector
            .fromOrderedList(
                ordered,
                FallbackStrategy
                    .lowerQualityOrHigherThan(
                        Quality.HD
                    )
            )
    }

    private fun applyScenePreset''',
    "REPORT quality selector",
)

report = must_replace(
    report,
    '''        overlayEffect = null

        val preview = Preview.Builder()
''',
    '''        overlayEffect = null

        val selector =
            if (useFront) {
                CameraSelector.DEFAULT_FRONT_CAMERA
            } else {
                CameraSelector.DEFAULT_BACK_CAMERA
            }

        val selectedCameraInfo =
            try {
                p.getCameraInfo(selector)
            } catch (_: Exception) {
                null
            }

        activeVideoFpsLabel =
            if (qualityModes[qualityIndex] == "LOW LIGHT") {
                "AUTO LOW-LIGHT FPS"
            } else {
                "AUTO FPS"
            }
        activeVideoStabilizationLabel = "STAB OFF"
        activeVideoDynamicRangeLabel = "SDR"
        activeVideoAspectLabel = "9:16 SOCIAL SAFE"

        val preview = Preview.Builder()
''',
    "REPORT capability prelude",
)

report = must_replace(
    report,
    '''        } else {
            val recorder = Recorder.Builder()
                .setQualitySelector(
                    buildQualitySelector()
                )
                .setTargetVideoEncodingBitRate(
                    targetVideoBitrate()
                )
                .build()

            videoCapture =
                VideoCapture.withOutput(
                    recorder
                )
        }
''',
    '''        } else {
            var selectedQualitySelector =
                buildQualitySelector()
            var selectedDynamicRange =
                DynamicRange.SDR
            var enableVideoStabilization =
                false

            if (selectedCameraInfo != null) {
                try {
                    val capabilities =
                        Recorder.getVideoCapabilities(
                            selectedCameraInfo
                        )

                    if (
                        wantsVideoHdr() &&
                        capabilities.supportedDynamicRanges.contains(
                            DynamicRange.HLG_10_BIT
                        )
                    ) {
                        val hdrQualities =
                            capabilities.getSupportedQualities(
                                DynamicRange.HLG_10_BIT
                            )

                        val orderedHdr =
                            listOf(
                                Quality.UHD,
                                Quality.FHD,
                                Quality.HD
                            ).filter {
                                hdrQualities.contains(it)
                            }

                        if (orderedHdr.isNotEmpty()) {
                            selectedQualitySelector =
                                QualitySelector.fromOrderedList(
                                    orderedHdr,
                                    FallbackStrategy
                                        .lowerQualityOrHigherThan(
                                            Quality.HD
                                        )
                                )
                            selectedDynamicRange =
                                DynamicRange.HLG_10_BIT
                            activeVideoDynamicRangeLabel =
                                "HLG10 HDR"
                        } else {
                            activeVideoDynamicRangeLabel =
                                "SDR HDR-FALLBACK"
                        }
                    } else if (wantsVideoHdr()) {
                        activeVideoDynamicRangeLabel =
                            "SDR HDR-FALLBACK"
                    }

                    enableVideoStabilization =
                        wantsVideoStabilization() &&
                            capabilities.isStabilizationSupported

                    activeVideoStabilizationLabel =
                        if (enableVideoStabilization) {
                            "STAB ON"
                        } else if (wantsVideoStabilization()) {
                            "STAB UNSUPPORTED"
                        } else {
                            "STAB OFF"
                        }
                } catch (_: Exception) {
                    activeVideoDynamicRangeLabel =
                        if (wantsVideoHdr()) {
                            "SDR HDR-FALLBACK"
                        } else {
                            "SDR"
                        }
                    activeVideoStabilizationLabel =
                        "STAB AUTO"
                }
            }

            val recorder =
                Recorder.Builder()
                    .setQualitySelector(
                        selectedQualitySelector
                    )
                    .setAspectRatio(
                        AspectRatio.RATIO_16_9
                    )
                    .setTargetVideoEncodingBitRate(
                        targetVideoBitrate()
                    )
                    .build()

            val videoBuilder =
                VideoCapture.Builder(
                    recorder
                )

            if (
                selectedDynamicRange !=
                DynamicRange.SDR
            ) {
                videoBuilder.setDynamicRange(
                    selectedDynamicRange
                )
            }

            if (enableVideoStabilization) {
                videoBuilder.setVideoStabilizationEnabled(
                    true
                )
            }

            videoCapture =
                videoBuilder.build()
        }
''',
    "REPORT Recorder engine",
)

report = must_replace(
    report,
    '''        val session =
            if (photoMode) {
                SessionConfig.Builder(
                    preview,
                    imageCapture!!
                )
                    .addEffect(
                        overlayEffect!!
                    )
                    .build()
            } else {
                SessionConfig.Builder(
                    preview,
                    videoCapture!!
                )
                    .addEffect(
                        overlayEffect!!
                    )
                    .build()
            }

        val selector = if (useFront) {
            CameraSelector.DEFAULT_FRONT_CAMERA
        } else {
            CameraSelector.DEFAULT_BACK_CAMERA
        }
''',
    '''        var session =
            if (photoMode) {
                SessionConfig.Builder(
                    preview,
                    imageCapture!!
                )
                    .addEffect(
                        overlayEffect!!
                    )
                    .build()
            } else {
                SessionConfig.Builder(
                    preview,
                    videoCapture!!
                )
                    .addEffect(
                        overlayEffect!!
                    )
                    .build()
            }

        if (!photoMode && selectedCameraInfo != null) {
            val requestedFps =
                requestedVideoFps()

            if (requestedFps > 0) {
                try {
                    val supportedRanges =
                        selectedCameraInfo
                            .getSupportedFrameRateRanges(
                                session
                            )

                    val exactRange =
                        supportedRanges.firstOrNull {
                            it.lower == requestedFps &&
                                it.upper == requestedFps
                        }

                    val compatibleRange =
                        exactRange
                            ?: supportedRanges
                                .filter {
                                    it.lower <= requestedFps &&
                                        it.upper >= requestedFps
                                }
                                .minByOrNull {
                                    it.upper - it.lower
                                }

                    if (compatibleRange != null) {
                        session =
                            SessionConfig.Builder(
                                preview,
                                videoCapture!!
                            )
                                .addEffect(
                                    overlayEffect!!
                                )
                                .setFrameRateRange(
                                    compatibleRange
                                )
                                .build()

                        activeVideoFpsLabel =
                            if (exactRange != null) {
                                "${requestedFps} FPS"
                            } else {
                                "${compatibleRange.lower}-${compatibleRange.upper} FPS"
                            }
                    } else {
                        activeVideoFpsLabel =
                            "AUTO FPS"
                    }
                } catch (_: Exception) {
                    activeVideoFpsLabel =
                        "AUTO FPS"
                }
            } else {
                activeVideoFpsLabel =
                    "AUTO LOW-LIGHT FPS"
            }
        }
''',
    "REPORT SessionConfig FPS",
)

report = must_replace(
    report,
    '''        formatView.text =
            "${qualityModes[qualityIndex]} • DEVICE FPS • SCENE ${sceneModes[sceneIndex]} • LOOK ${lookModes[lookIndex]}"
''',
    '''        formatView.text =
            "${qualityModes[qualityIndex]} • $activeVideoFpsLabel • $activeVideoStabilizationLabel • $activeVideoDynamicRangeLabel • SCENE ${sceneModes[sceneIndex]} • LOOK ${lookModes[lookIndex]}"
''',
    "REPORT operator status",
)

REPORT.write_text(report, encoding="utf-8")

# ============================================================
# LIVE CAMERA
# ============================================================
live = LIVE.read_text(encoding="utf-8")

live = must_replace(
    live,
    "import androidx.camera.core.CameraSelector\n",
    "import androidx.camera.core.CameraSelector\n"
    "import androidx.camera.core.AspectRatio\n"
    "import androidx.camera.core.DynamicRange\n",
    "LIVE CameraX imports",
)

live = must_replace(
    live,
    '''    private var quality = Quality.FHD
    private var qualityLabel = "FHD"
''',
    '''    private var quality = Quality.FHD
    private var qualityLabel = "SOCIAL 30"

    private val liveQualityProfiles =
        arrayOf(
            "SOCIAL 30",
            "SOCIAL 60",
            "UHD 30",
            "UHD 60",
            "HDR UHD",
            "ACTION STAB",
            "LOW LIGHT",
            "HD FAST"
        )

    private var liveQualityIndex = 0
    private var liveActiveFpsLabel = "AUTO FPS"
    private var liveActiveStabilizationLabel = "STAB AUTO"
    private var liveActiveDynamicRangeLabel = "SDR"
''',
    "LIVE quality state",
)

live = must_replace(
    live,
    '''                scaleType =
                    PreviewView.ScaleType.FILL_CENTER
''',
    '''                scaleType =
                    PreviewView.ScaleType.FIT_CENTER
''',
    "LIVE social-safe preview",
)

live = must_replace(
    live,
    '''        qualityButton =
            liveSettingButton(
                "QUALITY ▾\\nFHD",
                cyan
''',
    '''        qualityButton =
            liveSettingButton(
                "QUALITY ▾\\n${liveQualityProfiles[liveQualityIndex]}",
                cyan
''',
    "LIVE quality button",
)

live = must_replace(
    live,
    '''    private fun cycleProfile() {
''',
    '''    private fun liveSelectedQuality(): Quality {
        return when (
            liveQualityProfiles[
                liveQualityIndex
            ]
        ) {
            "UHD 30",
            "UHD 60",
            "HDR UHD" -> Quality.UHD
            "HD FAST" -> Quality.HD
            else -> Quality.FHD
        }
    }

    private fun liveTargetBitrate(): Int {
        return when (
            liveQualityProfiles[
                liveQualityIndex
            ]
        ) {
            "SOCIAL 30" -> 24_000_000
            "SOCIAL 60" -> 42_000_000
            "UHD 30" -> 64_000_000
            "UHD 60" -> 90_000_000
            "HDR UHD" -> 72_000_000
            "ACTION STAB" -> 30_000_000
            "LOW LIGHT" -> 28_000_000
            "HD FAST" -> 12_000_000
            else -> 24_000_000
        }
    }

    private fun liveRequestedFps(): Int {
        return when (
            liveQualityProfiles[
                liveQualityIndex
            ]
        ) {
            "SOCIAL 60",
            "UHD 60" -> 60
            "LOW LIGHT" -> 0
            else -> 30
        }
    }

    private fun liveWantsHdr(): Boolean {
        return liveQualityProfiles[
            liveQualityIndex
        ] == "HDR UHD"
    }

    private fun liveWantsStabilization(): Boolean {
        return when (
            liveQualityProfiles[
                liveQualityIndex
            ]
        ) {
            "SOCIAL 30",
            "ACTION STAB",
            "LOW LIGHT" -> true
            else -> false
        }
    }

    private fun syncLiveQualityState() {
        quality =
            liveSelectedQuality()
        qualityLabel =
            liveQualityProfiles[
                liveQualityIndex
            ]
    }

    private fun cycleProfile() {
''',
    "LIVE quality helpers",
)

live = must_sub(
    live,
    r'''    private fun cycleQuality\(\) \{.*?\n    \}\n\n    private fun toggleTorch''',
    '''    private fun cycleQuality() {
        if (recording != null) {
            toast(
                "Stop LIVE REC before changing quality"
            )
            return
        }

        liveQualityIndex =
            (liveQualityIndex + 1) %
                liveQualityProfiles.size

        syncLiveQualityState()

        qualityButton.text =
            "QUALITY ▾\\n${liveQualityProfiles[liveQualityIndex]}"

        saveLiveCameraPreferences()
        bindCamera()
    }

    private fun toggleTorch''',
    "LIVE cycle quality",
)

live = must_sub(
    live,
    r'''    private fun showLiveQualityDropdown\(\n        anchor: View\n    \) \{.*?\n    \}\n\n    private fun showLiveAudioDropdown''',
    '''    private fun showLiveQualityDropdown(
        anchor: View
    ) {
        if (recording != null) {
            toast(
                "Stop LIVE REC before changing quality"
            )
            return
        }

        showLivePillDropdown(
            anchor,
            "CREATOR QUALITY",
            liveQualityProfiles,
            liveQualityIndex
        ) { picked ->
            liveQualityIndex =
                picked

            syncLiveQualityState()

            qualityButton.text =
                "QUALITY ▾\\n${liveQualityProfiles[liveQualityIndex]}"

            saveLiveCameraPreferences()
            bindCamera()
        }
    }

    private fun showLiveAudioDropdown''',
    "LIVE quality dropdown",
)

live = must_replace(
    live,
    '''        val prefs =
            getSharedPreferences(
                "develop_uganda_live_camera",
                Context.MODE_PRIVATE
            )

        profileIndex =
''',
    '''        val prefs =
            getSharedPreferences(
                "develop_uganda_live_camera",
                Context.MODE_PRIVATE
            )

        liveQualityIndex =
            prefs.getInt(
                "live_quality_index",
                liveQualityIndex
            )
                .coerceIn(
                    0,
                    liveQualityProfiles.lastIndex
                )

        syncLiveQualityState()

        profileIndex =
''',
    "LIVE load quality",
)

live = must_replace(
    live,
    '''            .edit()
            .putInt(
                "profile_index",
''',
    '''            .edit()
            .putInt(
                "live_quality_index",
                liveQualityIndex
            )
            .putInt(
                "profile_index",
''',
    "LIVE save quality",
)

live = must_sub(
    live,
    r'''    private fun bindCamera\(\) \{.*?\n    \}\n\n    private fun drawLiveVideoEffect''',
    '''    private fun bindCamera() {
        val future =
            ProcessCameraProvider.getInstance(
                this
            )

        future.addListener(
            {
                val provider =
                    future.get()

                provider.unbindAll()

                val selector =
                    if (useFront) {
                        CameraSelector.DEFAULT_FRONT_CAMERA
                    } else {
                        CameraSelector.DEFAULT_BACK_CAMERA
                    }

                val selectedCameraInfo =
                    try {
                        provider.getCameraInfo(
                            selector
                        )
                    } catch (_: Exception) {
                        null
                    }

                liveActiveFpsLabel =
                    if (
                        liveQualityProfiles[
                            liveQualityIndex
                        ] == "LOW LIGHT"
                    ) {
                        "AUTO LOW-LIGHT FPS"
                    } else {
                        "AUTO FPS"
                    }
                liveActiveStabilizationLabel =
                    "STAB OFF"
                liveActiveDynamicRangeLabel =
                    "SDR"

                val preview =
                    Preview.Builder()
                        .build()
                        .also {
                            it.setSurfaceProvider(
                                previewView.surfaceProvider
                            )
                        }

                var selectedDynamicRange =
                    DynamicRange.SDR
                var enableVideoStabilization =
                    false
                var selectedQuality =
                    liveSelectedQuality()

                if (selectedCameraInfo != null) {
                    try {
                        val capabilities =
                            Recorder.getVideoCapabilities(
                                selectedCameraInfo
                            )

                        if (
                            liveWantsHdr() &&
                            capabilities.supportedDynamicRanges.contains(
                                DynamicRange.HLG_10_BIT
                            )
                        ) {
                            val hdrQualities =
                                capabilities.getSupportedQualities(
                                    DynamicRange.HLG_10_BIT
                                )

                            selectedQuality =
                                when {
                                    hdrQualities.contains(
                                        Quality.UHD
                                    ) -> Quality.UHD
                                    hdrQualities.contains(
                                        Quality.FHD
                                    ) -> Quality.FHD
                                    hdrQualities.contains(
                                        Quality.HD
                                    ) -> Quality.HD
                                    else -> selectedQuality
                                }

                            if (hdrQualities.isNotEmpty()) {
                                selectedDynamicRange =
                                    DynamicRange.HLG_10_BIT
                                liveActiveDynamicRangeLabel =
                                    "HLG10 HDR"
                            } else {
                                liveActiveDynamicRangeLabel =
                                    "SDR HDR-FALLBACK"
                            }
                        } else if (liveWantsHdr()) {
                            liveActiveDynamicRangeLabel =
                                "SDR HDR-FALLBACK"
                        }

                        enableVideoStabilization =
                            liveWantsStabilization() &&
                                capabilities.isStabilizationSupported

                        liveActiveStabilizationLabel =
                            if (enableVideoStabilization) {
                                "STAB ON"
                            } else if (liveWantsStabilization()) {
                                "STAB UNSUPPORTED"
                            } else {
                                "STAB OFF"
                            }
                    } catch (_: Exception) {
                        liveActiveDynamicRangeLabel =
                            if (liveWantsHdr()) {
                                "SDR HDR-FALLBACK"
                            } else {
                                "SDR"
                            }
                        liveActiveStabilizationLabel =
                            "STAB AUTO"
                    }
                }

                val recorder =
                    Recorder.Builder()
                        .setQualitySelector(
                            QualitySelector.from(
                                selectedQuality
                            )
                        )
                        .setAspectRatio(
                            AspectRatio.RATIO_16_9
                        )
                        .setTargetVideoEncodingBitRate(
                            liveTargetBitrate()
                        )
                        .build()

                val videoBuilder =
                    VideoCapture.Builder(
                        recorder
                    )

                if (
                    selectedDynamicRange !=
                    DynamicRange.SDR
                ) {
                    videoBuilder.setDynamicRange(
                        selectedDynamicRange
                    )
                }

                if (enableVideoStabilization) {
                    videoBuilder.setVideoStabilizationEnabled(
                        true
                    )
                }

                videoCapture =
                    videoBuilder.build()

                overlayEffect =
                    OverlayEffect(
                        CameraEffect.VIDEO_CAPTURE,
                        0,
                        Handler(
                            Looper.getMainLooper()
                        )
                    ) { throwable ->
                        toast(
                            "LIVE graphics warning: " +
                                (throwable.message ?: "unknown")
                        )
                    }.also { effect ->
                        effect.setOnDrawListener { frame ->
                            drawLiveBroadcastOverlay(
                                frame
                            )
                            true
                        }
                    }

                var session =
                    SessionConfig.Builder(
                        preview,
                        videoCapture!!
                    )
                        .addEffect(
                            overlayEffect!!
                        )
                        .build()

                if (selectedCameraInfo != null) {
                    val requestedFps =
                        liveRequestedFps()

                    if (requestedFps > 0) {
                        try {
                            val supportedRanges =
                                selectedCameraInfo
                                    .getSupportedFrameRateRanges(
                                        session
                                    )

                            val exactRange =
                                supportedRanges.firstOrNull {
                                    it.lower == requestedFps &&
                                        it.upper == requestedFps
                                }

                            val compatibleRange =
                                exactRange
                                    ?: supportedRanges
                                        .filter {
                                            it.lower <= requestedFps &&
                                                it.upper >= requestedFps
                                        }
                                        .minByOrNull {
                                            it.upper - it.lower
                                        }

                            if (compatibleRange != null) {
                                session =
                                    SessionConfig.Builder(
                                        preview,
                                        videoCapture!!
                                    )
                                        .addEffect(
                                            overlayEffect!!
                                        )
                                        .setFrameRateRange(
                                            compatibleRange
                                        )
                                        .build()

                                liveActiveFpsLabel =
                                    if (exactRange != null) {
                                        "${requestedFps} FPS"
                                    } else {
                                        "${compatibleRange.lower}-${compatibleRange.upper} FPS"
                                    }
                            } else {
                                liveActiveFpsLabel =
                                    "AUTO FPS"
                            }
                        } catch (_: Exception) {
                            liveActiveFpsLabel =
                                "AUTO FPS"
                        }
                    } else {
                        liveActiveFpsLabel =
                            "AUTO LOW-LIGHT FPS"
                    }
                }

                camera =
                    provider.bindToLifecycle(
                        this,
                        selector,
                        session
                    )

                camera
                    ?.cameraInfo
                    ?.exposureState
                    ?.let { exposure ->
                        if (
                            exposure.isExposureCompensationSupported
                        ) {
                            camera
                                ?.cameraControl
                                ?.setExposureCompensationIndex(
                                    0.coerceIn(
                                        exposure.exposureCompensationRange.lower,
                                        exposure.exposureCompensationRange.upper
                                    )
                                )
                        }
                    }

                quality =
                    selectedQuality
                qualityLabel =
                    liveQualityProfiles[
                        liveQualityIndex
                    ]

                camLamp.setTextColor(
                    green
                )

                updateTimer()
            },
            ContextCompat.getMainExecutor(
                this
            )
        )
    }

    private fun drawLiveVideoEffect''',
    "LIVE camera engine bind",
)

live = must_replace(
    live,
    '''            livePreviewTech.text =
                "TC ${liveTimecode()} • $qualityLabel • MIC ${audioPercent}% • NET ${
''',
    '''            livePreviewTech.text =
                "TC ${liveTimecode()} • $qualityLabel • $liveActiveFpsLabel • $liveActiveStabilizationLabel • $liveActiveDynamicRangeLabel • MIC ${audioPercent}% • NET ${
''',
    "LIVE preview status",
)

live = live.replace(
    'append("SOCIAL CAMERA: FHD PREFERRED • 20Mbps @ FHD • DEVICE AE/AF/AWB\\n")',
    'append("CREATOR ENGINE: ${liveQualityProfiles[liveQualityIndex]} • $liveActiveFpsLabel • $liveActiveStabilizationLabel • $liveActiveDynamicRangeLabel • 9:16 SOCIAL SAFE\\n")',
)

LIVE.write_text(live, encoding="utf-8")

# ============================================================
# HOME / VERSION
# ============================================================
home = HOME.read_text(encoding="utf-8")

home = home.replace(
    '"MIDNIGHT NAVY UI • V202"',
    '"CREATOR CAMERA ENGINE • V203"',
    1,
)
home = home.replace(
    '"SOCIAL CAMERA ENGINE",\n                "SIDE HUD REPORT OVERLAY • DYNAMIC MOVING DATA • GLOWING LIVE FEED SIGNAL • HIGH BITRATE SOCIAL VIDEO"',
    '"CREATOR CAMERA ENGINE",\n                "1080P/4K • 30/60 FPS WHEN SUPPORTED • HLG10 HDR • STABILIZED ACTION • LOW-LIGHT AUTO FPS • 9:16 SOCIAL SAFE"',
    1,
)
home = home.replace(
    '"FIELD REPORT • bigger side-positioned dynamic telemetry • static rows removed • clearer moving data • presets"',
    '"FIELD REPORT • SOCIAL 30/60 • 4K 30/60 • HDR master • stabilized action • low-light creator modes • telemetry"',
    1,
)
home = home.replace(
    '"LIVE STUDIO • glowing blinking LIVE FEED REC signal burned into saved video • 1080p/high-bitrate tune • VIDEO FX"',
    '"LIVE STUDIO • SOCIAL 30/60 • UHD 30/60 • HDR • action stabilization • low-light profile • LIVE graphics"',
    1,
)

HOME.write_text(home, encoding="utf-8")

gradle = GRADLE.read_text(encoding="utf-8")
gradle = re.sub(
    r"versionCode\s*=\s*\d+",
    "versionCode = 20300",
    gradle,
    count=1,
)
gradle = re.sub(
    r'versionName\s*=\s*"[^"]+"',
    'versionName = "203.0-creator-camera-engine"',
    gradle,
    count=1,
)
GRADLE.write_text(gradle, encoding="utf-8")

print("V203 Creator Camera Engine patch applied.")
