from pathlib import Path
import re

ROOT = Path("v172-source/app")
HOME = ROOT / "src/main/java/com/sentongoharuna/pulse/DevelopUgandaNewsroomActivity.kt"
GRADLE = ROOT / "build.gradle.kts"

def must_replace(text, old, new, label):
    if old not in text:
        raise SystemExit(f"V210 patch anchor missing: {label}")
    return text.replace(old, new, 1)

home = HOME.read_text(encoding="utf-8")

# V210: preserve every camera module from V204 onward and expose them
# as an expandable Home-page module list. Selecting a row opens the
# current REPORT camera; it does NOT disable newer modules.
home = home.replace(
    '"NIGHT INTELLIGENCE PRO • V209"',
    '"CAMERA MODULE HUB • V210"',
    1,
)

home = home.replace(
    '"SOCIAL FHD/60 • SOCIAL HDR • 4K 30/60 • ACTION 30/60 • HLG10 HDR • HORIZON/SHAKE GUARDS • AMBIENT-LIGHT NIGHT ADVISOR • 9:16 SAFE"',
    '"V204→V209 ALL RETAINED • SOCIAL/HDR/4K/ACTION • AF/METER • HORIZON • STEADYSHOT • NIGHT INTELLIGENCE • 9:16 SAFE"',
    1,
)

home = home.replace(
    '"FIELD REPORT • AF/METER LOCK • HORIZON + SHAKE GUARDS • LIVE LUX SENSOR • LOW-LIGHT/30FPS ADVICE • SOCIAL/HDR/4K/ACTION • telemetry"',
    '"FIELD REPORT • ALL PRO CAMERA MODULES ACTIVE • SOCIAL/HDR/4K/ACTION • AF/METER • HORIZON • STEADYSHOT • NIGHT INTELLIGENCE • telemetry"',
    1,
)

module_block = '''        page.addView(
            sectionTitle(
                "PRO CAMERA MODULES"
            )
        )

        val cameraModulePanel =
            LinearLayout(this).apply {
                orientation =
                    LinearLayout.VERTICAL

                visibility =
                    View.GONE

                setPadding(
                    0,
                    dp(4),
                    0,
                    dp(8)
                )
            }

        val cameraModuleButton =
            smallClipButton(
                "CAMERA MODULES ▾  •  ALL PRO ACTIVE",
                gold
            ) {
                cameraModulePanel.visibility =
                    if (
                        cameraModulePanel.visibility ==
                            View.VISIBLE
                    ) {
                        View.GONE
                    } else {
                        View.VISIBLE
                    }
            }

        page.addView(
            cameraModuleButton,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(48)
            ).apply {
                bottomMargin =
                    dp(6)
            }
        )

        val cameraModules =
            listOf(
                Triple(
                    "✓ ALL PRO • V210",
                    "Every camera module below remains active together. New camera versions should be appended here, not replace older tools.",
                    green
                ),
                Triple(
                    "✓ V204 • SOCIAL MASTER PRO",
                    "Social FHD/60 • Social HDR • 4K 30/60 • Action 30/60 • Low Light • capability-aware fallbacks.",
                    cyan
                ),
                Triple(
                    "✓ V205 • PRO FOCUS ASSIST",
                    "Tap autofocus • long-press persistent focus lock for interviews, buildings and fixed-distance subjects.",
                    gold
                ),
                Triple(
                    "✓ V206 • PRO METERING LOCK",
                    "Long-press AF + AE + AWB metering lock with an operator focus/metering reticle.",
                    gold
                ),
                Triple(
                    "✓ V207 • HORIZON GUARD PRO",
                    "Live roll-based horizon guide: LEVEL LOCK • LEVEL NEAR • ADJUST.",
                    green
                ),
                Triple(
                    "✓ V208 • STEADYSHOT GUARD PRO",
                    "Sensor-derived STEADY • MOVING • SHAKE guidance alongside real device stabilization.",
                    cyan
                ),
                Triple(
                    "✓ V209 • NIGHT INTELLIGENCE PRO",
                    "Ambient-light lux advisor: BRIGHT • NORMAL • DIM • DARK with Low Light / 30 fps guidance.",
                    red
                )
            )

        cameraModules.forEach {
                module ->
            cameraModulePanel.addView(
                compactStatus(
                    module.first,
                    module.second,
                    module.third
                ).apply {
                    isClickable =
                        true

                    isFocusable =
                        true

                    setOnClickListener {
                        Toast.makeText(
                            this@DevelopUgandaNewsroomActivity,
                            "${module.first} • ACTIVE IN V210",
                            Toast.LENGTH_SHORT
                        ).show()

                        openReportCamera()
                    }
                }
            )
        }

        page.addView(
            cameraModulePanel
        )

        page.addView(
            compactStatus(
                "V210 MODULE POLICY",
                "NOTHING DROPPED • V204→V209 RETAINED • FUTURE CAMERA FEATURES APPEND TO THIS MODULE HUB",
                green
            )
        )

'''

anchor = '''        val quickLaunch =
            LinearLayout(this).apply {
'''

if "CAMERA MODULES ▾  •  ALL PRO ACTIVE" not in home:
    if anchor not in home:
        raise SystemExit("V210 patch anchor missing: quickLaunch")
    home = home.replace(
        anchor,
        module_block + anchor,
        1,
    )

HOME.write_text(home, encoding="utf-8")

gradle = GRADLE.read_text(encoding="utf-8")
gradle = re.sub(
    r"versionCode\s*=\s*\d+",
    "versionCode = 21000",
    gradle,
    count=1,
)
gradle = re.sub(
    r'versionName\s*=\s*"[^"]+"',
    'versionName = "210.0-camera-module-hub"',
    gradle,
    count=1,
)
GRADLE.write_text(gradle, encoding="utf-8")

print("V210 Camera Module Hub patch applied.")
