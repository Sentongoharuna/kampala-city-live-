from pathlib import Path
import re

ROOT = Path("v172-source/app")
REPORT = ROOT / "src/main/java/com/sentongoharuna/pulse/DevelopUgandaCameraActivity.kt"
LIVE = ROOT / "src/main/java/com/sentongoharuna/pulse/DevelopUgandaLiveActivity.kt"
HOME = ROOT / "src/main/java/com/sentongoharuna/pulse/DevelopUgandaNewsroomActivity.kt"
GRADLE = ROOT / "build.gradle.kts"

def must_replace(text, old, new, label):
    if old not in text:
        raise SystemExit(f"V212 patch anchor missing: {label}")
    return text.replace(old, new, 1)

# ============================================================
# V212 — VERIFIED CAMERA STATE
# No decorative-only claim. Operator text is generated from the
# actual runtime CameraX/sensor/audio states. Recorded REPORT and
# LIVE output visibly carries V212. Report filename and SHA-256 JSON
# also carry the recording engine version.
# ============================================================

report = REPORT.read_text(encoding="utf-8")

# Operator preview itself visibly identifies the engine version.
report = must_replace(
    report,
    '''        previewBrandView =
            hud(
                "develop.uganda",
''',
    '''        previewBrandView =
            hud(
                "develop.uganda • V212",
''',
    "REPORT operator version brand",
)

# Add one real-state summary sourced from the actual variables maintained by
# V204-V211. This is not a mock module list.
report = must_replace(
    report,
    '''    private fun socialCameraStatus(): String {
''',
    '''    private fun verifiedCameraStateText(): String {
        val rollText =
            phoneRollDeg?.let {
                String.format(
                    Locale.US,
                    "%+.1f°",
                    it
                )
            } ?: "--"

        val luxText =
            ambientLux?.let {
                String.format(
                    Locale.US,
                    "%.0fLUX",
                    it
                )
            } ?: "--"

        return buildString {
            append("V212 VERIFIED")
            append(" • ")
            append(qualityDeckLabel())
            append(" • ")
            append(activeVideoFpsLabel)
            append(" • ")
            append(activeVideoStabilizationLabel)
            append(" • ")
            append(activeVideoDynamicRangeLabel)
            append(" • ")
            append(focusAssistLabel())
            append(" • H ")
            append(rollText)
            append(" • ")
            append(motionGuardLabel())
            append(" • ")
            append(ambientLightLabel())
            append(" ")
            append(luxText)
            append(" • AUDIO ")
            append(audioGuardLabel())
        }
    }

    private fun socialCameraStatus(): String {
''',
    "REPORT verified runtime state helper",
)

# Camera interface tag always shows which engine is operating.
report = must_replace(
    report,
    '''            previewTagView.text =
                sceneTag()
''',
    '''            previewTagView.text =
                "${sceneTag()} • V212 VERIFIED"
''',
    "REPORT preview tag version",
)

# Replace generic format status with the live runtime state, while preserving
# current scene/look information.
report = must_replace(
    report,
    '''        formatView.text =
            "${qualityModes[qualityIndex]} • $activeVideoFpsLabel • $activeVideoStabilizationLabel • $activeVideoDynamicRangeLabel • ${focusAssistLabel()} • SCENE ${sceneModes[sceneIndex]} • LOOK ${lookModes[lookIndex]}"
''',
    '''        formatView.text =
            "${verifiedCameraStateText()} • SCENE ${sceneModes[sceneIndex]} • LOOK ${lookModes[lookIndex]}"
''',
    "REPORT verified status line",
)

# The actual burned-in REPORT video now visibly identifies V212 beside the tag.
report = must_replace(
    report,
    '''        drawStrongRecordedText(
            c,
            sceneTag(),
            safeLeft +
                brandWidth +
                (11f * u),
            y,
            text
        )
''',
    '''        drawStrongRecordedText(
            c,
            "${sceneTag()} • V212",
            safeLeft +
                brandWidth +
                (11f * u),
            y,
            text
        )
''',
    "REPORT recorded V212 burn-in",
)

# Version the actual MediaStore filename as well.
report = must_replace(
    report,
    '''        baseName = "DEVELOP_UGANDA_${reportId}_${sceneModes[sceneIndex]}_${lookModes[lookIndex]}_" +
''',
    '''        baseName = "DEVELOP_UGANDA_V212_${reportId}_${sceneModes[sceneIndex]}_${lookModes[lookIndex]}_" +
''',
    "REPORT versioned filename",
)

# Correct the old integrity JSON app version and add camera-engine lineage.
report = must_replace(
    report,
    '''                        put(
                            "app_version",
                            "V188"
                        )
''',
    '''                        put(
                            "app_version",
                            "V212"
                        )
                        put(
                            "camera_engine",
                            "V212 VERIFIED CAMERA STATE"
                        )
                        put(
                            "camera_modules",
                            "V204,V205,V206,V207,V208,V209,V210,V211,V212"
                        )
''',
    "REPORT integrity version",
)

REPORT.write_text(report, encoding="utf-8")

# ============================================================
# LIVE — visible V212 interface + recorded V212 burn-in + filename
# ============================================================

live = LIVE.read_text(encoding="utf-8")

# Live operator interface version.
live = must_replace(
    live,
    '''        liveTitle =
            label(
                "develop.uganda",
''',
    '''        liveTitle =
            label(
                "develop.uganda • V212",
''',
    "LIVE operator version brand",
)

# Real live-state summary sourced from active CameraX and audio states.
live = must_replace(
    live,
    '''    private fun liveAudioGuardLabel(): String {
''',
    '''    private fun liveVerifiedStateText(): String {
        return buildString {
            append("V212 VERIFIED")
            append(" • ")
            append(qualityLabel)
            append(" • ")
            append(liveActiveFpsLabel)
            append(" • ")
            append(liveActiveStabilizationLabel)
            append(" • ")
            append(liveActiveDynamicRangeLabel)
            append(" • AUDIO ")
            append(liveAudioGuardLabel())
        }
    }

    private fun liveAudioGuardLabel(): String {
''',
    "LIVE verified runtime state helper",
)

# Prefix the existing live technical row with real-state summary.
live = must_replace(
    live,
    '''            livePreviewTech.text =
                "TC ${liveTimecode()} • $qualityLabel • $liveActiveFpsLabel • $liveActiveStabilizationLabel • $liveActiveDynamicRangeLabel • AUDIO ${liveAudioGuardLabel()} ${audioPercent}% • NET ${
''',
    '''            livePreviewTech.text =
                "${liveVerifiedStateText()} • TC ${liveTimecode()} • AUDIO ${audioPercent}% • NET ${
''',
    "LIVE verified tech row",
)

# Burn V212 visibly into the saved LIVE video.
live = must_replace(
    live,
    '''        drawStrongLiveText(
            canvas,
            "develop.uganda",
            safeLeft +
                (23f * u),
            safeTop,
            paint
        )
''',
    '''        drawStrongLiveText(
            canvas,
            "develop.uganda • V212",
            safeLeft +
                (23f * u),
            safeTop,
            paint
        )
''',
    "LIVE recorded V212 brand",
)

# Also include version on the lower-third footer of saved LIVE output.
live = must_replace(
    live,
    '''            "REPORTER • $reporterName   |   STORY • $storyId   |   develop.uganda",
''',
    '''            "REPORTER • $reporterName   |   STORY • $storyId   |   develop.uganda • V212",
''',
    "LIVE recorded lower third version",
)

# Version the LIVE MediaStore filename.
live = must_replace(
    live,
    '''        liveRecordingName =
            "DEVELOP_UGANDA_LIVE_${profiles[profileIndex]}_$stamp"
''',
    '''        liveRecordingName =
            "DEVELOP_UGANDA_V212_LIVE_${profiles[profileIndex]}_$stamp"
''',
    "LIVE versioned filename",
)

LIVE.write_text(live, encoding="utf-8")

# ============================================================
# HOME MODULE HUB — fix the list so every version V204-V212 is
# actually represented. V210 was previously the hub itself rather
# than a separate row; V212 makes it explicit.
# ============================================================

home = HOME.read_text(encoding="utf-8")

home = home.replace(
    '"AUDIO GUARD PRO • V211"',
    '"VERIFIED CAMERA STATE • V212"',
    1,
)

home = home.replace(
    '"V204→V211 ALL RETAINED • SOCIAL/HDR/4K/ACTION • AF/METER • HORIZON • STEADYSHOT • NIGHT INTELLIGENCE • AUDIO GUARD • 9:16 SAFE"',
    '"V204→V212 ALL RETAINED • SOCIAL/HDR/4K/ACTION • AF/METER • HORIZON • STEADYSHOT • NIGHT INTELLIGENCE • AUDIO GUARD • VERIFIED STATE • 9:16 SAFE"',
    1,
)

home = home.replace(
    '"FIELD REPORT • ALL PRO CAMERA MODULES ACTIVE • SOCIAL/HDR/4K/ACTION • AF/METER • HORIZON • STEADYSHOT • NIGHT INTELLIGENCE • AUDIO GUARD • telemetry"',
    '"FIELD REPORT • V212 VERIFIED RUNTIME STATE • ALL V204→V211 MODULES RETAINED • LIVE CAMERA/SENSOR/AUDIO VALUES • VERSIONED VIDEO • telemetry"',
    1,
)

home = home.replace(
    '"✓ ALL PRO • V210"',
    '"✓ ALL PRO • V212"',
    1,
)

home = home.replace(
    '"Every camera module below remains active together. V211 adds Audio Guard without replacing V204–V210. Future camera versions append here too."',
    '"Every camera module below remains active together. V212 now verifies real runtime state and versions the actual recorded output without replacing V204–V211."',
    1,
)

home = must_replace(
    home,
    '''                Triple(
                    "✓ V211 • AUDIO GUARD PRO",
                    "REPORT + LIVE microphone guidance: LOW • GOOD • HOT • CLIP RISK with current and peak levels.",
                    green
                )
''',
    '''                Triple(
                    "✓ V210 • CAMERA MODULE HUB",
                    "Home dropdown that keeps camera generations available instead of replacing them.",
                    gold
                ),
                Triple(
                    "✓ V211 • AUDIO GUARD PRO",
                    "REPORT + LIVE microphone guidance: LOW • GOOD • HOT • CLIP RISK with current and peak levels.",
                    green
                ),
                Triple(
                    "✓ V212 • VERIFIED CAMERA STATE",
                    "Uses real runtime CameraX, sensor and audio values; interface, saved video, filename and integrity record identify V212.",
                    cyan
                )
''',
    "HOME explicit V210 and V212 rows",
)

home = home.replace(
    '"NOTHING DROPPED • V204→V211 RETAINED • FUTURE CAMERA FEATURES APPEND TO THIS MODULE HUB"',
    '"NOTHING DROPPED • V204→V212 RETAINED • NEW MODULES MUST HAVE REAL RUNTIME BEHAVIOUR BEFORE THEY ARE SHOWN AS ACTIVE"',
    1,
)

HOME.write_text(home, encoding="utf-8")

# ============================================================
# APP VERSION
# ============================================================

gradle = GRADLE.read_text(encoding="utf-8")
gradle = re.sub(
    r"versionCode\s*=\s*\d+",
    "versionCode = 21200",
    gradle,
    count=1,
)
gradle = re.sub(
    r'versionName\s*=\s*"[^"]+"',
    'versionName = "212.0-verified-camera-state"',
    gradle,
    count=1,
)
GRADLE.write_text(gradle, encoding="utf-8")

print("V212 Verified Camera State patch applied.")
