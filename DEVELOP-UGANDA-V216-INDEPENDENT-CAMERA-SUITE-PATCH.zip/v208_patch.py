from pathlib import Path
import re

ROOT = Path("v172-source/app")
REPORT = ROOT / "src/main/java/com/sentongoharuna/pulse/DevelopUgandaCameraActivity.kt"
HOME = ROOT / "src/main/java/com/sentongoharuna/pulse/DevelopUgandaNewsroomActivity.kt"
GRADLE = ROOT / "build.gradle.kts"

def must_replace(text, old, new, label):
    if old not in text:
        raise SystemExit(f"V208 patch anchor missing: {label}")
    return text.replace(old, new, 1)

# ============================================================
# V208 — STEADYSHOT GUARD PRO
# Sensor-derived operator shake guidance for cleaner video.
# It does NOT fake or replace optical/electronic stabilization.
# ============================================================

report = REPORT.read_text(encoding="utf-8")

# Add operator motion guard view.
report = must_replace(
    report,
    '''    private lateinit var focusReticleView: TextView
    private lateinit var horizonGuardView: TextView

    private lateinit var brandView: TextView
''',
    '''    private lateinit var focusReticleView: TextView
    private lateinit var horizonGuardView: TextView
    private lateinit var motionGuardView: TextView

    private lateinit var brandView: TextView
''',
    "REPORT motion guard field",
)

# Add shake telemetry state beside orientation sensor data.
report = must_replace(
    report,
    '''    @Volatile private var compassAzimuthDeg: Float? = null
    @Volatile private var phonePitchDeg: Float? = null
    @Volatile private var phoneRollDeg: Float? = null
    @Volatile private var gnssSatellitesVisible = -1
''',
    '''    @Volatile private var compassAzimuthDeg: Float? = null
    @Volatile private var phonePitchDeg: Float? = null
    @Volatile private var phoneRollDeg: Float? = null
    @Volatile private var cameraShakeScore = 0f
    @Volatile private var lastMotionSampleMs = 0L
    @Volatile private var gnssSatellitesVisible = -1
''',
    "REPORT shake sensor state",
)

# Place the motion guard immediately below the center horizon guide.
report = must_replace(
    report,
    '''        root.addView(
            horizonGuardView,
            FrameLayout.LayoutParams(
                dp(270),
                dp(34),
                Gravity.CENTER
            )
        )

        // V187 PREVIEW HUD:
''',
    '''        root.addView(
            horizonGuardView,
            FrameLayout.LayoutParams(
                dp(270),
                dp(34),
                Gravity.CENTER
            )
        )

        motionGuardView =
            TextView(this).apply {
                text =
                    "STEADYSHOT • --"

                textSize =
                    8.0f

                gravity =
                    Gravity.CENTER

                typeface =
                    Typeface.MONOSPACE

                setTextColor(
                    0xFFAEB7C7.toInt()
                )

                setPadding(
                    dp(9),
                    dp(4),
                    dp(9),
                    dp(4)
                )

                background =
                    GradientDrawable().apply {
                        shape =
                            GradientDrawable.RECTANGLE

                        cornerRadius =
                            dp(14).toFloat()

                        setColor(
                            0x42031829
                        )

                        setStroke(
                            dp(1),
                            0x607A91A4
                        )
                    }
            }

        val motionParams =
            FrameLayout.LayoutParams(
                dp(170),
                dp(30),
                Gravity.CENTER
            ).apply {
                topMargin =
                    dp(54)
            }

        root.addView(
            motionGuardView,
            motionParams
        )

        // V187 PREVIEW HUD:
''',
    "REPORT motion guard UI",
)

# Add motion-guard logic before horizon update.
report = must_replace(
    report,
    '''    private fun updateHorizonGuard() {
''',
    '''    private fun motionGuardLabel(): String {
        return when {
            cameraShakeScore <=
                8f ->
                    "STEADY"

            cameraShakeScore <=
                22f ->
                    "MOVING"

            else ->
                "SHAKE"
        }
    }

    private fun updateMotionGuard() {
        if (
            !::motionGuardView.isInitialized
        ) {
            return
        }

        if (
            operatorControlsHidden ||
            cleanModeEnabled
        ) {
            motionGuardView.visibility =
                View.GONE

            return
        }

        motionGuardView.visibility =
            View.VISIBLE

        val label =
            motionGuardLabel()

        motionGuardView.text =
            String.format(
                Locale.US,
                "STEADYSHOT • %s • %.0f",
                label,
                cameraShakeScore
            )

        motionGuardView.setTextColor(
            when (label) {
                "STEADY" ->
                    0xFF91B6A0.toInt()

                "MOVING" ->
                    0xFFAEBDEB.toInt()

                else ->
                    0xFFC76D73.toInt()
            }
        )
    }

    private fun updateHorizonGuard() {
''',
    "REPORT motion guard update",
)

# Refresh both operator guides.
report = must_replace(
    report,
    '''    private fun refreshHud() {
        updateHorizonGuard()

        timecodeView.text =
''',
    '''    private fun refreshHud() {
        updateHorizonGuard()
        updateMotionGuard()

        timecodeView.text =
''',
    "REPORT motion guard refresh",
)

# Add motion label to operator health line.
report = must_replace(
    report,
    '''            previewHealthView.text =
                recordingHealthText()
''',
    '''            previewHealthView.text =
                "${recordingHealthText()} • ${motionGuardLabel()}"
''',
    "REPORT motion health label",
)

# Compute smoothed shake from changes in rotation-vector orientation.
report = must_replace(
    report,
    '''            compassAzimuthDeg =
                (
                    (azimuth % 360f) +
                        360f
                    ) % 360f
            phonePitchDeg = pitch
            phoneRollDeg = roll
''',
    '''            val previousAzimuth =
                compassAzimuthDeg
            val previousPitch =
                phonePitchDeg
            val previousRoll =
                phoneRollDeg

            val normalizedAzimuth =
                (
                    (azimuth % 360f) +
                        360f
                    ) % 360f

            compassAzimuthDeg =
                normalizedAzimuth
            phonePitchDeg =
                pitch
            phoneRollDeg =
                roll

            val now =
                SystemClock.elapsedRealtime()

            if (
                previousAzimuth !=
                    null &&
                previousPitch !=
                    null &&
                previousRoll !=
                    null &&
                lastMotionSampleMs >
                    0L
            ) {
                val dt =
                    (
                        now -
                            lastMotionSampleMs
                        ).coerceAtLeast(
                            1L
                        )

                val azRaw =
                    kotlin.math.abs(
                        normalizedAzimuth -
                            previousAzimuth
                    )

                val azDelta =
                    minOf(
                        azRaw,
                        360f -
                            azRaw
                    )

                val rollDelta =
                    kotlin.math.abs(
                        roll -
                            previousRoll
                    )

                val pitchDelta =
                    kotlin.math.abs(
                        pitch -
                            previousPitch
                    )

                val scale =
                    (
                        16.67f /
                            dt.toFloat()
                        ).coerceIn(
                            0.35f,
                            2.5f
                        )

                val rawScore =
                    (
                        (
                            rollDelta +
                                pitchDelta +
                                (
                                    azDelta *
                                        0.35f
                                    )
                            ) *
                            4.2f *
                            scale
                        ).coerceIn(
                            0f,
                            100f
                        )

                cameraShakeScore =
                    (
                        cameraShakeScore *
                            0.72f
                        ) +
                        (
                            rawScore *
                                0.28f
                            )
            }

            lastMotionSampleMs =
                now
''',
    "REPORT shake calculation",
)

# Surface feature in creator engine status.
report = must_replace(
    report,
    '''            append(" • HORIZON GUARD")
        }
    }
''',
    '''            append(" • HORIZON GUARD")
            append(" • STEADYSHOT ")
            append(
                motionGuardLabel()
            )
        }
    }
''',
    "REPORT creator status shake",
)

REPORT.write_text(report, encoding="utf-8")

# ============================================================
# HOME / VERSION
# ============================================================

home = HOME.read_text(encoding="utf-8")

home = home.replace(
    '"HORIZON GUARD PRO • V207"',
    '"STEADYSHOT GUARD PRO • V208"',
    1,
)

home = home.replace(
    '"SOCIAL FHD/60 • SOCIAL HDR • 4K 30/60 • ACTION 30/60 • HLG10 HDR • AF+AE+AWB METER LOCK • LIVE HORIZON GUARD • 9:16 SOCIAL SAFE"',
    '"SOCIAL FHD/60 • SOCIAL HDR • 4K 30/60 • ACTION 30/60 • HLG10 HDR • AF+AE+AWB LOCK • HORIZON + SHAKE GUARDS • 9:16 SOCIAL SAFE"',
    1,
)

home = home.replace(
    '"FIELD REPORT • TAP AF • AF+AE+AWB METER LOCK • LIVE HORIZON GUIDE • SOCIAL/HDR/4K/ACTION/LOW LIGHT • telemetry"',
    '"FIELD REPORT • TAP AF • METER LOCK • LIVE HORIZON GUIDE • STEADY/MOVING/SHAKE SENSOR GUARD • SOCIAL/HDR/4K/ACTION/LOW LIGHT • telemetry"',
    1,
)

HOME.write_text(home, encoding="utf-8")

gradle = GRADLE.read_text(encoding="utf-8")
gradle = re.sub(
    r"versionCode\s*=\s*\d+",
    "versionCode = 20800",
    gradle,
    count=1,
)
gradle = re.sub(
    r'versionName\s*=\s*"[^"]+"',
    'versionName = "208.0-steadyshot-guard-pro"',
    gradle,
    count=1,
)
GRADLE.write_text(gradle, encoding="utf-8")

print("V208 SteadyShot Guard Pro patch applied.")
