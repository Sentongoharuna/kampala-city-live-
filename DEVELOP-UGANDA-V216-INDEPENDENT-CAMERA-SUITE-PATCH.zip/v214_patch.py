from pathlib import Path
import re

ROOT = Path("v172-source/app")
REPORT = ROOT / "src/main/java/com/sentongoharuna/pulse/DevelopUgandaCameraActivity.kt"
LIVE = ROOT / "src/main/java/com/sentongoharuna/pulse/DevelopUgandaLiveActivity.kt"
HOME = ROOT / "src/main/java/com/sentongoharuna/pulse/DevelopUgandaNewsroomActivity.kt"
GRADLE = ROOT / "build.gradle.kts"

def must_replace(text, old, new, label):
    if old not in text:
        raise SystemExit(f"V214 patch anchor missing: {label}")
    return text.replace(old, new, 1)

# ============================================================
# V214 — MODE SIGNATURE PRO
#
# Goal:
# - Keep every V204-V213 behaviour.
# - Make the operator preview visibly but subtly change by the
#   ACTUAL selected look/mode, instead of every mode looking the same.
# - Use an operator-only low-alpha preview tone approximation.
# - Quality modes get distinct accent identity, but we DO NOT fake
#   resolution/HDR/frame-rate by changing pixels.
# - Recorded REPORT/LIVE video burns in the exact selected mode and V214.
# ============================================================

report = REPORT.read_text(encoding="utf-8")

# Preview tuning layer field.
report = must_replace(
    report,
    '''    private lateinit var audioGuardView: TextView
    private lateinit var thermalGuardView: TextView

    private lateinit var brandView: TextView
''',
    '''    private lateinit var audioGuardView: TextView
    private lateinit var thermalGuardView: TextView
    private lateinit var previewModeToneView: View

    private lateinit var brandView: TextView
''',
    "REPORT preview mode tone field",
)

# Insert transparent operator preview tone directly above PreviewView but
# below all later controls/HUD. It does not enter the CameraX VIDEO target.
report = must_replace(
    report,
    '''        root.addView(
            previewView,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        focusReticleView =
''',
    '''        root.addView(
            previewView,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        previewModeToneView =
            View(this).apply {
                isClickable =
                    false

                isFocusable =
                    false

                setBackgroundColor(
                    Color.TRANSPARENT
                )
            }

        root.addView(
            previewModeToneView,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        focusReticleView =
''',
    "REPORT operator tone layer",
)

# Add real selected-mode identity helpers before thermal helper.
report = must_replace(
    report,
    '''    private fun thermalStateLabel(): String {
''',
    '''    private fun previewLookTintColor(): Int {
        // Very low alpha on purpose: this is an operator preview cue.
        // The recorded creative look is still produced by drawCreativeLook().
        return when (
            lookModes[
                lookIndex
            ]
        ) {
            "WARM" ->
                0x10FF8A3D.toInt()

            "COOL" ->
                0x10007AFF.toInt()

            "TEAL" ->
                0x1000A7A0.toInt()

            "GOLD" ->
                0x10D6A83A.toInt()

            "SOFT" ->
                0x0CF0D8D0.toInt()

            "SUNSET" ->
                0x10E06A46.toInt()

            "BLUE HOUR" ->
                0x102F5FA8.toInt()

            "NIGHT" ->
                0x12173363.toInt()

            "MONO" ->
                0x0D707070.toInt()

            "NATURAL" ->
                0x0600A070.toInt()

            else ->
                Color.TRANSPARENT
        }
    }

    private fun reportModeAccentColor(): Int {
        return when (
            qualityModes[
                qualityIndex
            ]
        ) {
            "SOCIAL FHD" ->
                0xFF8FA8E8.toInt()

            "SOCIAL 60" ->
                0xFF73B7D9.toInt()

            "SOCIAL HDR" ->
                0xFFA793D8.toInt()

            "MASTER UHD" ->
                0xFFAEBDEB.toInt()

            "UHD 60" ->
                0xFF7FB8CA.toInt()

            "MASTER HDR" ->
                0xFFD0B06F.toInt()

            "ACTION STAB" ->
                0xFF91B6A0.toInt()

            "ACTION 60" ->
                0xFF71B9A7.toInt()

            "LOW LIGHT" ->
                0xFF8A86B8.toInt()

            "FAST HD" ->
                0xFFAEB7C7.toInt()

            else ->
                0xFFAEBDEB.toInt()
        }
    }

    private fun reportModePurposeLabel(): String {
        return when (
            qualityModes[
                qualityIndex
            ]
        ) {
            "SOCIAL FHD" ->
                "SOCIAL MASTER"

            "SOCIAL 60" ->
                "SMOOTH SOCIAL"

            "SOCIAL HDR" ->
                "SOCIAL HDR"

            "MASTER UHD" ->
                "4K MASTER"

            "UHD 60" ->
                "4K MOTION"

            "MASTER HDR" ->
                "HDR MASTER"

            "ACTION STAB" ->
                "STABLE ACTION"

            "ACTION 60" ->
                "FAST ACTION"

            "LOW LIGHT" ->
                "LOW LIGHT"

            "FAST HD" ->
                "FAST DELIVERY"

            else ->
                "CAMERA MODE"
        }
    }

    private fun updateReportModePreviewTuning() {
        if (
            ::previewModeToneView.isInitialized
        ) {
            previewModeToneView.setBackgroundColor(
                previewLookTintColor()
            )
        }

        if (
            ::previewTagView.isInitialized
        ) {
            previewTagView.setTextColor(
                reportModeAccentColor()
            )

            previewTagView.text =
                "${sceneTag()} • ${reportModePurposeLabel()} • ${lookModes[lookIndex]} • V214"
        }
    }

    private fun thermalStateLabel(): String {
''',
    "REPORT mode preview helpers",
)

# Update every HUD refresh so changing quality/look/scene immediately changes
# the preview identity/tone.
report = must_replace(
    report,
    '''    private fun refreshHud() {
        updateHorizonGuard()
''',
    '''    private fun refreshHud() {
        updateReportModePreviewTuning()
        updateHorizonGuard()
''',
    "REPORT refresh preview tuning",
)

# V214 verified runtime text also names actual purpose/look.
report = report.replace(
    'append("V213 VERIFIED")',
    'append("V214 VERIFIED")',
    1,
)

report = must_replace(
    report,
    '''            append(qualityDeckLabel())
            append(" • ")
            append(activeVideoFpsLabel)
''',
    '''            append(qualityDeckLabel())
            append(" • ")
            append(
                reportModePurposeLabel()
            )
            append(" • LOOK ")
            append(
                lookModes[
                    lookIndex
                ]
            )
            append(" • ")
            append(activeVideoFpsLabel)
''',
    "REPORT verified mode signature",
)

# V214 operator brand/tag.
report = report.replace(
    '"develop.uganda • V213"',
    '"develop.uganda • V214"',
    1,
)

# The refresh function now owns the tag, so remove the old fixed V213 tag.
report = report.replace(
    '''            previewTagView.text =
                "${sceneTag()} • V213 VERIFIED"
''',
    '''            previewTagView.text =
                "${sceneTag()} • ${reportModePurposeLabel()} • ${lookModes[lookIndex]} • V214"
''',
    1,
)

# Recorded REPORT video: V214 plus explicit real selected mode/scene/look.
report = must_replace(
    report,
    '''            "${sceneTag()} • V213",
''',
    '''            "${sceneTag()} • V214",
''',
    "REPORT recorded V214 tag",
)

report = must_replace(
    report,
    '''            "$recState   |   TC ${tc()}   |   V213   |   THERM ${thermalStateLabel()}",
            safeLeft,
            y,
            maxWidth,
            text,
            15.2f * u
        )

        y += 20f * u
        text.color = Color.WHITE
''',
    '''            "$recState   |   TC ${tc()}   |   V214   |   THERM ${thermalStateLabel()}",
            safeLeft,
            y,
            maxWidth,
            text,
            15.2f * u
        )

        y += 19f * u
        text.color =
            reportModeAccentColor()
        text.textSize =
            15.2f * u

        drawFitText(
            c,
            "MODE • ${qualityModes[qualityIndex]}   |   ${reportModePurposeLabel()}   |   SCENE • ${sceneModes[sceneIndex]}   |   LOOK • ${lookModes[lookIndex]}",
            safeLeft,
            y,
            maxWidth,
            text,
            11.7f * u
        )

        y += 20f * u
        text.color = Color.WHITE
''',
    "REPORT recorded mode signature row",
)

# V214 filename and integrity.
report = report.replace(
    '"DEVELOP_UGANDA_V213_${reportId}_${sceneModes[sceneIndex]}_${lookModes[lookIndex]}_"',
    '"DEVELOP_UGANDA_V214_${reportId}_${sceneModes[sceneIndex]}_${lookModes[lookIndex]}_"',
    1,
)

# Snapshot exact quality for integrity metadata.
report = must_replace(
    report,
    '''        val sceneSnapshot =
            sceneModes[
                sceneIndex
            ]
        val lookSnapshot =
''',
    '''        val qualitySnapshot =
            qualityModes[
                qualityIndex
            ]

        val modePurposeSnapshot =
            reportModePurposeLabel()

        val sceneSnapshot =
            sceneModes[
                sceneIndex
            ]
        val lookSnapshot =
''',
    "REPORT quality snapshot",
)

report = report.replace(
    '''                            "V213"
''',
    '''                            "V214"
''',
    1,
)
report = report.replace(
    '''                            "V213 THERMAL GUARD PRO"
''',
    '''                            "V214 MODE SIGNATURE PRO"
''',
    1,
)
report = report.replace(
    '''                            "V204,V205,V206,V207,V208,V209,V210,V211,V212,V213"
''',
    '''                            "V204,V205,V206,V207,V208,V209,V210,V211,V212,V213,V214"
''',
    1,
)

report = must_replace(
    report,
    '''                        put(
                            "scene",
                            sceneSnapshot
                        )
                        put(
                            "look",
                            lookSnapshot
                        )
''',
    '''                        put(
                            "quality_mode",
                            qualitySnapshot
                        )
                        put(
                            "mode_purpose",
                            modePurposeSnapshot
                        )
                        put(
                            "scene",
                            sceneSnapshot
                        )
                        put(
                            "look",
                            lookSnapshot
                        )
''',
    "REPORT integrity exact mode",
)

REPORT.write_text(report, encoding="utf-8")

# ============================================================
# LIVE preview tuning tied to the actual selected quality/effect.
# ============================================================

live = LIVE.read_text(encoding="utf-8")

live = must_replace(
    live,
    '''    private lateinit var root: FrameLayout
    private lateinit var previewView: PreviewView

    private lateinit var liveBadge: TextView
''',
    '''    private lateinit var root: FrameLayout
    private lateinit var previewView: PreviewView
    private lateinit var livePreviewToneView: View

    private lateinit var liveBadge: TextView
''',
    "LIVE tone field",
)

live = must_replace(
    live,
    '''        root.addView(
            previewView,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        val topPanel =
''',
    '''        root.addView(
            previewView,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        livePreviewToneView =
            View(this).apply {
                isClickable =
                    false

                isFocusable =
                    false

                setBackgroundColor(
                    Color.TRANSPARENT
                )
            }

        root.addView(
            livePreviewToneView,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        val topPanel =
''',
    "LIVE operator tone layer",
)

# Helpers before thermal state.
live = must_replace(
    live,
    '''    private fun liveThermalStateLabel(): String {
''',
    '''    private fun livePreviewToneColor(): Int {
        return when (
            liveEffectLabels[
                liveEffectIndex
            ]
        ) {
            "WARM" ->
                0x10FF8A3D.toInt()

            "COOL" ->
                0x10007AFF.toInt()

            "TEAL" ->
                0x1000A7A0.toInt()

            "GOLD" ->
                0x10D6A83A.toInt()

            "SOFT" ->
                0x0CF0D8D0.toInt()

            "NIGHT" ->
                0x12173363.toInt()

            "NATURAL" ->
                0x0600A070.toInt()

            else ->
                Color.TRANSPARENT
        }
    }

    private fun liveModeAccentColor(): Int {
        return when (
            liveQualityProfiles[
                liveQualityIndex
            ]
        ) {
            "SOCIAL 30" ->
                0xFF8FA8E8.toInt()

            "SOCIAL 60" ->
                0xFF73B7D9.toInt()

            "SOCIAL HDR" ->
                0xFFA793D8.toInt()

            "UHD 30" ->
                0xFFAEBDEB.toInt()

            "UHD 60" ->
                0xFF7FB8CA.toInt()

            "HDR UHD" ->
                0xFFD0B06F.toInt()

            "ACTION STAB" ->
                0xFF91B6A0.toInt()

            "ACTION 60" ->
                0xFF71B9A7.toInt()

            "LOW LIGHT" ->
                0xFF8A86B8.toInt()

            "HD FAST" ->
                0xFFAEB7C7.toInt()

            else ->
                cyan
        }
    }

    private fun updateLiveModePreviewTuning() {
        if (
            ::livePreviewToneView.isInitialized
        ) {
            livePreviewToneView.setBackgroundColor(
                livePreviewToneColor()
            )
        }

        if (
            ::liveSubTitle.isInitialized
        ) {
            liveSubTitle.setTextColor(
                liveModeAccentColor()
            )

            liveSubTitle.text =
                "LIVE STUDIO • ${profiles[profileIndex]} • ${liveQualityProfiles[liveQualityIndex]} • LOOK ${liveEffectLabels[liveEffectIndex]} • V214"
        }
    }

    private fun liveThermalStateLabel(): String {
''',
    "LIVE preview mode helpers",
)

# Update preview tuning at the same 500ms signal tick.
live = must_replace(
    live,
    '''    private fun updateSignals() {
        netLamp.setTextColor(
''',
    '''    private fun updateSignals() {
        updateLiveModePreviewTuning()

        netLamp.setTextColor(
''',
    "LIVE update mode tuning",
)

live = live.replace(
    'append("V213 VERIFIED")',
    'append("V214 VERIFIED")',
    1,
)

live = must_replace(
    live,
    '''            append(qualityLabel)
            append(" • ")
            append(liveActiveFpsLabel)
''',
    '''            append(
                liveQualityProfiles[
                    liveQualityIndex
                ]
            )
            append(" • LOOK ")
            append(
                liveEffectLabels[
                    liveEffectIndex
                ]
            )
            append(" • ")
            append(liveActiveFpsLabel)
''',
    "LIVE verified exact mode",
)

# Operator/recorded V214.
live = live.replace(
    '"develop.uganda • V213"',
    '"develop.uganda • V214"',
    1,
)

live = must_replace(
    live,
    '''            "develop.uganda • V213",
''',
    '''            "develop.uganda • V214",
''',
    "LIVE recorded V214 brand",
)

# Saved LIVE video explicitly says exact mode/effect.
live = must_replace(
    live,
    '''            "${if (liveOn) "ON AIR" else "READY"}   |   TIMECODE • ${liveTimecode()}   |   FORMAT • $qualityLabel   |   V213   |   THERMAL • ${liveThermalStateLabel()}",
''',
    '''            "${if (liveOn) "ON AIR" else "READY"}   |   TIMECODE • ${liveTimecode()}   |   MODE • ${liveQualityProfiles[liveQualityIndex]}   |   LOOK • ${liveEffectLabels[liveEffectIndex]}   |   V214   |   THERMAL • ${liveThermalStateLabel()}",
''',
    "LIVE recorded exact mode",
)

live = must_replace(
    live,
    '''            "REPORTER • $reporterName   |   STORY • $storyId   |   develop.uganda • V213",
''',
    '''            "REPORTER • $reporterName   |   STORY • $storyId   |   develop.uganda • V214",
''',
    "LIVE footer V214",
)

live = live.replace(
    '"DEVELOP_UGANDA_V213_LIVE_${profiles[profileIndex]}_$stamp"',
    '"DEVELOP_UGANDA_V214_LIVE_${profiles[profileIndex]}_$stamp"',
    1,
)

LIVE.write_text(live, encoding="utf-8")

# ============================================================
# HOME — append V214; keep V204-V213 visible.
# ============================================================

home = HOME.read_text(encoding="utf-8")

home = home.replace(
    '"THERMAL GUARD PRO • V213"',
    '"MODE SIGNATURE PRO • V214"',
    1,
)

home = home.replace(
    '"V204→V213 ALL RETAINED • SOCIAL/HDR/4K/ACTION • AF/METER • HORIZON • STEADYSHOT • NIGHT INTELLIGENCE • AUDIO • VERIFIED STATE • THERMAL GUARD • 9:16 SAFE"',
    '"V204→V214 ALL RETAINED • SOCIAL/HDR/4K/ACTION • AF/METER • HORIZON • STEADYSHOT • NIGHT • AUDIO • VERIFIED • THERMAL • MODE-SPECIFIC PREVIEW • 9:16 SAFE"',
    1,
)

home = home.replace(
    '"FIELD REPORT • V213 VERIFIED RUNTIME STATE • ALL V204→V212 MODULES RETAINED • REAL THERMAL STATUS • AUTO SAFE PROFILE AT SEVERE+ • VERSIONED VIDEO • telemetry"',
    '"FIELD REPORT • V214 MODE-SPECIFIC OPERATOR PREVIEW • ALL V204→V213 RETAINED • REAL MODE/LOOK STATE • RECORDED MODE SIGNATURE • VERSIONED VIDEO • telemetry"',
    1,
)

home = home.replace(
    '"✓ ALL PRO • V213"',
    '"✓ ALL PRO • V214"',
    1,
)

home = home.replace(
    '"Every camera module below remains active together. V213 adds real Android thermal monitoring and high-heat safe-profile fallback without replacing V204–V212."',
    '"Every camera module below remains active together. V214 gives each selected camera mode/look a distinct operator preview identity and records the exact mode, without replacing V204–V213."',
    1,
)

home = must_replace(
    home,
    '''                Triple(
                    "✓ V213 • THERMAL GUARD PRO",
                    "Reads Android PowerManager thermal status; shows it in REPORT/LIVE, burns it into video, and falls back from high-demand profiles at SEVERE+.",
                    red
                )
''',
    '''                Triple(
                    "✓ V213 • THERMAL GUARD PRO",
                    "Reads Android PowerManager thermal status; shows it in REPORT/LIVE, burns it into video, and falls back from high-demand profiles at SEVERE+.",
                    red
                ),
                Triple(
                    "✓ V214 • MODE SIGNATURE PRO",
                    "Selected look gives the operator preview a subtle matching tone; quality mode gets its own accent/purpose label; REPORT/LIVE recordings burn in the exact mode and V214.",
                    cyan
                )
''',
    "HOME append V214",
)

home = home.replace(
    '"NOTHING DROPPED • V204→V213 RETAINED • ACTIVE MEANS REAL RUNTIME BEHAVIOUR, NOT DECORATIVE TEXT"',
    '"NOTHING DROPPED • V204→V214 RETAINED • MODE PREVIEW CUES ARE TIED TO THE REAL SELECTED MODE/LOOK • RECORDED OUTPUT STATES THE EXACT MODE"',
    1,
)

HOME.write_text(home, encoding="utf-8")

# ============================================================
# VERSION
# ============================================================

gradle = GRADLE.read_text(encoding="utf-8")
gradle = re.sub(
    r"versionCode\s*=\s*\d+",
    "versionCode = 21400",
    gradle,
    count=1,
)
gradle = re.sub(
    r'versionName\s*=\s*"[^"]+"',
    'versionName = "214.0-mode-signature-pro"',
    gradle,
    count=1,
)
GRADLE.write_text(gradle, encoding="utf-8")

print("V214 Mode Signature Pro patch applied.")
