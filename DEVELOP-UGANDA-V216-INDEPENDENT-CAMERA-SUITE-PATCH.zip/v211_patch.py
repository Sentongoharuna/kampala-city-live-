from pathlib import Path
import re

ROOT = Path("v172-source/app")
REPORT = ROOT / "src/main/java/com/sentongoharuna/pulse/DevelopUgandaCameraActivity.kt"
LIVE = ROOT / "src/main/java/com/sentongoharuna/pulse/DevelopUgandaLiveActivity.kt"
HOME = ROOT / "src/main/java/com/sentongoharuna/pulse/DevelopUgandaNewsroomActivity.kt"
GRADLE = ROOT / "build.gradle.kts"

def must_replace(text, old, new, label):
    if old not in text:
        raise SystemExit(f"V211 patch anchor missing: {label}")
    return text.replace(old, new, 1)

# ============================================================
# V211 AUDIO GUARD PRO
# Operator-side microphone level guidance for REPORT + LIVE.
# Does not apply fake denoise/compression to the recorded track.
# ============================================================

report = REPORT.read_text(encoding="utf-8")

report = must_replace(
    report,
    '''    private lateinit var motionGuardView: TextView
    private lateinit var lightAdvisorView: TextView

    private lateinit var brandView: TextView
''',
    '''    private lateinit var motionGuardView: TextView
    private lateinit var lightAdvisorView: TextView
    private lateinit var audioGuardView: TextView

    private lateinit var brandView: TextView
''',
    "REPORT audio guard field",
)

report = must_replace(
    report,
    '''    @Volatile private var audioAmplitude = 0.0
    @Volatile private var audioStateLabel = "MIC READY"
''',
    '''    @Volatile private var audioAmplitude = 0.0
    @Volatile private var audioPeakAmplitude = 0.0
    @Volatile private var audioStateLabel = "MIC READY"
''',
    "REPORT audio peak field",
)

# Place the Audio Guard below Night Intelligence.
report = must_replace(
    report,
    '''        root.addView(
            lightAdvisorView,
            lightParams
        )

        // V187 PREVIEW HUD:
''',
    '''        root.addView(
            lightAdvisorView,
            lightParams
        )

        audioGuardView =
            TextView(this).apply {
                text =
                    "AUDIO • MIC READY"

                textSize =
                    7.8f

                gravity =
                    Gravity.CENTER

                typeface =
                    Typeface.MONOSPACE

                setTextColor(
                    0xFFAEB7C7.toInt()
                )

                setPadding(
                    dp(9),
                    dp(4),
                    dp(9),
                    dp(4)
                )

                background =
                    GradientDrawable().apply {
                        shape =
                            GradientDrawable.RECTANGLE

                        cornerRadius =
                            dp(14).toFloat()

                        setColor(
                            0x42031829
                        )

                        setStroke(
                            dp(1),
                            0x607A91A4
                        )
                    }
            }

        val audioGuardParams =
            FrameLayout.LayoutParams(
                dp(220),
                dp(30),
                Gravity.CENTER
            ).apply {
                topMargin =
                    dp(130)
            }

        root.addView(
            audioGuardView,
            audioGuardParams
        )

        // V187 PREVIEW HUD:
''',
    "REPORT audio guard UI",
)

# Add classification + UI helpers before Night Intelligence helper.
report = must_replace(
    report,
    '''    private fun ambientLightLabel(): String {
''',
    '''    private fun audioGuardLabel(): String {
        if (
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.RECORD_AUDIO
            ) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            return "MIC OFF"
        }

        if (
            audioStateLabel ==
                "MIC ERROR"
        ) {
            return "MIC ERROR"
        }

        if (
            recording ==
                null
        ) {
            return "MIC READY"
        }

        val level =
            audioAmplitude.coerceIn(
                0.0,
                1.0
            )

        return when {
            level <
                0.015 ->
                    "LOW"

            level <
                0.70 ->
                    "GOOD"

            level <
                0.90 ->
                    "HOT"

            else ->
                "CLIP RISK"
        }
    }

    private fun updateAudioGuard() {
        if (
            !::audioGuardView.isInitialized
        ) {
            return
        }

        if (
            operatorControlsHidden ||
            cleanModeEnabled
        ) {
            audioGuardView.visibility =
                View.GONE

            return
        }

        audioGuardView.visibility =
            View.VISIBLE

        val label =
            audioGuardLabel()

        val percent =
            (
                audioAmplitude
                    .coerceIn(
                        0.0,
                        1.0
                    ) *
                    100.0
                ).roundToInt()

        val peakPercent =
            (
                audioPeakAmplitude
                    .coerceIn(
                        0.0,
                        1.0
                    ) *
                    100.0
                ).roundToInt()

        audioGuardView.text =
            when (label) {
                "MIC READY",
                "MIC OFF",
                "MIC ERROR" ->
                    "AUDIO • $label"

                else ->
                    "AUDIO • $label • ${percent}% • PEAK ${peakPercent}%"
            }

        audioGuardView.setTextColor(
            when (label) {
                "GOOD" ->
                    0xFF91B6A0.toInt()

                "HOT" ->
                    0xFFAEBDEB.toInt()

                "CLIP RISK",
                "MIC ERROR" ->
                    0xFFC76D73.toInt()

                "LOW" ->
                    0xFFAEBDEB.toInt()

                else ->
                    0xFFAEB7C7.toInt()
            }
        )
    }

    private fun ambientLightLabel(): String {
''',
    "REPORT audio guard helpers",
)

report = must_replace(
    report,
    '''        updateHorizonGuard()
        updateMotionGuard()
        updateLightAdvisor()

        timecodeView.text =
''',
    '''        updateHorizonGuard()
        updateMotionGuard()
        updateLightAdvisor()
        updateAudioGuard()

        timecodeView.text =
''',
    "REPORT refresh audio guard",
)

# Track audio peak during recording.
report = must_replace(
    report,
    '''                    audioAmplitude = 0.0
                    audioStateLabel = "MIC REC"
''',
    '''                    audioAmplitude = 0.0
                    audioPeakAmplitude = 0.0
                    audioStateLabel = "MIC REC"
''',
    "REPORT reset audio peak on start",
)

report = must_replace(
    report,
    '''                    audioAmplitude =
                        audioStats.audioAmplitude
                    audioStateLabel =
''',
    '''                    audioAmplitude =
                        audioStats.audioAmplitude

                    audioPeakAmplitude =
                        maxOf(
                            audioPeakAmplitude *
                                0.985,
                            audioAmplitude
                        )

                    audioStateLabel =
''',
    "REPORT update audio peak",
)

report = must_replace(
    report,
    '''                    audioAmplitude = 0.0
                    audioStateLabel =
                        if (
''',
    '''                    audioAmplitude = 0.0
                    audioPeakAmplitude = 0.0
                    audioStateLabel =
                        if (
''',
    "REPORT clear audio peak after finalize",
)

report = must_replace(
    report,
    '''            append(
                ambientLightRecommendation()
            )
        }
    }
''',
    '''            append(
                ambientLightRecommendation()
            )
            append(" • AUDIO ")
            append(
                audioGuardLabel()
            )
        }
    }
''',
    "REPORT creator status audio guard",
)

REPORT.write_text(report, encoding="utf-8")

# ============================================================
# LIVE AUDIO GUARD
# ============================================================

live = LIVE.read_text(encoding="utf-8")

live = must_replace(
    live,
    '''    private var liveAudioAmplitude = 0.0
    private var liveBlinkOn = true
''',
    '''    private var liveAudioAmplitude = 0.0
    private var liveAudioPeakAmplitude = 0.0
    private var liveBlinkOn = true
''',
    "LIVE audio peak field",
)

# Helper before updateSignals.
live = must_replace(
    live,
    '''    private fun updateSignals() {
''',
    '''    private fun liveAudioGuardLabel(): String {
        if (!audioEnabled) {
            return "OFF"
        }

        if (
            recording ==
                null
        ) {
            return "READY"
        }

        val level =
            liveAudioAmplitude.coerceIn(
                0.0,
                1.0
            )

        return when {
            level <
                0.015 ->
                    "LOW"

            level <
                0.70 ->
                    "GOOD"

            level <
                0.90 ->
                    "HOT"

            else ->
                "CLIP RISK"
        }
    }

    private fun updateSignals() {
''',
    "LIVE audio guard helper",
)

# Track peak from CameraX recording stats.
live = must_replace(
    live,
    '''                        liveAudioAmplitude =
                            event.recordingStats
                                .audioStats
                                .audioAmplitude
                                .coerceIn(
                                    0.0,
                                    1.0
                                )
''',
    '''                        liveAudioAmplitude =
                            event.recordingStats
                                .audioStats
                                .audioAmplitude
                                .coerceIn(
                                    0.0,
                                    1.0
                                )

                        liveAudioPeakAmplitude =
                            maxOf(
                                liveAudioPeakAmplitude *
                                    0.985,
                                liveAudioAmplitude
                            )
''',
    "LIVE update audio peak",
)

# Reset peak on finalize.
live = must_replace(
    live,
    '''                        liveAudioAmplitude =
                            0.0

                        if (
''',
    '''                        liveAudioAmplitude =
                            0.0

                        liveAudioPeakAmplitude =
                            0.0

                        if (
''',
    "LIVE clear audio peak",
)

# Add Audio Guard classification to the existing LIVE technical row.
live = must_replace(
    live,
    ''' • MIC ${audioPercent}% • NET ${
''',
    ''' • AUDIO ${liveAudioGuardLabel()} ${audioPercent}% • NET ${
''',
    "LIVE preview Audio Guard",
)

LIVE.write_text(live, encoding="utf-8")

# ============================================================
# HOME MODULE HUB — APPEND V211, DROP NOTHING
# ============================================================

home = HOME.read_text(encoding="utf-8")

home = home.replace(
    '"CAMERA MODULE HUB • V210"',
    '"AUDIO GUARD PRO • V211"',
    1,
)

home = home.replace(
    '"V204→V209 ALL RETAINED • SOCIAL/HDR/4K/ACTION • AF/METER • HORIZON • STEADYSHOT • NIGHT INTELLIGENCE • 9:16 SAFE"',
    '"V204→V211 ALL RETAINED • SOCIAL/HDR/4K/ACTION • AF/METER • HORIZON • STEADYSHOT • NIGHT INTELLIGENCE • AUDIO GUARD • 9:16 SAFE"',
    1,
)

home = home.replace(
    '"FIELD REPORT • ALL PRO CAMERA MODULES ACTIVE • SOCIAL/HDR/4K/ACTION • AF/METER • HORIZON • STEADYSHOT • NIGHT INTELLIGENCE • telemetry"',
    '"FIELD REPORT • ALL PRO CAMERA MODULES ACTIVE • SOCIAL/HDR/4K/ACTION • AF/METER • HORIZON • STEADYSHOT • NIGHT INTELLIGENCE • AUDIO GUARD • telemetry"',
    1,
)

home = home.replace(
    '''                Triple(
                    "✓ V209 • NIGHT INTELLIGENCE PRO",
                    "Ambient-light lux advisor: BRIGHT • NORMAL • DIM • DARK with Low Light / 30 fps guidance.",
                    red
                )
''',
    '''                Triple(
                    "✓ V209 • NIGHT INTELLIGENCE PRO",
                    "Ambient-light lux advisor: BRIGHT • NORMAL • DIM • DARK with Low Light / 30 fps guidance.",
                    red
                ),
                Triple(
                    "✓ V211 • AUDIO GUARD PRO",
                    "REPORT + LIVE microphone guidance: LOW • GOOD • HOT • CLIP RISK with current and peak levels.",
                    green
                )
''',
    "HOME append V211 module",
)

home = home.replace(
    '"Every camera module below remains active together. New camera versions should be appended here, not replace older tools."',
    '"Every camera module below remains active together. V211 adds Audio Guard without replacing V204–V210. Future camera versions append here too."',
    1,
)

home = home.replace(
    '"NOTHING DROPPED • V204→V209 RETAINED • FUTURE CAMERA FEATURES APPEND TO THIS MODULE HUB"',
    '"NOTHING DROPPED • V204→V211 RETAINED • FUTURE CAMERA FEATURES APPEND TO THIS MODULE HUB"',
    1,
)

HOME.write_text(home, encoding="utf-8")

# ============================================================
# VERSION
# ============================================================

gradle = GRADLE.read_text(encoding="utf-8")
gradle = re.sub(
    r"versionCode\s*=\s*\d+",
    "versionCode = 21100",
    gradle,
    count=1,
)
gradle = re.sub(
    r'versionName\s*=\s*"[^"]+"',
    'versionName = "211.0-audio-guard-pro"',
    gradle,
    count=1,
)
GRADLE.write_text(gradle, encoding="utf-8")

print("V211 Audio Guard Pro patch applied.")
