from pathlib import Path
import re

ROOT = Path("v172-source/app")
REPORT = ROOT / "src/main/java/com/sentongoharuna/pulse/DevelopUgandaCameraActivity.kt"
LIVE = ROOT / "src/main/java/com/sentongoharuna/pulse/DevelopUgandaLiveActivity.kt"
HOME = ROOT / "src/main/java/com/sentongoharuna/pulse/DevelopUgandaNewsroomActivity.kt"
GRADLE = ROOT / "build.gradle.kts"

def must_replace(text, old, new, label):
    if old not in text:
        raise SystemExit(f"V206 patch anchor missing: {label}")
    return text.replace(old, new, 1)

# ============================================================
# V206 — PRO METERING LOCK
# REPORT: persistent AF + AE + AWB metering region on long press,
# plus an operator-visible focus/metering reticle.
# ============================================================

report = REPORT.read_text(encoding="utf-8")

# Add focus reticle UI field.
report = must_replace(
    report,
    '''    private lateinit var previewHealthView: TextView

    private lateinit var brandView: TextView
''',
    '''    private lateinit var previewHealthView: TextView
    private lateinit var focusReticleView: TextView

    private lateinit var brandView: TextView
''',
    "REPORT reticle field",
)

# Add reticle auto-hide runnable near focus lock state.
report = must_replace(
    report,
    '''    private var focusLongPressTriggered = false
    private var focusLockActive = false

    private val focusLockRunnable =
''',
    '''    private var focusLongPressTriggered = false
    private var focusLockActive = false

    private val hideFocusReticleRunnable =
        Runnable {
            if (
                ::focusReticleView.isInitialized &&
                !focusLockActive
            ) {
                focusReticleView.visibility =
                    View.GONE
            }
        }

    private val focusLockRunnable =
''',
    "REPORT reticle hide state",
)

# Insert the reticle directly over the camera preview.
report = must_replace(
    report,
    '''        root.addView(
            previewView,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        // V187 PREVIEW HUD:
''',
    '''        root.addView(
            previewView,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        focusReticleView =
            TextView(this).apply {
                text =
                    "AF"

                textSize =
                    8.5f

                setTextColor(
                    Color.WHITE
                )

                gravity =
                    Gravity.CENTER

                typeface =
                    Typeface.DEFAULT_BOLD

                visibility =
                    View.GONE

                background =
                    GradientDrawable().apply {
                        shape =
                            GradientDrawable.RECTANGLE

                        cornerRadius =
                            dp(12).toFloat()

                        setColor(
                            0x26031829
                        )

                        setStroke(
                            dp(2),
                            0xFFDCE4F7.toInt()
                        )
                    }
            }

        root.addView(
            focusReticleView,
            FrameLayout.LayoutParams(
                dp(76),
                dp(76)
            )
        )

        // V187 PREVIEW HUD:
''',
    "REPORT reticle UI",
)

# Add reticle helper before persistent focus lock function.
report = must_replace(
    report,
    '''    private fun togglePersistentFocusLock(
        x: Float,
        y: Float
    ) {
''',
    '''    private fun showFocusReticle(
        x: Float,
        y: Float,
        locked: Boolean
    ) {
        if (
            !::focusReticleView.isInitialized
        ) {
            return
        }

        val size =
            dp(76).toFloat()

        val maxX =
            (
                previewView.width.toFloat() -
                    size
                ).coerceAtLeast(
                    0f
                )

        val maxY =
            (
                previewView.height.toFloat() -
                    size
                ).coerceAtLeast(
                    0f
                )

        focusReticleView.x =
            (
                x -
                    size /
                    2f
                ).coerceIn(
                    0f,
                    maxX
                )

        focusReticleView.y =
            (
                y -
                    size /
                    2f
                ).coerceIn(
                    0f,
                    maxY
                )

        focusReticleView.text =
            if (locked) {
                "AF + METER\\nLOCK"
            } else {
                "AF"
            }

        focusReticleView.setTextColor(
            if (locked) {
                0xFFAEBDEB.toInt()
            } else {
                Color.WHITE
            }
        )

        focusReticleView.background =
            GradientDrawable().apply {
                shape =
                    GradientDrawable.RECTANGLE

                cornerRadius =
                    dp(12).toFloat()

                setColor(
                    if (locked) {
                        0x3A031829
                    } else {
                        0x26031829
                    }
                )

                setStroke(
                    dp(
                        if (locked) {
                            3
                        } else {
                            2
                        }
                    ),
                    if (locked) {
                        0xFFAEBDEB.toInt()
                    } else {
                        0xFFDCE4F7.toInt()
                    }
                )
            }

        focusReticleView.visibility =
            View.VISIBLE

        uiHandler.removeCallbacks(
            hideFocusReticleRunnable
        )

        if (!locked) {
            uiHandler.postDelayed(
                hideFocusReticleRunnable,
                950L
            )
        }
    }

    private fun togglePersistentFocusLock(
        x: Float,
        y: Float
    ) {
''',
    "REPORT reticle helper",
)

# Upgrade persistent lock from AF-only to AF + AE + AWB metering.
report = must_replace(
    report,
    '''            val action =
                FocusMeteringAction
                    .Builder(
                        point
                    )
                    .disableAutoCancel()
                    .build()
''',
    '''            val action =
                FocusMeteringAction
                    .Builder(
                        point,
                        FocusMeteringAction.FLAG_AF or
                            FocusMeteringAction.FLAG_AE or
                            FocusMeteringAction.FLAG_AWB
                    )
                    .disableAutoCancel()
                    .build()
''',
    "REPORT combined AF/AE/AWB metering",
)

# Update lock toast, reticle and release behavior.
report = must_replace(
    report,
    '''            focusLockActive =
                true

            toast(
                "AF LOCK • long press again to release"
            )

            refreshHud()
''',
    '''            focusLockActive =
                true

            showFocusReticle(
                x,
                y,
                true
            )

            toast(
                "AF + METER LOCK • hold again to release"
            )

            refreshHud()
''',
    "REPORT lock reticle state",
)

report = must_replace(
    report,
    '''            focusLockActive =
                false

            toast(
                "FOCUS AUTO"
            )

            refreshHud()
            return
''',
    '''            focusLockActive =
                false

            if (
                ::focusReticleView.isInitialized
            ) {
                focusReticleView.text =
                    "AF AUTO"

                focusReticleView.visibility =
                    View.VISIBLE

                uiHandler.removeCallbacks(
                    hideFocusReticleRunnable
                )

                uiHandler.postDelayed(
                    hideFocusReticleRunnable,
                    700L
                )
            }

            toast(
                "AF / METER AUTO"
            )

            refreshHud()
            return
''',
    "REPORT release lock UI",
)

# Update status wording.
report = must_replace(
    report,
    '''        return if (focusLockActive) {
            "AF LOCK"
        } else {
            "AF AUTO"
        }
''',
    '''        return if (focusLockActive) {
            "AF+METER LOCK"
        } else {
            "AF AUTO"
        }
''',
    "REPORT focus assist label",
)

# Show reticle immediately on ACTION_DOWN.
report = must_replace(
    report,
    '''                    focusLongPressTriggered =
                        false

                    uiHandler.removeCallbacks(
                        focusLockRunnable
                    )
''',
    '''                    focusLongPressTriggered =
                        false

                    showFocusReticle(
                        event.x,
                        event.y,
                        false
                    )

                    uiHandler.removeCallbacks(
                        focusLockRunnable
                    )
''',
    "REPORT reticle on touch",
)

# When moving into zoom/exposure gesture, hide focus reticle unless lock is active.
report = must_replace(
    report,
    '''                            uiHandler.removeCallbacks(
                                focusLockRunnable
                            )
                        }
''',
    '''                            uiHandler.removeCallbacks(
                                focusLockRunnable
                            )

                            if (
                                ::focusReticleView.isInitialized &&
                                !focusLockActive
                            ) {
                                focusReticleView.visibility =
                                    View.GONE
                            }
                        }
''',
    "REPORT hide reticle on gesture",
)

# Explicit operator guidance.
report = must_replace(
    report,
    '''            append(" • TAP AF")
            append(" • HOLD AF LOCK")
''',
    '''            append(" • TAP AF")
            append(" • HOLD AF+AE+AWB METER")
''',
    "REPORT creator status guidance",
)

REPORT.write_text(report, encoding="utf-8")

# ============================================================
# LIVE — preserve continuous metering behavior.
# ============================================================

live = LIVE.read_text(encoding="utf-8")

live = live.replace(
    '"LIVE STUDIO • ${profiles[profileIndex]} • CONTINUOUS AF • READY"',
    '"LIVE STUDIO • ${profiles[profileIndex]} • CONTINUOUS AF/AE/AWB • READY"',
)

LIVE.write_text(live, encoding="utf-8")

# ============================================================
# HOME / VERSION
# ============================================================

home = HOME.read_text(encoding="utf-8")

home = home.replace(
    '"PRO FOCUS ASSIST • V205"',
    '"PRO METERING LOCK • V206"',
    1,
)

home = home.replace(
    '"SOCIAL FHD/60 • SOCIAL HDR • 4K 30/60 • ACTION 30/60 • HLG10 HDR • LONG-PRESS AF LOCK • 9:16 SOCIAL SAFE"',
    '"SOCIAL FHD/60 • SOCIAL HDR • 4K 30/60 • ACTION 30/60 • HLG10 HDR • LONG-PRESS AF+AE+AWB METER LOCK • 9:16 SOCIAL SAFE"',
    1,
)

home = home.replace(
    '"FIELD REPORT • TAP TO FOCUS • LONG PRESS AF LOCK • SOCIAL 30/60 • HDR • 4K • ACTION • LOW LIGHT • telemetry"',
    '"FIELD REPORT • TAP AF • LONG PRESS AF+AE+AWB METER LOCK • VISIBLE RETICLE • SOCIAL/HDR/4K/ACTION/LOW LIGHT • telemetry"',
    1,
)

HOME.write_text(home, encoding="utf-8")

gradle = GRADLE.read_text(encoding="utf-8")
gradle = re.sub(
    r"versionCode\s*=\s*\d+",
    "versionCode = 20600",
    gradle,
    count=1,
)
gradle = re.sub(
    r'versionName\s*=\s*"[^"]+"',
    'versionName = "206.0-pro-metering-lock"',
    gradle,
    count=1,
)
GRADLE.write_text(gradle, encoding="utf-8")

print("V206 Pro Metering Lock patch applied.")
