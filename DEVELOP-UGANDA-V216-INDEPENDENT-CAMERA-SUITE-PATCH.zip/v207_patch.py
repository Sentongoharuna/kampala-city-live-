from pathlib import Path
import re

ROOT = Path("v172-source/app")
REPORT = ROOT / "src/main/java/com/sentongoharuna/pulse/DevelopUgandaCameraActivity.kt"
HOME = ROOT / "src/main/java/com/sentongoharuna/pulse/DevelopUgandaNewsroomActivity.kt"
GRADLE = ROOT / "build.gradle.kts"

def must_replace(text, old, new, label):
    if old not in text:
        raise SystemExit(f"V207 patch anchor missing: {label}")
    return text.replace(old, new, 1)

# ============================================================
# V207 — HORIZON GUARD PRO
# Operator-side live horizon guidance using the phone roll sensor.
# The guide is NOT burned into the saved video. Saved telemetry and
# level instruments remain unchanged and authoritative.
# ============================================================

report = REPORT.read_text(encoding="utf-8")

# Add operator horizon view.
report = must_replace(
    report,
    '''    private lateinit var focusReticleView: TextView

    private lateinit var brandView: TextView
''',
    '''    private lateinit var focusReticleView: TextView
    private lateinit var horizonGuardView: TextView

    private lateinit var brandView: TextView
''',
    "REPORT horizon view field",
)

# Add the horizon guide after the focus reticle is attached.
report = must_replace(
    report,
    '''        root.addView(
            focusReticleView,
            FrameLayout.LayoutParams(
                dp(76),
                dp(76)
            )
        )

        // V187 PREVIEW HUD:
''',
    '''        root.addView(
            focusReticleView,
            FrameLayout.LayoutParams(
                dp(76),
                dp(76)
            )
        )

        horizonGuardView =
            TextView(this).apply {
                text =
                    "━━━━━━━━  LEVEL --  ━━━━━━━━"

                textSize =
                    8.6f

                gravity =
                    Gravity.CENTER

                typeface =
                    Typeface.MONOSPACE

                setTextColor(
                    0xFFAEB7C7.toInt()
                )

                setShadowLayer(
                    1.1f,
                    0.3f,
                    0.3f,
                    0x66000000
                )

                visibility =
                    View.VISIBLE
            }

        root.addView(
            horizonGuardView,
            FrameLayout.LayoutParams(
                dp(270),
                dp(34),
                Gravity.CENTER
            )
        )

        // V187 PREVIEW HUD:
''',
    "REPORT horizon guide UI",
)

# Add horizon logic before startEverything.
report = must_replace(
    report,
    '''    private fun startEverything() {
''',
    '''    private fun updateHorizonGuard() {
        if (
            !::horizonGuardView.isInitialized
        ) {
            return
        }

        if (
            operatorControlsHidden ||
            cleanModeEnabled
        ) {
            horizonGuardView.visibility =
                View.GONE

            return
        }

        horizonGuardView.visibility =
            View.VISIBLE

        val roll =
            phoneRollDeg

        if (roll == null) {
            horizonGuardView.rotation =
                0f

            horizonGuardView.text =
                "━━━━━━━━  HORIZON --  ━━━━━━━━"

            horizonGuardView.setTextColor(
                0xFFAEB7C7.toInt()
            )

            return
        }

        val absRoll =
            kotlin.math.abs(
                roll
            )

        val stateText =
            when {
                absRoll <=
                    1.0f ->
                        "LEVEL LOCK"

                absRoll <=
                    3.0f ->
                        "LEVEL NEAR"

                else ->
                    "ADJUST"
            }

        horizonGuardView.rotation =
            (
                -roll
            ).coerceIn(
                -12f,
                12f
            )

        horizonGuardView.text =
            String.format(
                Locale.US,
                "━━━━━━━━  %s  %+.1f°  ━━━━━━━━",
                stateText,
                roll
            )

        horizonGuardView.setTextColor(
            when {
                absRoll <=
                    1.0f ->
                        0xFF91B6A0.toInt()

                absRoll <=
                    3.0f ->
                        0xFFAEBDEB.toInt()

                else ->
                    0xFFC76D73.toInt()
            }
        )
    }

    private fun startEverything() {
''',
    "REPORT horizon update method",
)

# Refresh the horizon every time the rest of the HUD refreshes.
report = must_replace(
    report,
    '''    private fun refreshHud() {
        timecodeView.text =
            "TC ${tc()}"
''',
    '''    private fun refreshHud() {
        updateHorizonGuard()

        timecodeView.text =
            "TC ${tc()}"
''',
    "REPORT horizon refresh",
)

# Report it in camera status.
report = must_replace(
    report,
    '''            append(" • HOLD AF+AE+AWB METER")
        }
    }
''',
    '''            append(" • HOLD AF+AE+AWB METER")
            append(" • HORIZON GUARD")
        }
    }
''',
    "REPORT status horizon guard",
)

REPORT.write_text(report, encoding="utf-8")

# ============================================================
# HOME / VERSION
# ============================================================

home = HOME.read_text(encoding="utf-8")

home = home.replace(
    '"PRO METERING LOCK • V206"',
    '"HORIZON GUARD PRO • V207"',
    1,
)

home = home.replace(
    '"SOCIAL FHD/60 • SOCIAL HDR • 4K 30/60 • ACTION 30/60 • HLG10 HDR • LONG-PRESS AF+AE+AWB METER LOCK • 9:16 SOCIAL SAFE"',
    '"SOCIAL FHD/60 • SOCIAL HDR • 4K 30/60 • ACTION 30/60 • HLG10 HDR • AF+AE+AWB METER LOCK • LIVE HORIZON GUARD • 9:16 SOCIAL SAFE"',
    1,
)

home = home.replace(
    '"FIELD REPORT • TAP AF • LONG PRESS AF+AE+AWB METER LOCK • VISIBLE RETICLE • SOCIAL/HDR/4K/ACTION/LOW LIGHT • telemetry"',
    '"FIELD REPORT • TAP AF • AF+AE+AWB METER LOCK • LIVE HORIZON GUIDE • SOCIAL/HDR/4K/ACTION/LOW LIGHT • telemetry"',
    1,
)

HOME.write_text(home, encoding="utf-8")

gradle = GRADLE.read_text(encoding="utf-8")
gradle = re.sub(
    r"versionCode\s*=\s*\d+",
    "versionCode = 20700",
    gradle,
    count=1,
)
gradle = re.sub(
    r'versionName\s*=\s*"[^"]+"',
    'versionName = "207.0-horizon-guard-pro"',
    gradle,
    count=1,
)
GRADLE.write_text(gradle, encoding="utf-8")

print("V207 Horizon Guard Pro patch applied.")
