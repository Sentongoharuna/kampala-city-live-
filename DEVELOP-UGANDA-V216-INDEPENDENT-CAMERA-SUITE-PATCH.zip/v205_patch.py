from pathlib import Path
import re

ROOT = Path("v172-source/app")
REPORT = ROOT / "src/main/java/com/sentongoharuna/pulse/DevelopUgandaCameraActivity.kt"
LIVE = ROOT / "src/main/java/com/sentongoharuna/pulse/DevelopUgandaLiveActivity.kt"
HOME = ROOT / "src/main/java/com/sentongoharuna/pulse/DevelopUgandaNewsroomActivity.kt"
GRADLE = ROOT / "build.gradle.kts"

def must_replace(text, old, new, label):
    if old not in text:
        raise SystemExit(f"V205 patch anchor missing: {label}")
    return text.replace(old, new, 1)

# ============================================================
# V205 — PRO FOCUS ASSIST
# Persistent AF lock for REPORT video + focus state in operator HUD.
# Long press preview = lock focus. Tap = release lock + refocus.
# ============================================================

report = REPORT.read_text(encoding="utf-8")

# Add state around existing gesture fields.
report = must_replace(
    report,
    '''    private var gestureMoved = false
    private var lastPreviewTapMs = 0L

    private val autoHideRunnable =
''',
    '''    private var gestureMoved = false
    private var lastPreviewTapMs = 0L
    private var focusLongPressTriggered = false
    private var focusLockActive = false

    private val focusLockRunnable =
        Runnable {
            if (
                !gestureMoved &&
                !operatorLocked &&
                ::previewView.isInitialized
            ) {
                focusLongPressTriggered =
                    true

                togglePersistentFocusLock(
                    gestureDownX,
                    gestureDownY
                )
            }
        }

    private val autoHideRunnable =
''',
    "REPORT focus state",
)

# Add focus helper before startEverything, a stable anchor in the app.
report = must_replace(
    report,
    '''    private fun startEverything() {
''',
    '''    private fun togglePersistentFocusLock(
        x: Float,
        y: Float
    ) {
        val cam =
            camera
                ?: run {
                    toast(
                        "Camera is not ready"
                    )
                    return
                }

        if (focusLockActive) {
            try {
                cam.cameraControl
                    .cancelFocusAndMetering()
            } catch (_: Exception) {
            }

            focusLockActive =
                false

            toast(
                "FOCUS AUTO"
            )

            refreshHud()
            return
        }

        try {
            val point =
                previewView
                    .meteringPointFactory
                    .createPoint(
                        x,
                        y
                    )

            val action =
                FocusMeteringAction
                    .Builder(
                        point
                    )
                    .disableAutoCancel()
                    .build()

            cam.cameraControl
                .startFocusAndMetering(
                    action
                )

            focusLockActive =
                true

            toast(
                "AF LOCK • long press again to release"
            )

            refreshHud()
        } catch (_: Exception) {
            focusLockActive =
                false

            toast(
                "Focus lock unavailable on this lens"
            )
        }
    }

    private fun releaseFocusLockForTap() {
        if (!focusLockActive) {
            return
        }

        try {
            camera
                ?.cameraControl
                ?.cancelFocusAndMetering()
        } catch (_: Exception) {
        }

        focusLockActive =
            false
    }

    private fun focusAssistLabel(): String {
        return if (focusLockActive) {
            "AF LOCK"
        } else {
            "AF AUTO"
        }
    }

    private fun startEverything() {
''',
    "REPORT focus helpers",
)

# On camera rebind, do not keep stale lock state.
report = must_replace(
    report,
    '''            torchOn = false
            torchButton.text = "LIGHT\\nOFF"

            syncCameraRanges()
''',
    '''            torchOn = false
            torchButton.text = "LIGHT\\nOFF"

            focusLockActive =
                false

            syncCameraRanges()
''',
    "REPORT reset focus state on bind",
)

# Show focus state in operator status.
report = must_replace(
    report,
    '''        formatView.text =
            "${qualityModes[qualityIndex]} • $activeVideoFpsLabel • $activeVideoStabilizationLabel • $activeVideoDynamicRangeLabel • SCENE ${sceneModes[sceneIndex]} • LOOK ${lookModes[lookIndex]}"
''',
    '''        formatView.text =
            "${qualityModes[qualityIndex]} • $activeVideoFpsLabel • $activeVideoStabilizationLabel • $activeVideoDynamicRangeLabel • ${focusAssistLabel()} • SCENE ${sceneModes[sceneIndex]} • LOOK ${lookModes[lookIndex]}"
''',
    "REPORT focus status",
)

# Arm long press on ACTION_DOWN.
report = must_replace(
    report,
    '''                    gestureMoved =
                        false

                    true
                }

                MotionEvent.ACTION_MOVE -> {
''',
    '''                    gestureMoved =
                        false

                    focusLongPressTriggered =
                        false

                    uiHandler.removeCallbacks(
                        focusLockRunnable
                    )

                    uiHandler.postDelayed(
                        focusLockRunnable,
                        650L
                    )

                    true
                }

                MotionEvent.ACTION_MOVE -> {
''',
    "REPORT long press start",
)

# Cancel the long press if the finger moves into zoom/exposure gesture.
report = must_replace(
    report,
    '''                        if (
                            maxOf(
                                abs(dx),
                                abs(dy)
                            ) >
                            dp(18)
                        ) {
                            gestureMoved =
                                true
                        }
''',
    '''                        if (
                            maxOf(
                                abs(dx),
                                abs(dy)
                            ) >
                            dp(18)
                        ) {
                            gestureMoved =
                                true

                            uiHandler.removeCallbacks(
                                focusLockRunnable
                            )
                        }
''',
    "REPORT cancel long press on move",
)

# ACTION_UP: cancel pending runnable; if long-press fired do not also tap.
report = must_replace(
    report,
    '''                MotionEvent.ACTION_UP -> {
                    if (
                        !gestureMoved
                    ) {
                        val now =
                            SystemClock.elapsedRealtime()
''',
    '''                MotionEvent.ACTION_UP -> {
                    uiHandler.removeCallbacks(
                        focusLockRunnable
                    )

                    if (
                        !gestureMoved &&
                        !focusLongPressTriggered
                    ) {
                        val now =
                            SystemClock.elapsedRealtime()
''',
    "REPORT action up focus lock",
)

# Single tap should release persistent focus before normal tap-to-focus.
report = must_replace(
    report,
    '''                        } else {
                            tapToFocus(
                                event.x,
                                event.y
                            )
                        }
''',
    '''                        } else {
                            releaseFocusLockForTap()

                            tapToFocus(
                                event.x,
                                event.y
                            )
                        }
''',
    "REPORT tap releases lock",
)

# Cancel runnable on ACTION_CANCEL.
report = must_replace(
    report,
    '''                MotionEvent.ACTION_CANCEL ->
                    true
''',
    '''                MotionEvent.ACTION_CANCEL -> {
                    uiHandler.removeCallbacks(
                        focusLockRunnable
                    )
                    true
                }
''',
    "REPORT action cancel",
)

# Add the focus control instructions to social camera status.
report = must_replace(
    report,
    '''            append("Mbps TARGET")
        }
    }
''',
    '''            append("Mbps TARGET")
            append(" • TAP AF")
            append(" • HOLD AF LOCK")
        }
    }
''',
    "REPORT social status focus assist",
)

REPORT.write_text(report, encoding="utf-8")

# ============================================================
# LIVE — quality engine wording / creator focus guidance
# We keep LIVE autofocus continuous for moving live subjects.
# ============================================================
live = LIVE.read_text(encoding="utf-8")

live = must_replace(
    live,
    '''        liveSubTitle =
            label(
                "LIVE STUDIO • ${profiles[profileIndex]} • READY",
''',
    '''        liveSubTitle =
            label(
                "LIVE STUDIO • ${profiles[profileIndex]} • CONTINUOUS AF • READY",
''',
    "LIVE continuous autofocus status",
)

live = live.replace(
    '"LIVE STUDIO • ${profiles[profileIndex]} • READY"',
    '"LIVE STUDIO • ${profiles[profileIndex]} • CONTINUOUS AF • READY"',
)

LIVE.write_text(live, encoding="utf-8")

# ============================================================
# HOME
# ============================================================
home = HOME.read_text(encoding="utf-8")

home = home.replace(
    '"SOCIAL MASTER PRO • V204"',
    '"PRO FOCUS ASSIST • V205"',
    1,
)

home = home.replace(
    '"SOCIAL FHD/60 • SOCIAL HDR • 4K 30/60 • ACTION 30/60 • HLG10 HDR • LOW-LIGHT AUTO FPS • 9:16 SOCIAL SAFE"',
    '"SOCIAL FHD/60 • SOCIAL HDR • 4K 30/60 • ACTION 30/60 • HLG10 HDR • LONG-PRESS AF LOCK • 9:16 SOCIAL SAFE"',
    1,
)

home = home.replace(
    '"FIELD REPORT • SOCIAL 30/60 • SOCIAL HDR • 4K 30/60 • ACTION 30/60 • low-light creator mode • telemetry"',
    '"FIELD REPORT • TAP TO FOCUS • LONG PRESS AF LOCK • SOCIAL 30/60 • HDR • 4K • ACTION • LOW LIGHT • telemetry"',
    1,
)

HOME.write_text(home, encoding="utf-8")

# ============================================================
# VERSION
# ============================================================
gradle = GRADLE.read_text(encoding="utf-8")
gradle = re.sub(
    r"versionCode\s*=\s*\d+",
    "versionCode = 20500",
    gradle,
    count=1,
)
gradle = re.sub(
    r'versionName\s*=\s*"[^"]+"',
    'versionName = "205.0-pro-focus-assist"',
    gradle,
    count=1,
)
GRADLE.write_text(gradle, encoding="utf-8")

print("V205 Pro Focus Assist patch applied.")
