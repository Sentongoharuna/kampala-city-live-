from pathlib import Path
import re

ROOT = Path("v172-source/app")
SRC = ROOT / "src/main/java/com/sentongoharuna/pulse"
REPORT = SRC / "DevelopUgandaCameraActivity.kt"
LIVE = SRC / "DevelopUgandaLiveActivity.kt"
HOME = SRC / "DevelopUgandaNewsroomActivity.kt"
INDEPENDENT = SRC / "DevelopUgandaIndependentCameras.kt"
MANIFEST = ROOT / "src/main/AndroidManifest.xml"
GRADLE = ROOT / "build.gradle.kts"

def must_replace(text, old, new, label):
    if old not in text:
        raise SystemExit(f"V216 patch anchor missing: {label}")
    return text.replace(old, new, 1)

report = REPORT.read_text(encoding="utf-8")

report = must_replace(
    report,
    "class DevelopUgandaCameraActivity : AppCompatActivity(), SensorEventListener {",
    "open class DevelopUgandaCameraActivity : AppCompatActivity(), SensorEventListener {",
    "open base camera",
)

report = must_replace(
    report,
    '''    private lateinit var previewHealthView: TextView
    private lateinit var focusReticleView: TextView
''',
    '''    private lateinit var previewHealthView: TextView
    private lateinit var cameraExperienceBannerView: TextView
    private lateinit var focusReticleView: TextView
''',
    "experience banner field",
)

report = must_replace(
    report,
    '''    private var reportDisplayMode = "FIELD REPORT"
    private var clipSequence = 0
''',
    '''    private var cameraExperienceId =
        "V210_ALL_PRO"

    protected open fun defaultCameraExperienceId(): String {
        return "V210_ALL_PRO"
    }

    private var reportDisplayMode = "FIELD REPORT"
    private var clipSequence = 0
''',
    "experience id",
)

report = must_replace(
    report,
    '''        loadReporterIdentity()
        loadReportCameraPreferences()
        reportId = newReportId()

        reportDisplayMode =
''',
    '''        cameraExperienceId =
            intent.getStringExtra(
                "develop_uganda_camera_experience"
            )
                ?.trim()
                ?.uppercase(
                    Locale.US
                )
                ?.takeIf {
                    it.isNotBlank()
                }
                ?: defaultCameraExperienceId()

        loadReporterIdentity()
        loadReportCameraPreferences()
        applyIndependentCameraDefaultsIfNeeded()
        reportId = newReportId()

        reportDisplayMode =
''',
    "experience read before prefs",
)

report = must_replace(
    report,
    '''                ?.takeIf { it.isNotBlank() }
                ?: "FIELD REPORT"
''',
    '''                ?.takeIf { it.isNotBlank() }
                ?: cameraExperienceDisplayName()
''',
    "experience display fallback",
)

report = must_replace(
    report,
    '''        previewNarrationPanel.addView(
            previewBrandRow
        )

        previewIdentityView =
''',
    '''        previewNarrationPanel.addView(
            previewBrandRow
        )

        cameraExperienceBannerView =
            hud(
                cameraExperienceDisplayName(),
                7.5f,
                cameraExperienceAccentColor(),
                bold = true
            ).apply {
                maxLines = 2
                setPadding(
                    dp(7),
                    dp(2),
                    dp(7),
                    dp(2)
                )
                background =
                    GradientDrawable().apply {
                        shape =
                            GradientDrawable.RECTANGLE
                        cornerRadius =
                            dp(9).toFloat()
                        setColor(
                            0x52031829
                        )
                        setStroke(
                            dp(1),
                            cameraExperienceAccentColor()
                        )
                    }
            }

        previewNarrationPanel.addView(
            cameraExperienceBannerView,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(27)
            )
        )

        previewIdentityView =
''',
    "experience banner UI",
)

report = must_replace(
    report,
    '''    private fun autoDirectorSuggestedMode(): Pair<String, String> {
''',
    '''    private fun reportCameraPrefsName(): String {
        return "develop_uganda_report_camera_" +
            cameraExperienceId.lowercase(
                Locale.US
            )
    }

    private fun cameraExperienceDisplayName(): String {
        return when (cameraExperienceId) {
            "V205_FOCUS" ->
                "V205 • FOCUS ASSIST CAMERA"
            "V206_METER" ->
                "V206 • METERING LOCK CAMERA"
            "V207_HORIZON" ->
                "V207 • HORIZON CAMERA"
            "V208_STEADY" ->
                "V208 • STEADYSHOT CAMERA"
            "V209_NIGHT" ->
                "V209 • NIGHT INTELLIGENCE CAMERA"
            "V210_ALL_PRO" ->
                "V210 • ALL-PRO FIELD CAMERA"
            "V211_AUDIO" ->
                "V211 • AUDIO GUARD CAMERA"
            "V212_VERIFIED" ->
                "V212 • VERIFIED EVIDENCE CAMERA"
            "V213_THERMAL" ->
                "V213 • THERMAL SAFE CAMERA"
            "V214_SIGNATURE" ->
                "V214 • MODE SIGNATURE CAMERA"
            "V215_AUTO" ->
                "V215 • SMART AUTO DIRECTOR CAMERA"
            else ->
                "V210 • ALL-PRO FIELD CAMERA"
        }
    }

    private fun cameraExperienceShortLabel(): String {
        return cameraExperienceDisplayName()
            .removeSuffix(
                " CAMERA"
            )
    }

    private fun cameraExperienceInstruction(): String {
        return when (cameraExperienceId) {
            "V205_FOCUS" ->
                "TAP SUBJECT TO FOCUS • HOLD TO LOCK AF"
            "V206_METER" ->
                "HOLD SUBJECT FOR AF + AE + AWB METER LOCK"
            "V207_HORIZON" ->
                "KEEP HORIZON GUIDE GREEN • LEVEL LOCK"
            "V208_STEADY" ->
                "WATCH STEADY / MOVING / SHAKE • ACTION STAB DEFAULT"
            "V209_NIGHT" ->
                "REAL LUX SENSOR • LOW LIGHT DEFAULT • 30FPS ADVICE"
            "V210_ALL_PRO" ->
                "ALL PRO TOOLS V204→V215 AVAILABLE TOGETHER"
            "V211_AUDIO" ->
                "MIC LEVEL • PEAK • LOW / GOOD / HOT / CLIP RISK"
            "V212_VERIFIED" ->
                "LIVE CAMERAX + SENSOR + AUDIO STATE • VERIFIED OUTPUT"
            "V213_THERMAL" ->
                "REAL ANDROID THERMAL STATE • SAFE FALLBACK AT SEVERE+"
            "V214_SIGNATURE" ->
                "MODE-SPECIFIC PREVIEW TONE • EXACT MODE/LOOK RECORDED"
            "V215_AUTO" ->
                "AUTO DIRECTOR • REAL LUX + MOTION + THERMAL PROFILE SELECTION"
            else ->
                "ALL PRO CAMERA TOOLS"
        }
    }

    private fun cameraExperienceAccentColor(): Int {
        return when (cameraExperienceId) {
            "V205_FOCUS" -> 0xFFAEBDEB.toInt()
            "V206_METER" -> 0xFFD0B06F.toInt()
            "V207_HORIZON" -> 0xFF91B6A0.toInt()
            "V208_STEADY" -> 0xFF71B9A7.toInt()
            "V209_NIGHT" -> 0xFF8A86B8.toInt()
            "V210_ALL_PRO" -> 0xFF8FA8E8.toInt()
            "V211_AUDIO" -> 0xFF83B995.toInt()
            "V212_VERIFIED" -> 0xFF73B7D9.toInt()
            "V213_THERMAL" -> 0xFFC76D73.toInt()
            "V214_SIGNATURE" -> 0xFFA793D8.toInt()
            "V215_AUTO" -> 0xFF73B7D9.toInt()
            else -> 0xFFAEBDEB.toInt()
        }
    }

    private fun applyIndependentCameraDefaultsIfNeeded() {
        val prefs =
            getSharedPreferences(
                reportCameraPrefsName(),
                Context.MODE_PRIVATE
            )

        if (
            prefs.getBoolean(
                "experience_initialized",
                false
            )
        ) {
            return
        }

        fun quality(value: String) {
            val index = qualityModes.indexOf(value)
            if (index >= 0) qualityIndex = index
        }

        fun look(value: String) {
            val index = lookModes.indexOf(value)
            if (index >= 0) lookIndex = index
        }

        fun scene(value: String) {
            val index = sceneModes.indexOf(value)
            if (index >= 0) sceneIndex = index
        }

        when (cameraExperienceId) {
            "V205_FOCUS" -> {
                quality("SOCIAL FHD")
                scene("INTERVIEW")
                look("CLEAN")
            }
            "V206_METER" -> {
                quality("SOCIAL FHD")
                scene("REPORTER")
                look("NATURAL")
            }
            "V207_HORIZON" -> {
                quality("SOCIAL FHD")
                scene("OUTDOOR")
                look("NATURAL")
            }
            "V208_STEADY" -> {
                quality("ACTION STAB")
                scene("DOCUMENTARY")
                look("CLEAN")
            }
            "V209_NIGHT" -> {
                quality("LOW LIGHT")
                scene("NIGHT")
                look("NIGHT")
            }
            "V210_ALL_PRO" -> {
                quality("SOCIAL FHD")
                scene("REPORTER")
                look("CLEAN")
            }
            "V211_AUDIO" -> {
                quality("SOCIAL FHD")
                scene("INTERVIEW")
                look("CLEAN")
            }
            "V212_VERIFIED" -> {
                quality("SOCIAL FHD")
                scene("NEWS")
                look("NATURAL")
            }
            "V213_THERMAL" -> {
                quality("SOCIAL FHD")
                scene("REPORTER")
                look("CLEAN")
            }
            "V214_SIGNATURE" -> {
                quality("SOCIAL HDR")
                scene("CINEMA")
                look("WARM")
            }
            "V215_AUTO" -> {
                quality("SOCIAL FHD")
                scene("REPORTER")
                look("CLEAN")
                autoDirectorEnabled = true
            }
        }

        prefs.edit()
            .putBoolean(
                "experience_initialized",
                true
            )
            .apply()

        saveReportCameraPreferences()
    }

    private fun applyIndependentCameraExperienceUi() {
        if (::cameraExperienceBannerView.isInitialized) {
            cameraExperienceBannerView.text =
                "${cameraExperienceDisplayName()}\\n${cameraExperienceInstruction()}"
            cameraExperienceBannerView.setTextColor(
                cameraExperienceAccentColor()
            )
        }

        val mutedAlpha = 0.36f

        if (::horizonGuardView.isInitialized) {
            horizonGuardView.alpha =
                if (
                    cameraExperienceId in setOf(
                        "V207_HORIZON",
                        "V210_ALL_PRO",
                        "V212_VERIFIED",
                        "V215_AUTO"
                    )
                ) 1f else mutedAlpha
        }

        if (::motionGuardView.isInitialized) {
            motionGuardView.alpha =
                if (
                    cameraExperienceId in setOf(
                        "V208_STEADY",
                        "V210_ALL_PRO",
                        "V212_VERIFIED",
                        "V215_AUTO"
                    )
                ) 1f else mutedAlpha
        }

        if (::lightAdvisorView.isInitialized) {
            lightAdvisorView.alpha =
                if (
                    cameraExperienceId in setOf(
                        "V209_NIGHT",
                        "V210_ALL_PRO",
                        "V212_VERIFIED",
                        "V215_AUTO"
                    )
                ) 1f else mutedAlpha
        }

        if (::audioGuardView.isInitialized) {
            audioGuardView.alpha =
                if (
                    cameraExperienceId in setOf(
                        "V211_AUDIO",
                        "V210_ALL_PRO",
                        "V212_VERIFIED"
                    )
                ) 1f else mutedAlpha
        }

        if (::thermalGuardView.isInitialized) {
            thermalGuardView.alpha =
                if (
                    cameraExperienceId in setOf(
                        "V213_THERMAL",
                        "V210_ALL_PRO",
                        "V212_VERIFIED",
                        "V215_AUTO"
                    )
                ) 1f else mutedAlpha
        }

        if (::autoDirectorButton.isInitialized) {
            autoDirectorButton.alpha =
                if (
                    cameraExperienceId ==
                        "V215_AUTO"
                ) 1f else 0.64f
        }
    }

    private fun autoDirectorSuggestedMode(): Pair<String, String> {
''',
    "independent camera model",
)

if '"develop_uganda_report_camera"' not in report:
    raise SystemExit("V216 patch anchor missing: shared report prefs")
report = report.replace(
    '"develop_uganda_report_camera"',
    'reportCameraPrefsName()'
)

report = report.replace(
    'append("V215 VERIFIED")',
    'append("V216 VERIFIED")',
    1,
)

report = must_replace(
    report,
    '''            append(" • ")
            append(
                autoDirectorStateText()
            )
        }
    }
''',
    '''            append(" • ")
            append(
                autoDirectorStateText()
            )
            append(" • CAMERA ")
            append(
                cameraExperienceShortLabel()
            )
        }
    }
''',
    "verified camera identity",
)

report = must_replace(
    report,
    '''        applyAutoDirectorIfNeeded()
        updateReportModePreviewTuning()
        updateHorizonGuard()
''',
    '''        applyAutoDirectorIfNeeded()
        updateReportModePreviewTuning()
        applyIndependentCameraExperienceUi()
        updateHorizonGuard()
''',
    "apply independent camera UI",
)

report = report.replace(
    '"develop.uganda • V215"',
    '"develop.uganda • V216"',
    1,
)

report = must_replace(
    report,
    '''            "${sceneTag()} • V215",
''',
    '''            "${sceneTag()} • V216",
''',
    "recorded V216 tag",
)

report = must_replace(
    report,
    '''            "$recState   |   TC ${tc()}   |   V215   |   THERM ${thermalStateLabel()}",
''',
    '''            "$recState   |   TC ${tc()}   |   V216   |   CAMERA ${cameraExperienceShortLabel()}   |   THERM ${thermalStateLabel()}",
''',
    "recorded camera identity",
)

report = must_replace(
    report,
    '''            "MODE • ${qualityModes[qualityIndex]}   |   ${reportModePurposeLabel()}   |   SCENE • ${sceneModes[sceneIndex]}   |   LOOK • ${lookModes[lookIndex]}   |   ${autoDirectorStateText()}",
''',
    '''            "MODE • ${qualityModes[qualityIndex]}   |   ${reportModePurposeLabel()}   |   SCENE • ${sceneModes[sceneIndex]}   |   LOOK • ${lookModes[lookIndex]}   |   ${autoDirectorStateText()}   |   CAMERA • ${cameraExperienceShortLabel()}",
''',
    "recorded camera row",
)

report = report.replace(
    '"DEVELOP_UGANDA_V215_${reportId}_${sceneModes[sceneIndex]}_${lookModes[lookIndex]}_"',
    '"DEVELOP_UGANDA_V216_${cameraExperienceId}_${reportId}_${sceneModes[sceneIndex]}_${lookModes[lookIndex]}_"',
    1,
)

report = must_replace(
    report,
    '''        val autoDirectorSnapshot =
            autoDirectorStateText()

        val sceneSnapshot =
''',
    '''        val autoDirectorSnapshot =
            autoDirectorStateText()

        val cameraExperienceIdSnapshot =
            cameraExperienceId

        val cameraExperienceLabelSnapshot =
            cameraExperienceDisplayName()

        val sceneSnapshot =
''',
    "integrity experience snapshot",
)

report = report.replace(
    '''                            "V215"
''',
    '''                            "V216"
''',
    1,
)

report = report.replace(
    '''                            "V215 SMART AUTO DIRECTOR PRO"
''',
    '''                            "V216 INDEPENDENT CAMERA SUITE"
''',
    1,
)

report = report.replace(
    '''                            "V204,V205,V206,V207,V208,V209,V210,V211,V212,V213,V214,V215"
''',
    '''                            "V204,V205,V206,V207,V208,V209,V210,V211,V212,V213,V214,V215,V216"
''',
    1,
)

report = must_replace(
    report,
    '''                        put(
                            "auto_director",
                            autoDirectorSnapshot
                        )
                        put(
                            "scene",
''',
    '''                        put(
                            "auto_director",
                            autoDirectorSnapshot
                        )
                        put(
                            "camera_experience_id",
                            cameraExperienceIdSnapshot
                        )
                        put(
                            "camera_experience_label",
                            cameraExperienceLabelSnapshot
                        )
                        put(
                            "scene",
''',
    "integrity camera identity",
)

REPORT.write_text(report, encoding="utf-8")

INDEPENDENT.write_text(
'''package com.sentongoharuna.pulse

class DevelopUgandaFocusAssistCameraActivity :
    DevelopUgandaCameraActivity() {
    override fun defaultCameraExperienceId(): String =
        "V205_FOCUS"
}

class DevelopUgandaMeteringLockCameraActivity :
    DevelopUgandaCameraActivity() {
    override fun defaultCameraExperienceId(): String =
        "V206_METER"
}

class DevelopUgandaHorizonCameraActivity :
    DevelopUgandaCameraActivity() {
    override fun defaultCameraExperienceId(): String =
        "V207_HORIZON"
}

class DevelopUgandaSteadyShotCameraActivity :
    DevelopUgandaCameraActivity() {
    override fun defaultCameraExperienceId(): String =
        "V208_STEADY"
}

class DevelopUgandaNightIntelligenceCameraActivity :
    DevelopUgandaCameraActivity() {
    override fun defaultCameraExperienceId(): String =
        "V209_NIGHT"
}

class DevelopUgandaAllProCameraActivity :
    DevelopUgandaCameraActivity() {
    override fun defaultCameraExperienceId(): String =
        "V210_ALL_PRO"
}

class DevelopUgandaAudioGuardCameraActivity :
    DevelopUgandaCameraActivity() {
    override fun defaultCameraExperienceId(): String =
        "V211_AUDIO"
}

class DevelopUgandaVerifiedCameraActivity :
    DevelopUgandaCameraActivity() {
    override fun defaultCameraExperienceId(): String =
        "V212_VERIFIED"
}

class DevelopUgandaThermalSafeCameraActivity :
    DevelopUgandaCameraActivity() {
    override fun defaultCameraExperienceId(): String =
        "V213_THERMAL"
}

class DevelopUgandaModeSignatureCameraActivity :
    DevelopUgandaCameraActivity() {
    override fun defaultCameraExperienceId(): String =
        "V214_SIGNATURE"
}

class DevelopUgandaAutoDirectorCameraActivity :
    DevelopUgandaCameraActivity() {
    override fun defaultCameraExperienceId(): String =
        "V215_AUTO"
}
''',
    encoding="utf-8"
)

manifest = MANIFEST.read_text(encoding="utf-8")
manifest_anchor = '''        <activity
            android:name=".DevelopUgandaCameraActivity"
            android:screenOrientation="portrait"
            android:exported="false"/>
'''

manifest_insert = '''        <activity
            android:name=".DevelopUgandaFocusAssistCameraActivity"
            android:screenOrientation="portrait"
            android:exported="false"/>

        <activity
            android:name=".DevelopUgandaMeteringLockCameraActivity"
            android:screenOrientation="portrait"
            android:exported="false"/>

        <activity
            android:name=".DevelopUgandaHorizonCameraActivity"
            android:screenOrientation="portrait"
            android:exported="false"/>

        <activity
            android:name=".DevelopUgandaSteadyShotCameraActivity"
            android:screenOrientation="portrait"
            android:exported="false"/>

        <activity
            android:name=".DevelopUgandaNightIntelligenceCameraActivity"
            android:screenOrientation="portrait"
            android:exported="false"/>

        <activity
            android:name=".DevelopUgandaAllProCameraActivity"
            android:screenOrientation="portrait"
            android:exported="false"/>

        <activity
            android:name=".DevelopUgandaAudioGuardCameraActivity"
            android:screenOrientation="portrait"
            android:exported="false"/>

        <activity
            android:name=".DevelopUgandaVerifiedCameraActivity"
            android:screenOrientation="portrait"
            android:exported="false"/>

        <activity
            android:name=".DevelopUgandaThermalSafeCameraActivity"
            android:screenOrientation="portrait"
            android:exported="false"/>

        <activity
            android:name=".DevelopUgandaModeSignatureCameraActivity"
            android:screenOrientation="portrait"
            android:exported="false"/>

        <activity
            android:name=".DevelopUgandaAutoDirectorCameraActivity"
            android:screenOrientation="portrait"
            android:exported="false"/>

''' + manifest_anchor

if "DevelopUgandaFocusAssistCameraActivity" not in manifest:
    manifest = must_replace(
        manifest,
        manifest_anchor,
        manifest_insert,
        "manifest independent activities",
    )

MANIFEST.write_text(manifest, encoding="utf-8")

home = HOME.read_text(encoding="utf-8")

home = home.replace(
    '"SMART AUTO DIRECTOR PRO • V215"',
    '"INDEPENDENT CAMERA SUITE • V216"',
    1,
)

home = home.replace(
    '"V204→V215 ALL RETAINED • SOCIAL/HDR/4K/ACTION • AF/METER • HORIZON • STEADYSHOT • NIGHT • AUDIO • VERIFIED • THERMAL • MODE PREVIEW • SMART AUTO DIRECTOR • 9:16 SAFE"',
    '"V205→V215 NOW OPEN AS SEPARATE CAMERAS • V204 ENGINE RETAINED • EACH CAMERA HAS ITS OWN STATE/DEFAULTS/UI EMPHASIS/RECORDED IDENTITY • V216"',
    1,
)

home = home.replace(
    '"FIELD REPORT • V215 SMART AUTO DIRECTOR • ALL V204→V214 RETAINED • REAL LUX/MOTION/THERMAL INPUTS CHOOSE REAL CAMERA PROFILE • NEVER SWITCHES DURING RECORDING • telemetry"',
    '"FIELD REPORT • V216 INDEPENDENT CAMERA SUITE • V205→V215 DIRECT HOME LAUNCHERS • SEPARATE CAMERA ACTIVITIES + PREFERENCES • NOTHING DROPPED • telemetry"',
    1,
)

start_marker = '''        page.addView(
            sectionTitle(
                "PRO CAMERA MODULES"
            )
        )
'''
end_marker = '''        val quickLaunch =
'''

start = home.find(start_marker)
end = home.find(end_marker, start if start >= 0 else 0)
if start < 0 or end < 0:
    raise SystemExit("V216 patch anchor missing: home module block")

cards = '''        page.addView(
            sectionTitle(
                "INDEPENDENT PRO CAMERAS"
            )
        )

        page.addView(
            compactStatus(
                "V216 CAMERA ARCHITECTURE",
                "NO DROPDOWN TO OPEN THESE CAMERAS • EVERY CARD BELOW OPENS ITS OWN ANDROID CAMERA ACTIVITY • EACH CAMERA REMEMBERS ITS OWN SETTINGS",
                green
            )
        )

        page.addView(
            launchCard(
                "V205 • FOCUS ASSIST CAMERA",
                "Dedicated subject-focus camera",
                "Tap subject for AF • long-press persistent AF lock • INTERVIEW + SOCIAL FHD default • focus reticle emphasized • all shared recording/telemetry tools remain",
                gold,
                "OPEN V205 FOCUS CAMERA"
            ) {
                openIndependentCamera(
                    DevelopUgandaFocusAssistCameraActivity::class.java
                )
            }
        )

        page.addView(
            launchCard(
                "V206 • METERING LOCK CAMERA",
                "Dedicated AF + AE + AWB metering camera",
                "Long-press metering region • visible reticle • NATURAL default • independent saved settings • exact camera identity burned into V216 output",
                0xFFD0B06F.toInt(),
                "OPEN V206 METER CAMERA"
            ) {
                openIndependentCamera(
                    DevelopUgandaMeteringLockCameraActivity::class.java
                )
            }
        )

        page.addView(
            launchCard(
                "V207 • HORIZON CAMERA",
                "Dedicated level-composition camera",
                "Rotation-vector horizon guide emphasized • LEVEL LOCK / LEVEL NEAR / ADJUST • OUTDOOR default • other modules retained but visually secondary",
                green,
                "OPEN V207 HORIZON CAMERA"
            ) {
                openIndependentCamera(
                    DevelopUgandaHorizonCameraActivity::class.java
                )
            }
        )

        page.addView(
            launchCard(
                "V208 • STEADYSHOT CAMERA",
                "Dedicated handheld-motion camera",
                "ACTION STAB default • real STEADY / MOVING / SHAKE guidance emphasized • DOCUMENTARY default • device stabilization remains real CameraX capability",
                0xFF71B9A7.toInt(),
                "OPEN V208 STEADYSHOT CAMERA"
            ) {
                openIndependentCamera(
                    DevelopUgandaSteadyShotCameraActivity::class.java
                )
            }
        )

        page.addView(
            launchCard(
                "V209 • NIGHT INTELLIGENCE CAMERA",
                "Dedicated low-light reporting camera",
                "LOW LIGHT + NIGHT defaults • real Android lux sensor emphasized • dark/dim/normal/bright guidance • 30fps advice preserved",
                0xFF8A86B8.toInt(),
                "OPEN V209 NIGHT CAMERA"
            ) {
                openIndependentCamera(
                    DevelopUgandaNightIntelligenceCameraActivity::class.java
                )
            }
        )

        page.addView(
            launchCard(
                "V210 • ALL-PRO FIELD CAMERA",
                "Full cumulative professional field camera",
                "All V204→V215 tools visible together • Social Master capture engine • focus/meter/horizon/motion/lux/audio/thermal/verified-state controls • REPORTER default",
                cyan,
                "OPEN V210 ALL-PRO CAMERA"
            ) {
                openIndependentCamera(
                    DevelopUgandaAllProCameraActivity::class.java
                )
            }
        )

        page.addView(
            launchCard(
                "V211 • AUDIO GUARD CAMERA",
                "Dedicated interview/audio-monitoring camera",
                "CameraX microphone amplitude + peak emphasized • LOW / GOOD / HOT / CLIP RISK • INTERVIEW default • audio track is still recorded normally",
                green,
                "OPEN V211 AUDIO CAMERA"
            ) {
                openIndependentCamera(
                    DevelopUgandaAudioGuardCameraActivity::class.java
                )
            }
        )

        page.addView(
            launchCard(
                "V212 • VERIFIED EVIDENCE CAMERA",
                "Dedicated verification/evidence camera",
                "Live CameraX + GPS + sensor + audio state emphasized • NEWS default • V216 filename and SHA-256 integrity metadata identify this exact camera",
                0xFF73B7D9.toInt(),
                "OPEN V212 VERIFIED CAMERA"
            ) {
                openIndependentCamera(
                    DevelopUgandaVerifiedCameraActivity::class.java
                )
            }
        )

        page.addView(
            launchCard(
                "V213 • THERMAL SAFE CAMERA",
                "Dedicated heat-aware long-recording camera",
                "Android PowerManager thermal state emphasized • severe+ safe fallback retained • SOCIAL FHD default • thermal state recorded in output",
                red,
                "OPEN V213 THERMAL CAMERA"
            ) {
                openIndependentCamera(
                    DevelopUgandaThermalSafeCameraActivity::class.java
                )
            }
        )

        page.addView(
            launchCard(
                "V214 • MODE SIGNATURE CAMERA",
                "Dedicated mode/look camera",
                "SOCIAL HDR + WARM first-run defaults • subtle look-matched preview • mode accent/purpose • exact quality/scene/look recorded",
                0xFFA793D8.toInt(),
                "OPEN V214 SIGNATURE CAMERA"
            ) {
                openIndependentCamera(
                    DevelopUgandaModeSignatureCameraActivity::class.java
                )
            }
        )

        page.addView(
            launchCard(
                "V215 • SMART AUTO DIRECTOR CAMERA",
                "Dedicated automatic field camera",
                "AUTO DIRECTOR enabled on first launch • real lux + shake + thermal choose actual Social FHD / Social 60 / Action Stab / Low Light • never changes mid-recording",
                0xFF73B7D9.toInt(),
                "OPEN V215 AUTO CAMERA"
            ) {
                openIndependentCamera(
                    DevelopUgandaAutoDirectorCameraActivity::class.java
                )
            }
        )

        page.addView(
            compactStatus(
                "NOTHING DROPPED",
                "V204 CAPTURE ENGINE + V205→V215 FUNCTIONAL MODULES REMAIN IN THE SHARED CORE • V216 MAKES THEM DIRECT-LAUNCH INDEPENDENT CAMERAS",
                gold
            )
        )

'''

home = home[:start] + cards + home[end:]

home = must_replace(
    home,
    '''    private fun openReportCamera() {
''',
    '''    private fun openIndependentCamera(
        cameraClass: Class<*>
    ) {
        startActivity(
            Intent(
                this,
                cameraClass
            )
        )
    }

    private fun openReportCamera() {
''',
    "home independent launcher helper",
)

HOME.write_text(home, encoding="utf-8")

live = LIVE.read_text(encoding="utf-8")
live = live.replace(
    '"develop.uganda • V215"',
    '"develop.uganda • V216"',
    1,
)
live = live.replace(
    'append("V215 VERIFIED")',
    'append("V216 VERIFIED")',
    1,
)
live = live.replace(
    'MANUAL LIVE • V215',
    'MANUAL LIVE • V216'
)
live = live.replace(
    '"DEVELOP_UGANDA_V215_LIVE_${profiles[profileIndex]}_$stamp"',
    '"DEVELOP_UGANDA_V216_LIVE_${profiles[profileIndex]}_$stamp"',
    1,
)
LIVE.write_text(live, encoding="utf-8")

gradle = GRADLE.read_text(encoding="utf-8")
gradle = re.sub(
    r"versionCode\s*=\s*\d+",
    "versionCode = 21600",
    gradle,
    count=1,
)
gradle = re.sub(
    r'versionName\s*=\s*"[^"]+"',
    'versionName = "216.0-independent-camera-suite"',
    gradle,
    count=1,
)
GRADLE.write_text(gradle, encoding="utf-8")

print("V216 Independent Camera Suite patch applied.")
