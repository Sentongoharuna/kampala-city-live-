from pathlib import Path
import re

ROOT = Path("v172-source/app")
SRC = ROOT / "src/main/java/com/sentongoharuna/pulse"
REPORT = SRC / "DevelopUgandaCameraActivity.kt"
LIVE = SRC / "DevelopUgandaLiveActivity.kt"
HOME = SRC / "DevelopUgandaNewsroomActivity.kt"
GRADLE = ROOT / "build.gradle.kts"

PAYLOAD = Path(__file__).resolve().parent

gradle = GRADLE.read_text(encoding="utf-8")

if 'versionCode = 22200' not in gradle:
    raise SystemExit("V223 FIX1 expects V222 Social Media Camera first")

if 'versionName = "222.0-social-media-camera"' not in gradle:
    raise SystemExit("V223 expects V222 versionName")

if 'com.google.mlkit:image-labeling:17.0.9' not in gradle:
    anchor = '    implementation("com.google.android.gms:play-services-location:21.4.0")\n'
    if anchor not in gradle:
        raise SystemExit("V223 Gradle ML Kit anchor missing")

    gradle = gradle.replace(
        anchor,
        anchor +
        '    implementation("com.google.mlkit:image-labeling:17.0.9")\n',
        1
    )

# ------------------------------------------------------------
# REPORT / independent camera suite
# ------------------------------------------------------------

report = REPORT.read_text(encoding="utf-8")

ml_imports = (
    "import com.google.mlkit.vision.common.InputImage\n"
    "import com.google.mlkit.vision.label.ImageLabeler\n"
    "import com.google.mlkit.vision.label.ImageLabeling\n"
    "import com.google.mlkit.vision.label.defaults.ImageLabelerOptions\n"
)

if "import com.google.mlkit.vision.label.ImageLabeling\n" not in report:
    anchor = "import com.google.android.gms.location.Priority\n"
    if anchor not in report:
        raise SystemExit("V223 REPORT ML import anchor missing")

    report = report.replace(
        anchor,
        anchor + ml_imports,
        1
    )

field_anchor = "    private lateinit var cameraExperienceBannerView: TextView\n"

if "private lateinit var autoViewDescriptionView: TextView" not in report:
    if field_anchor not in report:
        raise SystemExit("V223 REPORT view field anchor missing")

    report = report.replace(
        field_anchor,
        field_anchor +
        "    private lateinit var autoViewDescriptionView: TextView\n",
        1
    )

state_anchor = "    private var focusLockActive = false\n"

if "private lateinit var autoViewLabeler: ImageLabeler" not in report:
    if state_anchor not in report:
        raise SystemExit("V223 REPORT state anchor missing")

    report = report.replace(
        state_anchor,
        state_anchor +
        "    private lateinit var autoViewLabeler: ImageLabeler\n"
        "    private var autoViewBusy = false\n"
        "    private var autoViewSummary = \"AUTO VIEW • analysing scene\"\n",
        1
    )

handler_anchor = "    private val uiHandler = Handler(Looper.getMainLooper())\n"

if "private val autoViewRunnable" not in report:
    if handler_anchor not in report:
        raise SystemExit("V223 REPORT handler anchor missing")

    runnable = (
        handler_anchor +
        "\n"
        "    private val autoViewRunnable =\n"
        "        object : Runnable {\n"
        "            override fun run() {\n"
        "                analyzeAutoViewFrame()\n"
        "\n"
        "                uiHandler.postDelayed(\n"
        "                    this,\n"
        "                    3500L\n"
        "                )\n"
        "            }\n"
        "        }\n"
    )

    report = report.replace(
        handler_anchor,
        runnable,
        1
    )

banner_anchor = (
    "        previewNarrationPanel.addView(\n"
    "            cameraExperienceBannerView,\n"
    "            LinearLayout.LayoutParams(\n"
    "                ViewGroup.LayoutParams.MATCH_PARENT,\n"
    "                dp(27)\n"
    "            )\n"
    "        )\n"
)

if "autoViewDescriptionView =" not in report:
    if banner_anchor not in report:
        raise SystemExit("V223 REPORT banner UI anchor missing")

    ui = (
        PAYLOAD / "report_auto_view_ui.txt"
    ).read_text(encoding="utf-8")

    report = report.replace(
        banner_anchor,
        banner_anchor + ui,
        1
    )

oncreate_anchor = (
    "        buildUi()\n"
    "        requestPermissionsAndStart()\n"
    "        uiHandler.post(tick)\n"
)

if "startAutoViewDescription()" not in report:
    if oncreate_anchor not in report:
        raise SystemExit("V223 REPORT onCreate anchor missing")

    report = report.replace(
        oncreate_anchor,
        "        buildUi()\n"
        "        startAutoViewDescription()\n"
        "        requestPermissionsAndStart()\n"
        "        uiHandler.post(tick)\n",
        1
    )

if "private fun analyzeAutoViewFrame()" not in report:
    helper_anchor = "    private fun createIntegrityRecord(\n"

    if helper_anchor not in report:
        raise SystemExit("V223 REPORT helper anchor missing")

    helpers = (
        PAYLOAD / "report_auto_view_helpers.txt"
    ).read_text(encoding="utf-8")

    report = report.replace(
        helper_anchor,
        helpers + helper_anchor,
        1
    )

destroy_anchor = (
    "    override fun onDestroy() {\n"
    "        uiHandler.removeCallbacksAndMessages(\n"
    "            null\n"
    "        )\n"
)

if "autoViewLabeler.close()" not in report:
    if destroy_anchor not in report:
        raise SystemExit("V223 REPORT destroy anchor missing")

    close_block = (
        destroy_anchor +
        "\n"
        "        if (\n"
        "            ::autoViewLabeler.isInitialized\n"
        "        ) {\n"
        "            try {\n"
        "                autoViewLabeler.close()\n"
        "            } catch (_: Exception) {\n"
        "            }\n"
        "        }\n"
    )

    report = report.replace(
        destroy_anchor,
        close_block,
        1
    )

# FIX2: Do not rewrite cameraExperienceBannerView using exact source text.
# The existing independent-camera banner is preserved exactly as it is.
# Auto View is added as a separate operator-only line, avoiding source-format coupling.

# Overall build advances to V223; the independent camera family name
# remains V205...V222 and is already burned as CAMERA • <name>.
report = report.replace(
    '"app_version",\n                            "V222"',
    '"app_version",\n                            "V223"',
    1
)

report = report.replace(
    '"${sceneTag()} • V222"',
    '"${sceneTag()} • V223"',
    1
)

report = report.replace(
    '•   V222   •   THERM',
    '•   V223   •   THERM',
    1
)

report = report.replace(
    '"DEVELOP_UGANDA_V222_${cameraExperienceId}_',
    '"DEVELOP_UGANDA_V223_${cameraExperienceId}_',
    1
)

REPORT.write_text(
    report,
    encoding="utf-8"
)

# ------------------------------------------------------------
# LIVE auto view
# ------------------------------------------------------------

live = LIVE.read_text(encoding="utf-8")

if "import com.google.mlkit.vision.label.ImageLabeling\n" not in live:
    anchor = "import androidx.core.content.ContextCompat\n"

    if anchor not in live:
        raise SystemExit("V223 LIVE ML import anchor missing")

    live = live.replace(
        anchor,
        anchor + ml_imports,
        1
    )

live_field_anchor = "    private lateinit var livePreviewTech: TextView\n"

if "private lateinit var liveAutoViewDescriptionView: TextView" not in live:
    if live_field_anchor not in live:
        raise SystemExit("V223 LIVE view field anchor missing")

    live = live.replace(
        live_field_anchor,
        live_field_anchor +
        "    private lateinit var liveAutoViewDescriptionView: TextView\n",
        1
    )

live_state_anchor = "    private var liveBlinkOn = true\n"

if "private lateinit var liveAutoViewLabeler: ImageLabeler" not in live:
    if live_state_anchor not in live:
        raise SystemExit("V223 LIVE state anchor missing")

    live = live.replace(
        live_state_anchor,
        live_state_anchor +
        "    private lateinit var liveAutoViewLabeler: ImageLabeler\n"
        "    private var liveAutoViewBusy = false\n"
        "    private var liveAutoViewSummary = \"AUTO VIEW • analysing scene\"\n",
        1
    )

live_handler_anchor = (
    "    private val uiHandler =\n"
    "        Handler(Looper.getMainLooper())\n"
)

if "private val liveAutoViewRunnable" not in live:
    if live_handler_anchor not in live:
        raise SystemExit("V223 LIVE handler anchor missing")

    live_runnable = (
        live_handler_anchor +
        "\n"
        "    private val liveAutoViewRunnable =\n"
        "        object : Runnable {\n"
        "            override fun run() {\n"
        "                analyzeLiveAutoViewFrame()\n"
        "\n"
        "                uiHandler.postDelayed(\n"
        "                    this,\n"
        "                    3500L\n"
        "                )\n"
        "            }\n"
        "        }\n"
    )

    live = live.replace(
        live_handler_anchor,
        live_runnable,
        1
    )

live_tech_anchor = (
    "        topPanel.addView(\n"
    "            livePreviewTech\n"
    "        )\n"
)

if "liveAutoViewDescriptionView =" not in live:
    if live_tech_anchor not in live:
        raise SystemExit("V223 LIVE tech UI anchor missing")

    ui = (
        PAYLOAD / "live_auto_view_ui.txt"
    ).read_text(encoding="utf-8")

    live = live.replace(
        live_tech_anchor,
        live_tech_anchor + ui,
        1
    )

live_oncreate_anchor = (
    "        loadLiveIdentity()\n"
    "        loadLiveCameraPreferences()\n"
    "        buildLiveUi()\n"
    "        requestNeededPermissions()\n"
    "\n"
    "        uiHandler.post(\n"
    "            uiTicker\n"
    "        )\n"
)

if "startLiveAutoViewDescription()" not in live:
    if live_oncreate_anchor not in live:
        raise SystemExit("V223 LIVE onCreate anchor missing")

    live = live.replace(
        live_oncreate_anchor,
        "        loadLiveIdentity()\n"
        "        loadLiveCameraPreferences()\n"
        "        buildLiveUi()\n"
        "        startLiveAutoViewDescription()\n"
        "        requestNeededPermissions()\n"
        "\n"
        "        uiHandler.post(\n"
        "            uiTicker\n"
        "        )\n",
        1
    )

if "private fun analyzeLiveAutoViewFrame()" not in live:
    live_helper_anchor = "    private fun buildLiveUi() {\n"

    if live_helper_anchor not in live:
        raise SystemExit("V223 LIVE helper anchor missing")

    helpers = (
        PAYLOAD / "live_auto_view_helpers.txt"
    ).read_text(encoding="utf-8")

    live = live.replace(
        live_helper_anchor,
        helpers + live_helper_anchor,
        1
    )

live_destroy_anchor = (
    "    override fun onDestroy() {\n"
    "        uiHandler.removeCallbacksAndMessages(\n"
    "            null\n"
    "        )\n"
)

if "liveAutoViewLabeler.close()" not in live:
    if live_destroy_anchor not in live:
        raise SystemExit("V223 LIVE destroy anchor missing")

    close_block = (
        live_destroy_anchor +
        "\n"
        "        if (\n"
        "            ::liveAutoViewLabeler.isInitialized\n"
        "        ) {\n"
        "            try {\n"
        "                liveAutoViewLabeler.close()\n"
        "            } catch (_: Exception) {\n"
        "            }\n"
        "        }\n"
    )

    live = live.replace(
        live_destroy_anchor,
        close_block,
        1
    )

# Advance live build and explicitly show which camera created the saved clip.
live = live.replace(
    "V222",
    "V223"
)

old_live_reporter = (
    '"REPORTER • $reporterName   |   STORY • $storyId   |   develop.uganda • V223"'
)

new_live_reporter = (
    '"CAMERA • LIVE STUDIO   |   REPORTER • $reporterName   |   STORY • $storyId   |   develop.uganda • V223"'
)

if old_live_reporter in live:
    live = live.replace(
        old_live_reporter,
        new_live_reporter,
        1
    )

LIVE.write_text(
    live,
    encoding="utf-8"
)

# ------------------------------------------------------------
# HOME — explicitly reassure that no camera was removed
# ------------------------------------------------------------

home = HOME.read_text(encoding="utf-8")

top_old = '"SOCIAL MEDIA CAMERA • V222\\nRECORD → AUTO SM MASTER"'

if top_old not in home:
    raise SystemExit("V223 HOME top anchor missing")

home = home.replace(
    top_old,
    '"ALL CAMERAS RETAINED • V223\\nAUTO VIEW • CAMERA ID IN SAVED VIDEO"',
    1
)

home = home.replace(
    '"SHOT FINDER • PICK THE CAMERA BY WHAT YOU ARE FILMING"',
    '"SHOT FINDER • ALL CAMERAS ARE INDEPENDENT • PICK BY WHAT YOU ARE FILMING"',
    1
)

home_status_anchor = (
    "        page.addView(\n"
    "            compactStatus(\n"
    '                "CREATOR CAMERA ENGINE",\n'
)

if "AUTO VIEW • ON-DEVICE SCENE DESCRIPTION" not in home:
    if home_status_anchor not in home:
        raise SystemExit("V223 HOME auto-view status anchor missing")

    status = (
        PAYLOAD / "home_auto_view_status.txt"
    ).read_text(encoding="utf-8")

    home = home.replace(
        home_status_anchor,
        status + home_status_anchor,
        1
    )

old_nothing = (
    '"V204 CAPTURE ENGINE + V205→V222 FUNCTIONAL MODULES REMAIN IN THE SHARED CORE • '
    'V216 MAKES THEM DIRECT-LAUNCH INDEPENDENT CAMERAS"'
)

new_nothing = (
    '"V205 • V206 • V207 • V208 • V209 • V210 • V211 • V212 • V213 • V214 • V215 • '
    'V222 SOCIAL MEDIA CAMERA ALL REMAIN DIRECT-LAUNCH OPTIONS • V223 ADDS AUTO VIEW TO MAIN REPORT/LIVE"'
)

if old_nothing in home:
    home = home.replace(
        old_nothing,
        new_nothing,
        1
    )

HOME.write_text(
    home,
    encoding="utf-8"
)

gradle = re.sub(
    r"versionCode\s*=\s*\d+",
    "versionCode = 22302",
    gradle,
    count=1
)

gradle = re.sub(
    r'versionName\s*=\s*"[^"]+"',
    'versionName = "223.2-all-cameras-auto-view-fix2"',
    gradle,
    count=1
)

GRADLE.write_text(
    gradle,
    encoding="utf-8"
)

print("V223 FIX2 All Cameras + Auto View applied.")
