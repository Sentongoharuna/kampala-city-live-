develop.uganda V232 — LIVE GRADE MONITOR

GOAL
V232 makes the V231/V230 color system practical on the real camera screen. The
operator no longer has to leave the camera to understand a color adjustment.
The selected Uganda Scene look, master strength and five palette controls are
shown and adjusted over the live PreviewView.

LIVE CAMERA FEATURES
• Floating LIVE GRADE chip on FIELD REPORT and LIVE STUDIO.
• Tap the chip to open the camera-screen tuning drawer.
• Uganda Scene LUT names remain familiar and numbered, e.g. KAMPALA STREET 01,
  NAKASERO GOLD 01, CLOCK TOWER STEEL 01, KAMPALA CONCRETE 01 and KAMPALA NIGHT 02.
• Master LUT strength: 0–100%.
• Five independent palette colors per LUT: 0–200% each.
• Every slider movement updates the operator camera preview immediately.
• HOLD ORIGINAL is a press-and-hold bypass: hold to see the untouched preview,
  release to return to the live grade.
• RESET restores the current scene LUT's authored strength and all five colors
  to 100%.
• The full Color Studio remains available for advanced setup.

IMAGE PIPELINE PRINCIPLE
ORIGINAL CameraX MP4: NEVER REPLACED and never receives the monitor filter.
LIVE GRADE MONITOR: operator-only screen-space approximation for practical tuning.
COLOR_MASTER.mp4: final tuned 17^3 Media3 SingleColorLut render and real H.264/AAC re-encode.

TECHNICAL NOTE
The live preview is intentionally a fast ColorMatrix approximation so it can
respond while the user drags sliders. The final Color Master uses the complete
17^3 tuned LUT, so it remains the authoritative graded output. PreviewView is
set to COMPATIBLE implementation mode to make the operator color transform
visible on the actual camera feed without rewiring CameraX recording.

UPGRADE BASE
The V232 patch accepts either the current proven V230 source or a successful
V231 source. When applied to V230 it carries the complete V231 Uganda Scene
five-color tuning layer forward automatically.
