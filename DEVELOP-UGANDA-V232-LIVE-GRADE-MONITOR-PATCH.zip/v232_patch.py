from pathlib import Path
import re
import shutil

ROOT = Path("v172-source/app")
SRC = ROOT / "src/main/java/com/sentongoharuna/pulse"

REPORT = SRC / "DevelopUgandaCameraActivity.kt"
LIVE = SRC / "DevelopUgandaLiveActivity.kt"
HOME = SRC / "DevelopUgandaNewsroomActivity.kt"
PACKAGER = SRC / "DevelopUgandaStoryPackager.kt"
REVIEW = SRC / "DevelopUgandaInstantReviewDialog.kt"
BRAND = SRC / "DevelopUgandaBrandMetadataStore.kt"
GRADLE = ROOT / "build.gradle.kts"
PAYLOAD = Path(__file__).resolve().parent


def require(text: str, needle: str, label: str):
    if needle not in text:
        raise SystemExit(f"V232 base check failed: {label} missing: {needle}")


def replace_required(text: str, old: str, new: str, label: str, count: int = 1):
    if old not in text:
        raise SystemExit(f"V232 anchor missing: {label}: {old}")
    return text.replace(old, new, count)


def insert_after_set_content_view(text: str, block: str, label: str) -> str:
    if "DevelopUgandaLiveGradePanel.attach(" in text:
        return text

    pattern = re.compile(r"(?P<indent>^[ \t]*)setContentView\(root\)\s*$", re.MULTILINE)
    match = pattern.search(text)
    if not match:
        raise SystemExit(f"V232 anchor missing: {label} setContentView(root)")

    indent = match.group("indent")
    rendered = "\n" + "\n".join(indent + line if line else "" for line in block.splitlines())
    return text[:match.end()] + rendered + text[match.end():]


def upgrade_preview_call(text: str, scope_expression: str) -> str:
    # Upgrade the existing V230/V231 monitor refresh to use the tuned scope.
    pattern = re.compile(
        r"DevelopUgandaColorEngine\.applyPreviewMonitor\(\s*previewView,\s*value\s*\)",
        re.MULTILINE,
    )
    replacement = (
        "DevelopUgandaColorEngine.applyPreviewMonitor(\n"
        "                previewView,\n"
        "                value,\n"
        f"                {scope_expression}\n"
        "            )"
    )
    return pattern.sub(replacement, text, count=1)


# ---------------------------------------------------------------------------
# V232 can upgrade the current proven V230 base directly, or a successfully
# built V231 base. This avoids forcing the user to complete V231 first while
# still carrying all V231 five-color tuning into V232.
# ---------------------------------------------------------------------------
gradle = GRADLE.read_text(encoding="utf-8")

if "versionCode = 23100" in gradle and 'versionName = "231.0-uganda-scene-color-lab"' in gradle:
    base = 231
    base_name = '231.0-uganda-scene-color-lab'
elif "versionCode = 23000" in gradle and 'versionName = "230.0-cinema-color-engine-2"' in gradle:
    base = 230
    base_name = '230.0-cinema-color-engine-2'
else:
    raise SystemExit("V232 requires the proven V230 or V231 source base")

for path in [REPORT, LIVE, HOME, PACKAGER, REVIEW, BRAND]:
    if not path.exists():
        raise SystemExit(f"V232 required source missing: {path}")

engine_path = SRC / "DevelopUgandaColorEngine.kt"
studio_path = SRC / "DevelopUgandaColorStudioActivity.kt"
tuner_path = SRC / "DevelopUgandaColorTuner.kt"
panel_path = SRC / "DevelopUgandaLiveGradePanel.kt"

old_engine = engine_path.read_text(encoding="utf-8")
for needle in [
    "DU URBAN TEAL",
    "DU GOLDEN CITY",
    "DU STEEL + FIRE",
    "SingleColorLut.createFromCube",
    "COLOR_MASTER",
]:
    require(old_engine, needle, "existing color engine")

# Full V232 color layer includes the V231 five-color tuner plus the new
# camera-screen live grade controller.
for name in [
    "DevelopUgandaColorEngine.kt",
    "DevelopUgandaColorStudioActivity.kt",
    "DevelopUgandaColorTuner.kt",
    "DevelopUgandaLiveGradePanel.kt",
]:
    shutil.copyfile(PAYLOAD / name, SRC / name)

# ---------------------------------------------------------------------------
# REPORT camera: retain recording engine, upgrade labels, and attach the live
# grade panel to the real PreviewView. No recording output or CameraX bind
# function is replaced.
# ---------------------------------------------------------------------------
report = REPORT.read_text(encoding="utf-8")
require(report, "ACTION_COLOR_ENGINE", "REPORT color integration")
if not re.search(r"scheduleV(?:229|230|231)ColorMaster", report):
    raise SystemExit("V232 base check failed: REPORT color scheduling helper missing")

for old_version in ("V229", "V230", "V231"):
    report = report.replace(old_version, "V232")
report = upgrade_preview_call(report, "v229ColorScope()")
report = insert_after_set_content_view(
    report,
    """DevelopUgandaLiveGradePanel.attach(
    activity = this,
    root = root,
    previewView = previewView,
    scopeProvider = { v229ColorScope() },
    hintProvider = { v229ColorHint() }
)""",
    "REPORT",
)
REPORT.write_text(report, encoding="utf-8")

# LIVE camera: same real-time grade controls, independently scoped.
live = LIVE.read_text(encoding="utf-8")
require(live, "liveColorButton", "LIVE color integration")
if not re.search(r"scheduleV(?:229|230|231)LiveColorMaster", live):
    raise SystemExit("V232 base check failed: LIVE color scheduling helper missing")

for old_version in ("V229", "V230", "V231"):
    live = live.replace(old_version, "V232")
live = upgrade_preview_call(live, "v229LiveColorScope()")
live = insert_after_set_content_view(
    live,
    """DevelopUgandaLiveGradePanel.attach(
    activity = this,
    root = root,
    previewView = previewView,
    scopeProvider = { v229LiveColorScope() },
    hintProvider = { v229LiveColorHint() }
)""",
    "LIVE",
)
LIVE.write_text(live, encoding="utf-8")

# Home/newsroom visible module label.
home = HOME.read_text(encoding="utf-8")
home = home.replace("V230 • CINEMA COLOR ENGINE 2.0", "V232 • LIVE GRADE MONITOR")
home = home.replace("V231 • UGANDA SCENE COLOR LAB", "V232 • LIVE GRADE MONITOR")
for old_version in ("V229", "V230", "V231"):
    home = home.replace(old_version, "V232")
HOME.write_text(home, encoding="utf-8")

# Story package / instant review / brand metadata retain the architecture but
# identify the V232 grade system.
packager = PACKAGER.read_text(encoding="utf-8")
require(packager, "COLOR_MASTER.mp4", "Story Package color master")
require(packager, "COLOR_PROFILE.json", "Story Package color profile")
for old_version in ("V229", "V230", "V231"):
    packager = packager.replace(old_version, "V232")
packager = packager.replace("Cinema Color Engine 2.0", "Live Grade Monitor")
packager = packager.replace("Uganda Scene Color Lab", "Live Grade Monitor")
PACKAGER.write_text(packager, encoding="utf-8")

review = REVIEW.read_text(encoding="utf-8")
require(review, '"COLOR MASTER"', "Instant Review color master")
require(review, '"COLOR STUDIO"', "Instant Review color studio")
for old_version in ("V229", "V230", "V231"):
    review = review.replace(old_version, "V232")
REVIEW.write_text(review, encoding="utf-8")

brand = BRAND.read_text(encoding="utf-8")
for old_version in ("V229", "V230", "V231"):
    brand = brand.replace(old_version, "V232")
BRAND.write_text(brand, encoding="utf-8")

# App version.
gradle = replace_required(
    gradle,
    f"versionCode = {base}00",
    "versionCode = 23200",
    "versionCode",
)
gradle = replace_required(
    gradle,
    f'versionName = "{base_name}"',
    'versionName = "232.0-live-grade-monitor"',
    "versionName",
)
GRADLE.write_text(gradle, encoding="utf-8")

print(f"PASS: V232 Live Grade Monitor applied from V{base} base.")
print("PASS: V231 five-color Uganda Scene tuning included.")
print("PASS: REPORT + LIVE camera PreviewView now have practical live tuning controls.")
print("PASS: HOLD ORIGINAL compare bypass included.")
print("PASS: Original CameraX recording and tuned COLOR_MASTER architecture retained.")
