from pathlib import Path
import re
import shutil

MAIN = Path("v172-source")
IHV = Path("v226-ihv-source")
HERE = Path(__file__).resolve().parent

if not (MAIN / "app/build.gradle.kts").exists():
    raise SystemExit("Missing v172-source/app build. This IHV package needs the existing V226 source.")

if IHV.exists():
    shutil.rmtree(IHV)
shutil.copytree(MAIN, IHV)

APP = IHV / "app"
BASE = APP / "src/main/java/com/sentongoharuna/pulse"
REPORT = BASE / "DevelopUgandaCameraActivity.kt"
BRANDING = BASE / "DevelopUgandaVideoBranding.kt"
DRAWABLE = APP / "src/main/res/drawable-nodpi"
LOGO = DRAWABLE / "develop_uganda_video_logo.png"
GRADLE = APP / "build.gradle.kts"
MANIFEST = APP / "src/main/AndroidManifest.xml"

gradle = GRADLE.read_text(encoding="utf-8")
m = re.search(r'versionCode\s*=\s*(\d+)', gradle)
if not m:
    raise SystemExit("versionCode not found")
code = int(m.group(1))
if code not in (22602, 22603, 22604):
    raise SystemExit(f"V226 IHV expects the V226.2/V226.3 line. Found versionCode={code}")

# If the main source is still V226.2, reproduce the V226.3 branding only inside
# the IHV copy. The real v172-source main app is never modified.
report = REPORT.read_text(encoding="utf-8")
brand_call = 'DevelopUgandaVideoBranding.effect(this@DevelopUgandaCameraActivity)'
if brand_call not in report:
    fn_match = re.search(r'\b(?:private\s+)?fun\s+exportAutomaticSocialMaster\s*\(', report)
    if not fn_match:
        raise SystemExit("exportAutomaticSocialMaster was not found")
    brace_start = report.find("{", fn_match.start())
    depth = 0
    brace_end = None
    for i in range(brace_start, len(report)):
        ch = report[i]
        if ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                brace_end = i + 1
                break
    if brace_end is None:
        raise SystemExit("Could not isolate exportAutomaticSocialMaster")
    fn = report[fn_match.start():brace_end]
    bright = re.search(r'Brightness\s*\(\s*0\.0001f\s*\)', fn)
    if not bright:
        raise SystemExit("V222/V226 forced social re-encode anchor is missing")
    list_pos = fn.rfind("listOf(", 0, bright.start())
    if list_pos < 0:
        raise SystemExit("Could not identify Media3 video effects list")
    insert_at = list_pos + len("listOf(")
    fn = fn[:insert_at] + "\n                    " + brand_call + ",\n                    " + fn[insert_at:]
    report = report[:fn_match.start()] + fn + report[brace_end:]
    if "SM READY • LOGO" not in report:
        report = report.replace("SM READY", "SM READY • LOGO", 1)
    REPORT.write_text(report, encoding="utf-8")

DRAWABLE.mkdir(parents=True, exist_ok=True)
shutil.copy2(HERE / "develop_uganda_video_logo.png", LOGO)
shutil.copy2(HERE / "DevelopUgandaVideoBranding.kt", BRANDING)

# THE IMPORTANT PART:
# Different applicationId makes Android treat this as a second independent app,
# so it installs beside the main develop.uganda app instead of replacing it.
gradle = GRADLE.read_text(encoding="utf-8")
if re.search(r'applicationId\s*=\s*"[^"]+"', gradle):
    gradle = re.sub(
        r'applicationId\s*=\s*"[^"]+"',
        'applicationId = "com.sentongoharuna.pulse.ihv"',
        gradle,
        count=1
    )
else:
    raise SystemExit("applicationId not found in app/build.gradle.kts")

gradle = re.sub(r'versionCode\s*=\s*\d+', 'versionCode = 2260301', gradle, count=1)
gradle = re.sub(
    r'versionName\s*=\s*"[^"]+"',
    'versionName = "226.3-ihv-in-house-branded-social"',
    gradle,
    count=1
)
GRADLE.write_text(gradle, encoding="utf-8")

manifest = MANIFEST.read_text(encoding="utf-8")
if re.search(r'android:label\s*=\s*"[^"]+"', manifest):
    manifest = re.sub(
        r'android:label\s*=\s*"[^"]+"',
        'android:label="V226 IHV"',
        manifest,
        count=1
    )
else:
    manifest = manifest.replace("<application", '<application android:label="V226 IHV"', 1)
MANIFEST.write_text(manifest, encoding="utf-8")

print("PASS: V226 IHV source created.")
print("Main app remains: com.sentongoharuna.pulse")
print("IHV app id:      com.sentongoharuna.pulse.ihv")
print("Launcher name:   V226 IHV")
print("Source folder:   v226-ihv-source")
