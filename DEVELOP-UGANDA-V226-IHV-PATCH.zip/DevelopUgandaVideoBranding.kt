@file:OptIn(androidx.media3.common.util.UnstableApi::class)

package com.sentongoharuna.pulse

import android.content.Context
import android.graphics.BitmapFactory
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.StaticOverlaySettings

/**
 * V226.3 post-record branding for the automatic social master.
 *
 * The camera's original Gallery recording remains clean. This effect is only
 * injected into the Media3 social-export pipeline, producing a post-ready copy.
 */
object DevelopUgandaVideoBranding {
    fun effect(context: Context): OverlayEffect {
        val logo = BitmapFactory.decodeResource(
            context.resources,
            R.drawable.develop_uganda_video_logo
        ) ?: error("develop.uganda video logo resource could not be decoded")

        // Upper-left is deliberately chosen to avoid TikTok's right-side action rail
        // and the bottom caption / username / audio controls.
        val settings = StaticOverlaySettings.Builder()
            .setOverlayFrameAnchor(-1f, 1f)
            .setBackgroundFrameAnchor(-0.86f, 0.86f)
            .setScale(0.13f, 0.13f)
            .setAlphaScale(0.94f)
            .build()

        val overlay = BitmapOverlay.createStaticBitmapOverlay(logo, settings)
        return OverlayEffect(listOf(overlay))
    }
}
