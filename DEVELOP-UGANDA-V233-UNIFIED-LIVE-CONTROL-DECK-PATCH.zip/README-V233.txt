develop.uganda V233 — Unified Live Control Deck

Purpose
-------
V233 compiles the current V232 camera/color work into one finished operator experience.
It does not replace the original CameraX recording pipeline or the V232 17^3 LUT master.

What V233 changes
-----------------
• One dark glass button language across REPORT and LIVE camera controls.
• Button accents follow the active Uganda Scene LUT palette.
• REPORT keeps SCENE / LOOK / FORMAT / CAPTURE / COLOR plus LENS / RECORD / LIGHT visible.
• The dense advanced REPORT rows are moved into a collapsible LIVE TOOLS drawer.
• The actual existing Button objects are moved, so their existing listeners/functions are retained.
• V232 Live Grade remains on-camera and keeps HOLD ORIGINAL + individual palette tuning.
• Visible current build/output labels are promoted to V233.
• Existing Director/QC, telemetry, brand metadata, integrity, Photo Suite, Social Master,
  story packaging, and original-video safety are retained.

Build target
------------
versionCode 23300
versionName 233.0-unified-live-control-deck
