from pathlib import Path
import re
import shutil

ROOT = Path.cwd()
SRC = ROOT / "v172-source/app/src/main/java/com/sentongoharuna/pulse"
GRADLE = ROOT / "v172-source/app/build.gradle.kts"
PATCH_DIR = Path(__file__).resolve().parent


def require(path: Path):
    if not path.exists():
        raise SystemExit(f"V233 required file missing: {path}")


def write(path: Path, text: str):
    path.write_text(text, encoding="utf-8")
    print(f"V233 wrote {path}")


def replace_required(text: str, old: str, new: str, label: str) -> str:
    if old not in text:
        raise SystemExit(f"V233 anchor missing [{label}]: {old}")
    return text.replace(old, new)


def regex_insert_after(text: str, pattern: str, insertion: str, label: str) -> str:
    if insertion.strip() in text:
        return text
    match = re.search(pattern, text, flags=re.S)
    if not match:
        raise SystemExit(f"V233 anchor missing [{label}]")
    return text[: match.end()] + "\n" + insertion + text[match.end():]


for p in [SRC, GRADLE]:
    require(p)

camera_path = SRC / "DevelopUgandaCameraActivity.kt"
live_path = SRC / "DevelopUgandaLiveActivity.kt"
grade_panel_path = SRC / "DevelopUgandaLiveGradePanel.kt"
color_studio_path = SRC / "DevelopUgandaColorStudioActivity.kt"
newsroom_path = SRC / "DevelopUgandaNewsroomActivity.kt"
brand_path = SRC / "DevelopUgandaBrandMetadataStore.kt"
instant_path = SRC / "DevelopUgandaInstantReviewDialog.kt"
packager_path = SRC / "DevelopUgandaStoryPackager.kt"

for p in [
    camera_path,
    live_path,
    grade_panel_path,
    color_studio_path,
    newsroom_path,
    brand_path,
]:
    require(p)

# -----------------------------------------------------------------------------
# 1) Install V233 unified operator surface.
# -----------------------------------------------------------------------------
shutil.copy2(
    PATCH_DIR / "DevelopUgandaUnifiedControlDeck.kt",
    SRC / "DevelopUgandaUnifiedControlDeck.kt",
)

# -----------------------------------------------------------------------------
# 2) REPORT camera: retain V232 Live Grade, then layer V233 unified controls.
# -----------------------------------------------------------------------------
camera = camera_path.read_text(encoding="utf-8")

report_attach_pattern = r"DevelopUgandaLiveGradePanel\.attach\(\s*activity\s*=\s*this,\s*root\s*=\s*root,\s*previewView\s*=\s*previewView,\s*scopeProvider\s*=\s*\{\s*v229ColorScope\(\)\s*\},\s*hintProvider\s*=\s*\{\s*v229ColorHint\(\)\s*\}\s*\)"
report_insert = """        DevelopUgandaUnifiedControlDeck.attach(\n            activity = this,\n            root = root,\n            scopeProvider = { v229ColorScope() },\n            hintProvider = { v229ColorHint() },\n            mode = DevelopUgandaUnifiedControlDeck.Mode.REPORT\n        )"""
camera = regex_insert_after(
    camera,
    report_attach_pattern,
    report_insert,
    "REPORT LiveGrade attach",
)

# Promote current visible/output version to V233. Private helper names can also
# move from V232 to V233 safely because they are file-local and all references
# are changed together.
camera = camera.replace("V232", "V233")

# Remove the legacy visible V228/V227 build identifiers while retaining the
# underlying modules and their internal method names.
camera = re.sub(
    r'DevelopUgandaBrandMetadataStore\.previewTitle\(\s*this,\s*"V228"\s*\)',
    'DevelopUgandaBrandMetadataStore.previewTitle(\n                    this,\n                    "V233"\n                )',
    camera,
)
camera = camera.replace(
    'baseName = "DEVELOP_UGANDA_V228_',
    'baseName = "DEVELOP_UGANDA_V233_',
)
camera = camera.replace(
    ' • ${autoDirectorStateText()} • V227"',
    ' • ${autoDirectorStateText()} • V233"',
)

write(camera_path, camera)

# -----------------------------------------------------------------------------
# 3) LIVE camera: retain V232 grade monitor + apply the same V233 glass language.
#    LIVE keeps its own existing control geometry; REPORT gets the compact drawer.
# -----------------------------------------------------------------------------
live = live_path.read_text(encoding="utf-8")
live_attach_pattern = r"DevelopUgandaLiveGradePanel\.attach\(\s*activity\s*=\s*this,\s*root\s*=\s*root,\s*previewView\s*=\s*previewView,\s*scopeProvider\s*=\s*\{\s*v229LiveColorScope\(\)\s*\},\s*hintProvider\s*=\s*\{\s*v229LiveColorHint\(\)\s*\}\s*\)"
live_insert = """        DevelopUgandaUnifiedControlDeck.attach(\n            activity = this,\n            root = root,\n            scopeProvider = { v229LiveColorScope() },\n            hintProvider = { v229LiveColorHint() },\n            mode = DevelopUgandaUnifiedControlDeck.Mode.LIVE\n        )"""
live = regex_insert_after(
    live,
    live_attach_pattern,
    live_insert,
    "LIVE LiveGrade attach",
)
live = live.replace("V232", "V233")

# These V228 strings were still visible on the LIVE saved HUD and filenames.
live = live.replace('"V228"', '"V233"')
live = live.replace("DEVELOP_UGANDA_V228_LIVE_", "DEVELOP_UGANDA_V233_LIVE_")
write(live_path, live)

# -----------------------------------------------------------------------------
# 4) Carry the V232 live grade/color lab into V233 instead of creating another
#    disconnected page. Only version language changes; color math is untouched.
# -----------------------------------------------------------------------------
grade_panel = grade_panel_path.read_text(encoding="utf-8").replace("V232", "V233")
write(grade_panel_path, grade_panel)

color_studio = color_studio_path.read_text(encoding="utf-8").replace("V232", "V233")
write(color_studio_path, color_studio)

brand = brand_path.read_text(encoding="utf-8").replace(
    "Recorded with develop.uganda • V232",
    "Recorded with develop.uganda • V233",
)
write(brand_path, brand)

# -----------------------------------------------------------------------------
# 5) Newsroom top-level identity: V233 is one compiled camera generation.
#    Historical cards below remain as provenance for retained modules.
# -----------------------------------------------------------------------------
newsroom = newsroom_path.read_text(encoding="utf-8")
newsroom = newsroom.replace("V232", "V233")
old_top = "PROFESSIONAL COLOR ENGINE • V233\\nV228 BRAND/METADATA + V227 DIRECTOR/QC RETAINED"
new_top = "UNIFIED LIVE CONTROL DECK • V233\\nCOLOR • DIRECTOR • BRAND • QC • ALL RETAINED"
if old_top in newsroom:
    newsroom = newsroom.replace(old_top, new_top)
else:
    # Fallback if formatting changed, but still require the current V233 header.
    if "PROFESSIONAL COLOR ENGINE • V233" in newsroom:
        newsroom = newsroom.replace(
            "PROFESSIONAL COLOR ENGINE • V233",
            "UNIFIED LIVE CONTROL DECK • V233",
        )

# Make the current-generation card describe the compiled V233 experience.
newsroom = newsroom.replace(
    '"V233 • LIVE GRADE MONITOR",',
    '"V233 • UNIFIED LIVE CONTROL DECK",',
)
newsroom = newsroom.replace(
    '"V233 • PROFESSIONAL COLOR",',
    '"V233 • COLOR + LIVE CONTROL",',
)
write(newsroom_path, newsroom)

# Optional current-version wording in retained package/review modules.
for optional in [instant_path, packager_path]:
    if optional.exists():
        text = optional.read_text(encoding="utf-8")
        if "V232" in text:
            text = text.replace("V232", "V233")
            write(optional, text)

# -----------------------------------------------------------------------------
# 6) App version.
# -----------------------------------------------------------------------------
gradle = GRADLE.read_text(encoding="utf-8")
gradle = replace_required(
    gradle,
    "versionCode = 23200",
    "versionCode = 23300",
    "versionCode",
)
gradle = replace_required(
    gradle,
    'versionName = "232.0-live-grade-monitor"',
    'versionName = "233.0-unified-live-control-deck"',
    "versionName",
)
write(GRADLE, gradle)

# -----------------------------------------------------------------------------
# 7) Post-patch safety checks before Gradle even starts.
# -----------------------------------------------------------------------------
checks = {
    "new-deck": (SRC / "DevelopUgandaUnifiedControlDeck.kt", "UNIFIED LIVE CONTROL DECK"),
    "report-attach": (camera_path, "DevelopUgandaUnifiedControlDeck.Mode.REPORT"),
    "live-attach": (live_path, "DevelopUgandaUnifiedControlDeck.Mode.LIVE"),
    "report-version": (camera_path, '"V233"'),
    "report-output-name": (camera_path, "DEVELOP_UGANDA_V233_"),
    "live-output-name": (live_path, "DEVELOP_UGANDA_V233_LIVE_"),
    "studio-version": (color_studio_path, "develop.uganda • V233"),
    "brand-version": (brand_path, "Recorded with develop.uganda • V233"),
    "newsroom-version": (newsroom_path, "UNIFIED LIVE CONTROL DECK • V233"),
}

failed = []
for label, (path, needle) in checks.items():
    source = path.read_text(encoding="utf-8")
    if needle in source:
        print(f"PASS [{label}]")
    else:
        print(f"FAIL [{label}] missing {needle}")
        failed.append(label)

if failed:
    raise SystemExit("V233 patch verification failed: " + ", ".join(failed))

print("PASS: develop.uganda V233 Unified Live Control Deck patch applied.")
