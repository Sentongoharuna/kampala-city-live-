#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}"
bash "$P/scripts/verify-fix2.sh" "$P"
grep -F 'AircraftIntelligence.dashboard(mapSignals' "$P/app/src/main/java/com/sentongoharuna/worldsituationroom/MainActivity.java" >/dev/null
grep -F 'STALE' "$P/app/src/main/java/com/sentongoharuna/worldsituationroom/AircraftIntelligence.java" >/dev/null
echo '4.21 aircraft and frozen globe PASS'
