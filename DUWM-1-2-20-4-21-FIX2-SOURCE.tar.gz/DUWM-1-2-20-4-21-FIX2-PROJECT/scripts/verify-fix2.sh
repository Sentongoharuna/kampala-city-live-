#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}"
test -f "$P/settings.gradle.kts"
test -f "$P/app/build.gradle.kts"
echo "3309dfc06fe8608653c77e54d19391428f686e42d243f0031c5da21e9b33adcb  $P/app/src/main/java/com/sentongoharuna/worldsituationroom/SatelliteMapView.java" | sha256sum -c -
echo "FIX2 original globe integrity PASS"
