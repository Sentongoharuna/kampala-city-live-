# DUWM 4.21 — Live Aircraft Intelligence

Preserves the byte-identical 4.20 FIX2 globe. Adds immutable aircraft snapshots, source and timestamp, speed/heading/location fields and recent/aging/stale classification. An initial operations dashboard summary is computed without blocking rendering or replacing first-page navigation. No fabricated positions or flight trails. The first-page visual redesign remains a separate follow-up pending runtime layout testing.
