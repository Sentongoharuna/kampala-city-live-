package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** Immutable, source-grounded air traffic snapshot. No invented aircraft positions. */
public final class AircraftIntelligence {
 private AircraftIntelligence() {}
 public static final class Flight {
  public final String id,title,source,ageLabel; public final double latitude,longitude,heading,speedMetersPerSecond;
  public final long timestampMs;
  Flight(Signal s,long now){id=s.canonicalId;title=s.title;source=s.source;latitude=s.latitude;longitude=s.longitude;heading=s.heading;speedMetersPerSecond=s.speedMetersPerSecond;timestampMs=s.timestampMs;
   long age=s.timestampMs<=0?Long.MAX_VALUE:Math.max(0L,now-s.timestampMs);
   ageLabel=age<=120000L?"RECENT":age<=900000L?"AGING":"STALE";
  }
 }
 public static List<Flight> snapshot(List<Signal> signals,long now){
  if(signals==null)return Collections.emptyList();
  ArrayList<Flight> out=new ArrayList<>();
  for(Signal s:signals){if(s==null||s.layer!=Signal.Layer.FLIGHTS||!s.hasLocation())continue;out.add(new Flight(s,now));}
  Collections.sort(out,new Comparator<Flight>(){public int compare(Flight a,Flight b){return Long.compare(b.timestampMs,a.timestampMs);}});
  return Collections.unmodifiableList(out);
 }
 public static String dashboard(List<Signal> signals,long now){
  List<Flight> flights=snapshot(signals,now);int recent=0,aging=0;
  for(Flight f:flights){if("RECENT".equals(f.ageLabel))recent++;else if("AGING".equals(f.ageLabel))aging++;}
  return "AIRCRAFT "+flights.size()+"  |  RECENT "+recent+"  |  AGING "+aging+"  |  STALE "+(flights.size()-recent-aging);
 }
}
