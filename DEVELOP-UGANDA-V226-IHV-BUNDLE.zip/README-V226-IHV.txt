V226 IHV — IN HOUSE VERSION

Purpose
-------
Install the V226 in-house build beside the normal develop.uganda app without uninstalling either one.

Main app
  Launcher: develop.uganda
  Android applicationId: com.sentongoharuna.pulse

In-house app
  Launcher: V226 IHV
  Android applicationId: com.sentongoharuna.pulse.ihv
  Version: 226.3-ihv-in-house-branded-social

Important
---------
Changing only the visible app name is NOT enough. Android decides whether an APK replaces an installed app by applicationId/package identity. V226 IHV therefore uses a new applicationId.

The workflow copies v172-source into v226-ihv-source on the GitHub Actions runner, changes only the copy, builds it, and uploads the APK. It does not overwrite or commit changes into the main v172-source app.

The branded social export remains included: the original Gallery recording remains clean and the social copy receives the DEVELOP.UGANDA logo.
