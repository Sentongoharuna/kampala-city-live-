from pathlib import Path
import re
import shutil

ROOT = Path("v172-source/app")
SRC = ROOT / "src/main/java/com/sentongoharuna/pulse"
PACKAGER = SRC / "DevelopUgandaStoryPackager.kt"
PACKAGES = SRC / "DevelopUgandaStoryPackagesActivity.kt"
TRANSCRIPT = SRC / "DevelopUgandaTranscriptEngine.kt"
MANIFEST = ROOT / "src/main/AndroidManifest.xml"
GRADLE = ROOT / "build.gradle.kts"
PAYLOAD = Path(__file__).resolve().parent

def replace_once(text, old, new, label):
    if old not in text:
        raise SystemExit("V226 FIX2 anchor missing: " + label)
    return text.replace(old, new, 1)

gradle = GRADLE.read_text(encoding="utf-8")

if 'versionCode = 22601' not in gradle:
    raise SystemExit("V226 FIX2 expects V226.1 FIX1 versionCode 22601")

if 'versionName = "226.1-auto-story-package-fix1"' not in gradle:
    raise SystemExit("V226 FIX2 expects V226.1 FIX1 base")

shutil.copyfile(
    PAYLOAD / "DevelopUgandaMediaInbox.kt",
    SRC / "DevelopUgandaMediaInbox.kt"
)

shutil.copyfile(
    PAYLOAD / "DevelopUgandaStoryPlayerActivity.kt",
    SRC / "DevelopUgandaStoryPlayerActivity.kt"
)

packager = PACKAGER.read_text(encoding="utf-8")

registry_anchor = '''    data class RegistryEntry(
        val packageId: String,
        val path: String,
        val title: String,
        val camera: String,
        val createdUtc: String,
        val state: String
    )

'''

if "data class PlayableVideo(" not in packager:
    packager = replace_once(
        packager,
        registry_anchor,
        registry_anchor + '''    data class PlayableVideo(
        val uri: Uri,
        val label: String
    )

''',
        "PlayableVideo data class"
    )

read_text_anchor = '''    fun readText(context: Context, uri: Uri): String? {
        return try {
            context.contentResolver.openInputStream(uri)
                ?.bufferedReader()
                ?.use { it.readText() }
        } catch (_: Exception) {
            null
        }
    }

'''

if "fun resolvePlayableVideo(" not in packager:
    resolver = '''    fun resolvePlayableVideo(
        context: Context,
        packageId: String
    ): PlayableVideo? {
        val safeId = safeSegment(packageId)

        val source = sourceUriFromManifest(
            context,
            safeId
        )

        if (
            source != null &&
            uriIsReadable(
                context,
                source
            )
        ) {
            return PlayableVideo(
                uri = source,
                label = "ORIGINAL GALLERY VIDEO"
            )
        }

        val packageCopy = findPackageFile(
            context,
            safeId,
            "ORIGINAL_VIDEO.mp4"
        )

        if (
            packageCopy != null &&
            uriIsReadable(
                context,
                packageCopy
            )
        ) {
            return PlayableVideo(
                uri = packageCopy,
                label = "STORY PACKAGE COPY"
            )
        }

        return null
    }

    private fun uriIsReadable(
        context: Context,
        uri: Uri
    ): Boolean {
        return try {
            if (
                uri.scheme == "file"
            ) {
                val path = uri.path ?: return false
                val file = File(path)
                file.exists() && file.length() > 0L
            } else {
                context.contentResolver
                    .openFileDescriptor(
                        uri,
                        "r"
                    )
                    ?.use {
                        true
                    }
                    ?: false
            }
        } catch (_: Exception) {
            false
        }
    }

'''
    packager = replace_once(
        packager,
        read_text_anchor,
        read_text_anchor + resolver,
        "playable resolver"
    )

PACKAGER.write_text(
    packager,
    encoding="utf-8"
)

packages = PACKAGES.read_text(encoding="utf-8")

packages = packages.replace(
    '"REFRESH PACKAGES"',
    '"SCAN RECORDINGS + REFRESH"',
    1
)

refresh_anchor = '''    private fun refreshPackages() {
        host.removeAllViews()

        val packages = DevelopUgandaStoryPackager.listRegistry(this)
'''

inbox_block = '''    private fun refreshPackages() {
        host.removeAllViews()

        val inbox =
            DevelopUgandaMediaInbox.findUnpackaged(
                this,
                24
            )

        if (
            inbox.isNotEmpty()
        ) {
            host.addView(
                cardText(
                    "NEW RECORDINGS INBOX • ${inbox.size}",
                    "These are develop.uganda videos found directly in Android MediaStore that do not yet have a V226 Story Package. PLAY and SHARE work immediately. BUILD PACKAGE creates the newsroom package."
                )
            )

            inbox.take(
                12
            ).forEach {
                    video ->
                val intakeCard =
                    LinearLayout(
                        this
                    ).apply {
                        orientation =
                            LinearLayout.VERTICAL

                        setPadding(
                            dp(10),
                            dp(10),
                            dp(10),
                            dp(10)
                        )

                        background =
                            rounded(
                                panel,
                                green
                            )
                    }

                intakeCard.addView(
                    label(
                        video.displayName,
                        10f,
                        white,
                        true
                    )
                )

                intakeCard.addView(
                    label(
                        "MEDIASTORE RECORDING • ${formatDuration(video.durationMs)} • ${formatBytes(video.sizeBytes)}\\nNOT PACKAGED YET",
                        7.5f,
                        muted,
                        false
                    ).apply {
                        setPadding(
                            0,
                            dp(3),
                            0,
                            dp(6)
                        )
                    }
                )

                val mediaRow =
                    LinearLayout(
                        this
                    ).apply {
                        orientation =
                            LinearLayout.HORIZONTAL
                    }

                mediaRow.addView(
                    smallButton(
                        "PLAY",
                        green
                    ) {
                        playDirect(
                            video.uri,
                            video.displayName
                        )
                    },
                    weight()
                )

                mediaRow.addView(
                    smallButton(
                        "SHARE",
                        cyan
                    ) {
                        shareDirect(
                            video.uri
                        )
                    },
                    weight().apply {
                        marginStart =
                            dp(5)
                    }
                )

                intakeCard.addView(
                    mediaRow
                )

                val buildPackage =
                    actionButton(
                        "BUILD STORY PACKAGE",
                        gold
                    ) {
                        DevelopUgandaMediaInbox.packageVideo(
                            this,
                            video
                        )

                        toast(
                            "Building Story Package • original video stays safe"
                        )

                        host.postDelayed(
                            {
                                refreshPackages()
                            },
                            1800L
                        )
                    }

                intakeCard.addView(
                    buildPackage,
                    LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        dp(44)
                    ).apply {
                        topMargin =
                            dp(5)
                    }
                )

                host.addView(
                    intakeCard,
                    LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    ).apply {
                        topMargin =
                            dp(7)
                    }
                )
            }

            host.addView(
                label(
                    "PACKAGED STORIES",
                    10f,
                    gold,
                    true
                ).apply {
                    setPadding(
                        0,
                        dp(14),
                        0,
                        dp(5)
                    )
                }
            )
        }

        val packages = DevelopUgandaStoryPackager.listRegistry(this)
'''

packages = replace_once(
    packages,
    refresh_anchor,
    inbox_block,
    "MediaStore inbox"
)

empty_old = '''        if (packages.isEmpty()) {
            host.addView(
                cardText(
                    "NO STORY PACKAGES YET",
                    "Record a successful REPORT or LIVE clip. V226 will create a package automatically after CameraX Finalize."
                )
            )
            return
        }
'''

empty_new = '''        if (
            packages.isEmpty() &&
            inbox.isEmpty()
        ) {
            host.addView(
                cardText(
                    "NO DEVELOP.UGANDA VIDEOS FOUND",
                    "Record with a develop.uganda camera. New successful recordings package automatically after CameraX Finalize. This screen also scans MediaStore so older or missed develop.uganda recordings can be recovered into the newsroom."
                )
            )
            return
        }
'''

packages = replace_once(
    packages,
    empty_old,
    empty_new,
    "empty state"
)

packages = replace_once(
    packages,
    '''            row1.addView(
                smallButton("PLAY ORIGINAL", green) {
                    openPackageFile(entry.packageId, "ORIGINAL_VIDEO.mp4", "video/mp4")
                },
                weight()
            )
''',
    '''            row1.addView(
                smallButton("PLAY ORIGINAL", green) {
                    playOriginal(
                        entry.packageId
                    )
                },
                weight()
            )
''',
    "package play"
)

packages = replace_once(
    packages,
    '''            row1.addView(
                smallButton("SHARE ORIGINAL", cyan) {
                    sharePackageFile(entry.packageId, "ORIGINAL_VIDEO.mp4", "video/mp4")
                },
                weight().apply { marginStart = dp(5) }
            )
''',
    '''            row1.addView(
                smallButton("SHARE ORIGINAL", cyan) {
                    shareOriginal(
                        entry.packageId
                    )
                },
                weight().apply { marginStart = dp(5) }
            )
''',
    "package share"
)

open_anchor = '''    private fun openPackageFile(
        packageId: String,
        displayName: String,
        mime: String
    ) {
'''

helpers = '''    private fun playOriginal(
        packageId: String
    ) {
        val resolved =
            DevelopUgandaStoryPackager.resolvePlayableVideo(
                this,
                packageId
            )

        if (
            resolved == null
        ) {
            toast(
                "Original video is not readable from Gallery or the Story Package"
            )
            return
        }

        startActivity(
            Intent(
                this,
                DevelopUgandaStoryPlayerActivity::class.java
            ).apply {
                putExtra(
                    DevelopUgandaStoryPlayerActivity.EXTRA_PACKAGE_ID,
                    packageId
                )
            }
        )
    }

    private fun playDirect(
        uri: Uri,
        label: String
    ) {
        startActivity(
            Intent(
                this,
                DevelopUgandaStoryPlayerActivity::class.java
            ).apply {
                putExtra(
                    DevelopUgandaStoryPlayerActivity.EXTRA_DIRECT_URI,
                    uri.toString()
                )

                putExtra(
                    DevelopUgandaStoryPlayerActivity.EXTRA_DIRECT_LABEL,
                    label
                )
            }
        )
    }

    private fun shareOriginal(
        packageId: String
    ) {
        val resolved =
            DevelopUgandaStoryPackager.resolvePlayableVideo(
                this,
                packageId
            )

        if (
            resolved == null
        ) {
            toast(
                "Original video is not readable"
            )
            return
        }

        shareDirect(
            resolved.uri
        )
    }

    private fun shareDirect(
        uri: Uri
    ) {
        try {
            startActivity(
                Intent.createChooser(
                    Intent(
                        Intent.ACTION_SEND
                    ).apply {
                        type =
                            "video/mp4"

                        putExtra(
                            Intent.EXTRA_STREAM,
                            uri
                        )

                        addFlags(
                            Intent.FLAG_GRANT_READ_URI_PERMISSION
                        )
                    },
                    "Share video"
                )
            )
        } catch (_: Exception) {
            toast(
                "Share is not available"
            )
        }
    }

    private fun formatDuration(
        durationMs: Long?
    ): String {
        if (
            durationMs == null ||
            durationMs <= 0L
        ) {
            return "DURATION --"
        }

        val totalSeconds =
            durationMs / 1000L

        val minutes =
            totalSeconds / 60L

        val seconds =
            totalSeconds % 60L

        return String.format(
            java.util.Locale.US,
            "%02d:%02d",
            minutes,
            seconds
        )
    }

    private fun formatBytes(
        bytes: Long?
    ): String {
        if (
            bytes == null ||
            bytes <= 0L
        ) {
            return "SIZE --"
        }

        val mb =
            bytes.toDouble() /
                (
                    1024.0 *
                        1024.0
                    )

        return if (
            mb >= 1024.0
        ) {
            String.format(
                java.util.Locale.US,
                "%.1f GB",
                mb / 1024.0
            )
        } else {
            String.format(
                java.util.Locale.US,
                "%.0f MB",
                mb
            )
        }
    }

'''

if "private fun playOriginal(" not in packages:
    packages = replace_once(
        packages,
        open_anchor,
        helpers + open_anchor,
        "play/share helpers"
    )

packages = packages.replace(
    'toast("Transcript request started • review the draft when ready")',
    'toast("Transcript request started • clear speech is required")',
    1
)

PACKAGES.write_text(
    packages,
    encoding="utf-8"
)

transcript = TRANSCRIPT.read_text(encoding="utf-8")

transcript = replace_once(
    transcript,
    '''                override fun onError(error: Int) {
                    finish(
                        "FAILED",
                        "On-device recognizer error ${speechErrorLabel(error)}. Original video is unchanged."
                    )
                }
''',
    '''                override fun onError(error: Int) {
                    if (
                        error == SpeechRecognizer.ERROR_NO_MATCH ||
                        error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT
                    ) {
                        finish(
                            "NO SPEECH DETECTED",
                            "The phone's on-device recognizer did not confidently detect spoken words in this saved video. Quiet footage, construction noise, distant speech, music, or unsupported language/accent can produce this result. Original video is unchanged."
                        )
                        return
                    }

                    finish(
                        "FAILED",
                        "On-device recognizer error ${speechErrorLabel(error)}. Original video is unchanged."
                    )
                }
''',
    "transcript no-match"
)

TRANSCRIPT.write_text(
    transcript,
    encoding="utf-8"
)

manifest = MANIFEST.read_text(encoding="utf-8")

story_activity = '''        <activity
            android:name=".DevelopUgandaStoryPackagesActivity"
            android:screenOrientation="portrait"
            android:exported="false"/>

'''

if ".DevelopUgandaStoryPlayerActivity" not in manifest:
    manifest = replace_once(
        manifest,
        story_activity,
        story_activity + '''        <activity
            android:name=".DevelopUgandaStoryPlayerActivity"
            android:screenOrientation="portrait"
            android:exported="false"/>

''',
        "story player manifest"
    )

MANIFEST.write_text(
    manifest,
    encoding="utf-8"
)

gradle = re.sub(
    r"versionCode\s*=\s*\d+",
    "versionCode = 22602",
    gradle,
    count=1
)

gradle = re.sub(
    r'versionName\s*=\s*"[^"]+"',
    'versionName = "226.2-newsroom-media-intake"',
    gradle,
    count=1
)

GRADLE.write_text(
    gradle,
    encoding="utf-8"
)

print("V226 FIX2 Newsroom Media Intake applied.")
