from pathlib import Path
import re

root = Path("v172-source/app")
src = root / "src/main/java/com/sentongoharuna/pulse"
report_path = src / "DevelopUgandaCameraActivity.kt"
live_path = src / "DevelopUgandaLiveActivity.kt"
home_path = src / "DevelopUgandaNewsroomActivity.kt"
gradle_path = root / "build.gradle.kts"

def must_replace(text, old, new, label, count=1):
    if old not in text:
        raise SystemExit(f"V217 patch anchor missing: {label}")
    return text.replace(old, new, count)

report = report_path.read_text(encoding="utf-8")

# Full-screen window support.
if "import androidx.core.view.WindowCompat\n" not in report:
    report = must_replace(
        report,
        "import androidx.core.content.ContextCompat\n",
        "import androidx.core.content.ContextCompat\n"
        "import androidx.core.view.WindowCompat\n"
        "import androidx.core.view.WindowInsetsCompat\n"
        "import androidx.core.view.WindowInsetsControllerCompat\n",
        "full-screen imports"
    )

report = must_replace(
    report,
    '''            // V181: show the full 9:16 recording canvas in the live camera.\n            // FILL_CENTER was cropping the left/right sides of the preview,\n            // even though the exported video was correct. FIT_START keeps the\n            // entire recorded frame visible and places any spare screen space\n            // below it, where the operator controls already live.\n            scaleType = PreviewView.ScaleType.FIT_CENTER\n''',
    '''            // V217: full-frame operator camera.\n            // The camera image fills the phone behind all controls.\n            // Gallery output remains the authoritative CameraX recording.\n            scaleType = PreviewView.ScaleType.FILL_CENTER\n''',
    "full-frame preview"
)

report = must_replace(
    report,
    '''    private fun buildUi() {\n''',
    '''    private fun enforceImmersiveCameraWindow() {\n        WindowCompat.setDecorFitsSystemWindows(\n            window,\n            false\n        )\n\n        WindowInsetsControllerCompat(\n            window,\n            window.decorView\n        ).apply {\n            hide(\n                WindowInsetsCompat.Type.systemBars()\n            )\n\n            systemBarsBehavior =\n                WindowInsetsControllerCompat\n                    .BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE\n        }\n    }\n\n    override fun onWindowFocusChanged(\n        hasFocus: Boolean\n    ) {\n        super.onWindowFocusChanged(\n            hasFocus\n        )\n\n        if (hasFocus) {\n            enforceImmersiveCameraWindow()\n        }\n    }\n\n    private fun buildUi() {\n''',
    "immersive helper"
)

report = must_replace(
    report,
    '''        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)\n\n        buildUi()\n''',
    '''        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)\n        enforceImmersiveCameraWindow()\n\n        buildUi()\n''',
    "immersive onCreate"
)

# Remove HALF behavior: VIEW always means full screen.
pattern = re.compile(
    r'''    private fun togglePreviewMode\(\) \{.*?\n    \}\n\n    private fun showReportDetailedSettings''',
    re.S
)
replacement = r'''    private fun enforceFullFramePreview() {
        halfPreviewMode =
  false

        previewView.layoutParams =
  FrameLayout.LayoutParams(
      ViewGroup.LayoutParams.MATCH_PARENT,
      ViewGroup.LayoutParams.MATCH_PARENT
  ).apply {
      gravity =
          Gravity.TOP
  }

        previewView.scaleType =
  PreviewView.ScaleType.FILL_CENTER

        guidesView.layoutParams =
  FrameLayout.LayoutParams(
      ViewGroup.LayoutParams.MATCH_PARENT,
      ViewGroup.LayoutParams.MATCH_PARENT
  ).apply {
      gravity =
          Gravity.TOP
  }

        if (::viewModeButton.isInitialized) {
  viewModeButton.text =
      "VIEW\nFULL SCREEN"
        }

        if (::previewNarrationPanel.isInitialized) {
  val hudParams =
      previewNarrationPanel.layoutParams as
          FrameLayout.LayoutParams

  hudParams.topMargin =
      dp(44)

  previewNarrationPanel.layoutParams =
      hudParams

  previewBrandView.textSize =
      13.8f
        }
    }

    private fun togglePreviewMode() {
        enforceFullFramePreview()
        enforceImmersiveCameraWindow()

        toast(
  "Full-screen camera view"
        )
    }

    private fun showReportDetailedSettings'''
report, n = pattern.subn(lambda _match: replacement, report, count=1)
if n != 1:
    raise SystemExit("V217 patch anchor missing: togglePreviewMode")

report = report.replace(
    '"VIEW ▾\\nFULL"',
    '"VIEW\\nFULL SCREEN"',
    1
)

report = must_replace(
    report,
    '''                is VideoRecordEvent.Start -> {\n                    recStarted = System.currentTimeMillis()\n''',
    '''                is VideoRecordEvent.Start -> {\n                    enforceFullFramePreview()\n                    enforceImmersiveCameraWindow()\n\n                    recStarted = System.currentTimeMillis()\n''',
    "recording-start full screen"
)

# Saved-video telemetry becomes wider/readable.
report = must_replace(
    report,
    '''        val safeLeft =\n            finalWidth * 0.045f\n\n        val safeTop =\n            finalHeight * 0.115f\n\n        val maxWidth =\n            finalWidth * 0.39f\n\n        var y = safeTop\n''',
    '''        val safeLeft =\n            finalWidth * 0.050f\n\n        val safeTop =\n            finalHeight * 0.100f\n\n        val maxWidth =\n            finalWidth * 0.56f\n\n        var y = safeTop\n\n        val railStartY =\n            y - (14f * u)\n\n        val telemetryPanel =\n            Paint(\n                Paint.ANTI_ALIAS_FLAG\n            ).apply {\n                color =\n                    0x30000000\n                style =\n                    Paint.Style.FILL\n            }\n\n        c.drawRoundRect(\n            safeLeft - (14f * u),\n            safeTop - (26f * u),\n            safeLeft + maxWidth + (14f * u),\n            safeTop + (344f * u),\n            16f * u,\n            16f * u,\n            telemetryPanel\n        )\n''',
    "saved HUD geometry"
)

report = must_replace(
    report,
    '''            strokeWidth =\n                4.0f * u\n        }\n\n        c.drawLine(\n            safeLeft - (8f * u),\n            y - (8f * u),\n            safeLeft - (8f * u),\n            finalHeight * 0.67f,\n            rail\n        )\n\n        text.color =\n''',
    '''            strokeWidth =\n                2.3f * u\n        }\n\n        text.color =\n''',
    "remove long saved rail"
)

report = must_replace(
    report,
    '''        text.textSize =\n            42f * u\n''',
    '''        text.textSize =\n            34f * u\n''',
    "cleaner saved brand"
)

report = report.replace(
    '"${sceneTag()} • V216"',
    '"${sceneTag()} • V217"',
    1
)

report = must_replace(
    report,
    '''        drawFitText(\n            c,\n            "$recState   |   TC ${tc()}   |   V216   |   CAMERA ${cameraExperienceShortLabel()}   |   THERM ${thermalStateLabel()}",\n            safeLeft,\n            y,\n            maxWidth,\n            text,\n            15.2f * u\n        )\n\n        y += 19f * u\n        text.color =\n            reportModeAccentColor()\n        text.textSize =\n            15.2f * u\n\n        drawFitText(\n            c,\n            "MODE • ${qualityModes[qualityIndex]}   |   ${reportModePurposeLabel()}   |   SCENE • ${sceneModes[sceneIndex]}   |   LOOK • ${lookModes[lookIndex]}   |   ${autoDirectorStateText()}   |   CAMERA • ${cameraExperienceShortLabel()}",\n            safeLeft,\n            y,\n            maxWidth,\n            text,\n            11.7f * u\n        )\n\n        y += 20f * u\n''',
    '''        drawFitText(\n            c,\n            "$recState   •   TC ${tc()}   •   V217   •   THERM ${thermalStateLabel()}",\n            safeLeft,\n            y,\n            maxWidth,\n            text,\n            15.2f * u\n        )\n\n        y += 18f * u\n        text.color =\n            cameraExperienceAccentColor()\n        text.textSize =\n            15.3f * u\n\n        drawFitText(\n            c,\n            "CAMERA • ${cameraExperienceShortLabel()}",\n            safeLeft,\n            y,\n            maxWidth,\n            text,\n            13.6f * u\n        )\n\n        y += 18f * u\n        text.color =\n            reportModeAccentColor()\n        text.textSize =\n            15.2f * u\n\n        drawFitText(\n            c,\n            "MODE • ${qualityModes[qualityIndex]}   •   SCENE ${sceneModes[sceneIndex]}   •   LOOK ${lookModes[lookIndex]}",\n            safeLeft,\n            y,\n            maxWidth,\n            text,\n            12.8f * u\n        )\n\n        y += 18f * u\n        text.color =\n            0xFFAEBDEB.toInt()\n        text.textSize =\n            14.6f * u\n\n        drawFitText(\n            c,\n            autoDirectorStateText(),\n            safeLeft,\n            y,\n            maxWidth,\n            text,\n            12.6f * u\n        )\n\n        y += 20f * u\n''',
    "saved words format"
)

report = must_replace(
    report,
    '''        drawFitText(\n            c,\n            systemOverlay(),\n            safeLeft,\n            y,\n            maxWidth,\n            text,\n            12.9f * u\n        )\n\n        c.restore()\n''',
    '''        drawFitText(\n            c,\n            systemOverlay(),\n            safeLeft,\n            y,\n            maxWidth,\n            text,\n            12.9f * u\n        )\n\n        val railEndY =\n            y + (6f * u)\n\n        c.drawLine(\n            safeLeft - (8f * u),\n            railStartY,\n            safeLeft - (8f * u),\n            railEndY,\n            rail\n        )\n\n        c.drawLine(\n            safeLeft - (8f * u),\n            railEndY,\n            safeLeft + (7f * u),\n            railEndY,\n            rail\n        )\n\n        c.restore()\n''',
    "short rail ending at words"
)

# Version identity for report output/integrity.
report = report.replace(
    '"DEVELOP_UGANDA_V216_${cameraExperienceId}_${reportId}_${sceneModes[sceneIndex]}_${lookModes[lookIndex]}_"',
    '"DEVELOP_UGANDA_V217_${cameraExperienceId}_${reportId}_${sceneModes[sceneIndex]}_${lookModes[lookIndex]}_"',
    1
)
report = report.replace('"V216"', '"V217"', 1)
report = report.replace(
    '"V216 INDEPENDENT CAMERA SUITE"',
    '"V217 FIX1 FULL FRAME HUD PRO"',
    1
)
report = report.replace(
    '"V204,V205,V206,V207,V208,V209,V210,V211,V212,V213,V214,V215,V216"',
    '"V204,V205,V206,V207,V208,V209,V210,V211,V212,V213,V214,V215,V216,V217"',
    1
)

report_path.write_text(report, encoding="utf-8")

# LIVE keeps all behavior; only app/output identity advances.
live = live_path.read_text(encoding="utf-8")
live = live.replace("V216", "V217")
live_path.write_text(live, encoding="utf-8")

# Home keeps all 11 direct-open cameras and describes V217 changes.
home = home_path.read_text(encoding="utf-8")
home = home.replace(
    '"INDEPENDENT CAMERA SUITE • V216"',
    '"FULL FRAME HUD PRO • V217"',
    1
)
home = home.replace(
    '"LARGER TEXT • LIGHTER SHADOW • OPTIONAL SOFT BACKING • FULL-OPACITY COLOURS"',
    '"SHORT TELEMETRY RAIL • WIDER READABLE COLUMN • SOFT PANEL • CLEAR CAMERA/MODE ROWS • FULL-OPACITY COLOURS"',
    1
)
home = home.replace(
    '"V205→V215 NOW OPEN AS SEPARATE CAMERAS • V204 ENGINE RETAINED • EACH CAMERA HAS ITS OWN STATE/DEFAULTS/UI EMPHASIS/RECORDED IDENTITY • V216"',
    '"V205→V215 INDEPENDENT CAMERAS RETAINED • V217 ADDS FULL-SCREEN CAMERA PREVIEW + POLISHED SAVED-VIDEO HUD • NOTHING DROPPED"',
    1
)
home = home.replace(
    '"V216 CAMERA ARCHITECTURE"',
    '"V217 FULL FRAME CAMERA"',
    1
)
home = home.replace(
    '"NO DROPDOWN TO OPEN THESE CAMERAS • EVERY CARD BELOW OPENS ITS OWN ANDROID CAMERA ACTIVITY • EACH CAMERA REMEMBERS ITS OWN SETTINGS"',
    '"EVERY CAMERA STILL OPENS DIRECTLY • CAMERA PREVIEW NOW FILLS THE SCREEN BEHIND CONTROLS • RECORDING FORCES FULL FRAME • SAVED HUD IS WIDER AND CLEANER"',
    1
)
home_path.write_text(home, encoding="utf-8")

gradle = gradle_path.read_text(encoding="utf-8")
gradle = re.sub(r"versionCode\s*=\s*\d+", "versionCode = 21701", gradle, count=1)
gradle = re.sub(
    r'versionName\s*=\s*"[^"]+"',
    'versionName = "217.1-full-frame-hud-pro-fix1"',
    gradle,
    count=1
)
gradle_path.write_text(gradle, encoding="utf-8")

print("V217 Full Frame HUD Pro applied")
