from pathlib import Path
import re

ROOT = Path("v172-source/app")
SRC = ROOT / "src/main/java/com/sentongoharuna/pulse"
REPORT = SRC / "DevelopUgandaCameraActivity.kt"
LIVE = SRC / "DevelopUgandaLiveActivity.kt"
HOME = SRC / "DevelopUgandaNewsroomActivity.kt"
INDEPENDENT = SRC / "DevelopUgandaIndependentCameras.kt"
MANIFEST = ROOT / "src/main/AndroidManifest.xml"
EDITOR = SRC / "DevelopUgandaEditorActivity.kt"
GRADLE = ROOT / "build.gradle.kts"

PAYLOAD = Path(__file__).resolve().parent

gradle = GRADLE.read_text(encoding="utf-8")

if 'versionCode = 22101' not in gradle:
    raise SystemExit("V222 expects V221 FIX1 first")

if 'versionName = "221.1-social-upload-master-fix1"' not in gradle:
    raise SystemExit("V222 expects V221.1 base")

report = REPORT.read_text(encoding="utf-8")

# Imports.
if "import android.media.MediaMetadataRetriever\n" not in report:
    report = report.replace(
        "import android.location.LocationManager\n",
        "import android.location.LocationManager\n"
        "import android.media.MediaMetadataRetriever\n",
        1
    )

if "import java.io.FileInputStream\n" not in report:
    report = report.replace(
        "import java.io.File\n",
        "import java.io.File\n"
        "import java.io.FileInputStream\n",
        1
    )

media3_imports = (
    "import androidx.media3.common.MediaItem\n"
    "import androidx.media3.common.MimeTypes\n"
    "import androidx.media3.common.util.UnstableApi\n"
    "import androidx.media3.effect.Brightness\n"
    "import androidx.media3.effect.Presentation\n"
    "import androidx.media3.transformer.AudioEncoderSettings\n"
    "import androidx.media3.transformer.Composition\n"
    "import androidx.media3.transformer.DefaultEncoderFactory\n"
    "import androidx.media3.transformer.EditedMediaItem\n"
    "import androidx.media3.transformer.EditedMediaItemSequence\n"
    "import androidx.media3.transformer.Effects\n"
    "import androidx.media3.transformer.ExportException\n"
    "import androidx.media3.transformer.ExportResult\n"
    "import androidx.media3.transformer.Transformer\n"
    "import androidx.media3.transformer.VideoEncoderSettings\n"
)

if "import androidx.media3.transformer.Transformer\n" not in report:
    anchor = "import androidx.core.view.WindowInsetsControllerCompat\n"
    if anchor not in report:
        raise SystemExit("V222 Media3 import anchor missing")
    report = report.replace(
        anchor,
        anchor + media3_imports,
        1
    )

class_anchor = "open class DevelopUgandaCameraActivity : AppCompatActivity(), SensorEventListener {"

if "@OptIn(UnstableApi::class)\n" + class_anchor not in report:
    if class_anchor not in report:
        raise SystemExit("V222 REPORT class anchor missing")
    report = report.replace(
        class_anchor,
        "@OptIn(UnstableApi::class)\n" + class_anchor,
        1
    )

# Runtime state.
state_anchor = "    private var overlayEffect: OverlayEffect? = null\n"

if "private var automaticSocialTransformer: Transformer? = null" not in report:
    if state_anchor not in report:
        raise SystemExit("V222 transformer state anchor missing")
    report = report.replace(
        state_anchor,
        state_anchor +
        "    private var automaticSocialTransformer: Transformer? = null\n"
        "    private var automaticSocialExportActive = false\n",
        1
    )

def insert_before_else_in_function(text, signature, insertion):
    start = text.find(signature)
    if start < 0:
        raise SystemExit("V222 function missing: " + signature)

    next_fun = text.find(
        "\n    private fun ",
        start + len(signature)
    )
    if next_fun < 0:
        raise SystemExit("V222 function end missing: " + signature)

    block = text[start:next_fun]
    marker = "            else ->"
    pos = block.find(marker)

    if pos < 0:
        raise SystemExit("V222 else missing: " + signature)

    block = block[:pos] + insertion + block[pos:]
    return text[:start] + block + text[next_fun:]

if '"V222_SOCIAL"' not in report:
    report = insert_before_else_in_function(
        report,
        "    private fun cameraExperienceDisplayName(): String {",
        '            "V222_SOCIAL" ->\n'
        '                "V222 • SOCIAL MEDIA CAM"\n'
    )

    report = insert_before_else_in_function(
        report,
        "    private fun cameraExperienceInstruction(): String {",
        '            "V222_SOCIAL" ->\n'
        '                "RECORD → AUTO OPTIMIZE → SM POSTS • 9:16 • SOCIAL FHD • ORIGINAL + SOCIAL COPY"\n'
    )

    report = insert_before_else_in_function(
        report,
        "    private fun cameraExperienceBestFor(): String {",
        '            "V222_SOCIAL" ->\n'
        '                "TIKTOK / REELS / SHORTS / SOCIAL POSTS"\n'
    )

    report = insert_before_else_in_function(
        report,
        "    private fun cameraExperienceAccentColor(): Int {",
        '            "V222_SOCIAL" -> 0xFF62D8C9.toInt()\n'
    )

# Defaults.
defaults_sig = "    private fun applyIndependentCameraDefaultsIfNeeded() {"
start = report.find(defaults_sig)

if start < 0:
    raise SystemExit("V222 defaults function missing")

next_fun = report.find(
    "\n    private fun ",
    start + len(defaults_sig)
)

if next_fun < 0:
    raise SystemExit("V222 defaults function end missing")

defaults_block = report[start:next_fun]

if '"V222_SOCIAL" -> {' not in defaults_block:
    v215_anchor = (
        '            "V215_AUTO" -> {\n'
        '                quality("SOCIAL FHD")\n'
        '                scene("REPORTER")\n'
        '                look("CLEAN")\n'
        '                autoDirectorEnabled = true\n'
        '            }\n'
    )

    if v215_anchor not in defaults_block:
        raise SystemExit("V222 V215 defaults anchor missing")

    v222_defaults = (
        v215_anchor +
        '            "V222_SOCIAL" -> {\n'
        '                quality("SOCIAL FHD")\n'
        '                scene("REPORTER")\n'
        '                look("CLEAN")\n'
        '                reportHudSizeIndex = 0\n'
        '                reportHudContrastIndex = 1\n'
        '                reportHudBackingIndex = 1\n'
        '                reportDisplayMode = "SOCIAL POST"\n'
        '                autoDirectorEnabled = false\n'
        '            }\n'
    )

    defaults_block = defaults_block.replace(
        v215_anchor,
        v222_defaults,
        1
    )

    report = report[:start] + defaults_block + report[next_fun:]

# Helpers.
if "private fun exportAutomaticSocialMaster(" not in report:
    helper_anchor = "    private fun createIntegrityRecord(\n"

    if helper_anchor not in report:
        raise SystemExit("V222 helper insertion anchor missing")

    helpers = (
        PAYLOAD / "social_helpers.txt"
    ).read_text(
        encoding="utf-8"
    )

    report = report.replace(
        helper_anchor,
        helpers + helper_anchor,
        1
    )

# Finalize auto-export hook.
finalize_start = report.find(
    "                is VideoRecordEvent.Finalize -> {"
)

if finalize_start < 0:
    raise SystemExit("V222 Finalize branch missing")

integrity_pos = report.find(
    "createIntegrityRecord(",
    finalize_start
)

if integrity_pos < 0:
    raise SystemExit("V222 Finalize integrity call missing")

controls_anchor = (
    "                        setReportOperatorControlsHidden(\n"
    "                            false\n"
    "                        )\n"
)

controls_pos = report.find(
    controls_anchor,
    integrity_pos
)

if controls_pos < 0:
    raise SystemExit("V222 Finalize controls anchor missing")

hook_marker = (
    "exportAutomaticSocialMaster(\n"
    "                                event.outputResults.outputUri"
)

if hook_marker not in report:
    auto_hook = (
        "                        if (\n"
        "                            !hadError &&\n"
        "                            isSocialMediaCamera()\n"
        "                        ) {\n"
        "                            exportAutomaticSocialMaster(\n"
        "                                event.outputResults.outputUri\n"
        "                            )\n"
        "                        }\n\n"
    )

    report = (
        report[:controls_pos] +
        auto_hook +
        report[controls_pos:]
    )

# Version identity in new REPORT output.
report = report.replace(
    '"app_version",\n                            "V221"',
    '"app_version",\n                            "V222"',
    1
)

report = report.replace(
    '"${sceneTag()} • V221"',
    '"${sceneTag()} • V222"',
    1
)

report = report.replace(
    '•   V221   •   THERM',
    '•   V222   •   THERM',
    1
)

report = report.replace(
    '"DEVELOP_UGANDA_V221_${cameraExperienceId}_',
    '"DEVELOP_UGANDA_V222_${cameraExperienceId}_',
    1
)

REPORT.write_text(report, encoding="utf-8")

# Independent Activity.
independent = INDEPENDENT.read_text(encoding="utf-8")

if "class DevelopUgandaSocialMediaCameraActivity" not in independent:
    independent = independent.rstrip() + (
        '\n\nclass DevelopUgandaSocialMediaCameraActivity :\n'
        '    DevelopUgandaCameraActivity() {\n'
        '    override fun defaultCameraExperienceId(): String =\n'
        '        "V222_SOCIAL"\n'
        '}\n'
    )

INDEPENDENT.write_text(
    independent,
    encoding="utf-8"
)

# Manifest.
manifest = MANIFEST.read_text(encoding="utf-8")

manifest_anchor = (
    '        <activity\n'
    '            android:name=".DevelopUgandaAutoDirectorCameraActivity"\n'
    '            android:screenOrientation="portrait"\n'
    '            android:exported="false"/>\n'
)

if ".DevelopUgandaSocialMediaCameraActivity" not in manifest:
    if manifest_anchor not in manifest:
        raise SystemExit("V222 Manifest anchor missing")

    social_activity = (
        manifest_anchor +
        '\n'
        '        <activity\n'
        '            android:name=".DevelopUgandaSocialMediaCameraActivity"\n'
        '            android:screenOrientation="portrait"\n'
        '            android:exported="false"/>\n'
    )

    manifest = manifest.replace(
        manifest_anchor,
        social_activity,
        1
    )

MANIFEST.write_text(
    manifest,
    encoding="utf-8"
)

# Home.
home = HOME.read_text(encoding="utf-8")

top_old = '"SOCIAL UPLOAD MASTER • V221\\nSHOT FINDER + MEDIA3 EDITOR"'

if top_old not in home:
    raise SystemExit("V222 HOME top label anchor missing")

home = home.replace(
    top_old,
    '"SOCIAL MEDIA CAMERA • V222\\nRECORD → AUTO SM MASTER"',
    1
)

home = home.replace(
    "V205→V215",
    "V205→V222"
)

home = home.replace(
    "UNSURE → V215",
    "UNSURE → V215   •   SOCIAL POST → V222"
)

nothing_anchor = (
    '        page.addView(\n'
    '            compactStatus(\n'
    '                "NOTHING DROPPED",\n'
)

if "OPEN V222 SM CAMERA" not in home:
    if nothing_anchor not in home:
        raise SystemExit("V222 HOME Nothing Dropped anchor missing")

    social_card = (
        PAYLOAD / "social_home_card.txt"
    ).read_text(
        encoding="utf-8"
    )

    home = home.replace(
        nothing_anchor,
        social_card + nothing_anchor,
        1
    )

home = home.replace(
    '"EDIT + SOCIAL MASTER"',
    '"EDIT + SOCIAL MASTER • OPTIONAL"',
    1
)

HOME.write_text(
    home,
    encoding="utf-8"
)

# LIVE identity only.
live = LIVE.read_text(encoding="utf-8")
live = live.replace(
    "V221",
    "V222"
)
LIVE.write_text(
    live,
    encoding="utf-8"
)

# Editor stays available as fallback, but is not the main workflow.
editor = EDITOR.read_text(encoding="utf-8")
editor = editor.replace(
    '"SOCIAL MASTER FIX1 • FORCED H.264 RE-ENCODE • ORIGINAL UNTOUCHED"',
    '"OPTIONAL EDITOR SOCIAL MASTER • V222 SM CAMERA IS PRIMARY"',
    1
)
EDITOR.write_text(
    editor,
    encoding="utf-8"
)

# App version.
gradle = re.sub(
    r"versionCode\s*=\s*\d+",
    "versionCode = 22200",
    gradle,
    count=1
)

gradle = re.sub(
    r'versionName\s*=\s*"[^"]+"',
    'versionName = "222.0-social-media-camera"',
    gradle,
    count=1
)

GRADLE.write_text(
    gradle,
    encoding="utf-8"
)

print("V222 Social Media Camera applied.")
