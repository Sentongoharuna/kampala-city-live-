from pathlib import Path
import re

ROOT = Path("v172-source/app")
SRC = ROOT / "src/main/java/com/sentongoharuna/pulse"
EDITOR = SRC / "DevelopUgandaEditorActivity.kt"
GRADLE = ROOT / "build.gradle.kts"

gradle = GRADLE.read_text(encoding="utf-8")

if 'versionCode = 22100' not in gradle:
    raise SystemExit("V221 FIX1 expects versionCode 22100")

if 'versionName = "221.0-social-upload-master"' not in gradle:
    raise SystemExit("V221 FIX1 expects V221 Social Upload Master base")

editor = EDITOR.read_text(encoding="utf-8")

if "import android.media.MediaMetadataRetriever\n" not in editor:
    editor = editor.replace(
        "import android.graphics.drawable.GradientDrawable\n",
        "import android.graphics.drawable.GradientDrawable\n"
        "import android.media.MediaMetadataRetriever\n",
        1
    )

if "import androidx.media3.effect.Brightness\n" not in editor:
    editor = editor.replace(
        "import androidx.media3.effect.Presentation\n",
        "import androidx.media3.effect.Brightness\n"
        "import androidx.media3.effect.Presentation\n",
        1
    )

editor = editor.replace(
    '"develop.uganda  EDITOR V221"',
    '"develop.uganda  EDITOR V221.1"',
    1
)

editor = editor.replace(
    '"MEDIA3 EDITOR + SOCIAL UPLOAD MASTER • ORIGINAL STAYS UNTOUCHED"',
    '"SOCIAL MASTER FIX1 • FORCED H.264 RE-ENCODE • ORIGINAL UNTOUCHED"',
    1
)

editor = editor.replace(
    '"SOCIAL UPLOAD MASTER • 1080×1920 • H.264 • AAC • 30 FPS MAX • 2s KEYFRAMES"',
    '"SOCIAL MASTER • FORCED RE-ENCODE • 1080×1920 • H.264 • AAC • 30 FPS MAX • 2s KEYFRAMES"',
    1
)

old_effects = '''        val socialEffects =
            Effects(
                emptyList(),
                listOf(
                    Presentation.createForWidthAndHeight(
                        1080,
                        1920,
                        Presentation.LAYOUT_SCALE_TO_FIT
                    )
                )
            )
'''

new_effects = '''        val socialEffects =
            Effects(
                emptyList(),
                listOf(
                    Presentation.createForWidthAndHeight(
                        1080,
                        1920,
                        Presentation.LAYOUT_SCALE_TO_FIT
                    ),

                    // Media3 may transmux when input/output already match.
                    // A tiny non-zero RGB effect is visually negligible but
                    // requires decode -> process -> encode, so the requested
                    // social bitrate and H.264 encoder settings are applied.
                    Brightness(
                        0.0001f
                    )
                )
            )
'''

if old_effects not in editor:
    raise SystemExit("V221 FIX1 socialEffects anchor missing")

editor = editor.replace(
    old_effects,
    new_effects,
    1
)

old_completed = '''                            val uri =
                                publishSocialMaster(
                                    temp =
                                        temp,
                                    platform =
                                        platform
                                )

                            temp.delete()
'''

new_completed = '''                            val verification =
                                verifySocialEncode(
                                    temp =
                                        temp,
                                    requestedBitrate =
                                        bitrate
                                )

                            val uri =
                                publishSocialMaster(
                                    temp =
                                        temp,
                                    platform =
                                        platform
                                )

                            temp.delete()
'''

if old_completed not in editor:
    raise SystemExit("V221 FIX1 completion anchor missing")

editor = editor.replace(
    old_completed,
    new_completed,
    1
)

old_status = '''                                statusView.text =
                                    "$platform MASTER SAVED • 1080×1920 • H.264 • AAC • 30 FPS MAX • original preserved"
'''

new_status = '''                                statusView.text =
                                    "$platform MASTER SAVED • FORCED RE-ENCODE VERIFIED • $verification • original preserved"
'''

if old_status not in editor:
    raise SystemExit("V221 FIX1 saved-status anchor missing")

editor = editor.replace(
    old_status,
    new_status,
    1
)

verify_helper = r'''
    private fun verifySocialEncode(
        temp: File,
        requestedBitrate: Int
    ): String {
        if (
            !temp.exists() ||
            temp.length() <=
                0L
        ) {
            error(
                "Social master output is empty"
            )
        }

        val retriever =
            MediaMetadataRetriever()

        return try {
            retriever.setDataSource(
                temp.absolutePath
            )

            val width =
                retriever.extractMetadata(
                    MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH
                )
                    ?.toIntOrNull()
                    ?: 0

            val height =
                retriever.extractMetadata(
                    MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT
                )
                    ?.toIntOrNull()
                    ?: 0

            val totalBitrate =
                retriever.extractMetadata(
                    MediaMetadataRetriever.METADATA_KEY_BITRATE
                )
                    ?.toLongOrNull()
                    ?: 0L

            if (
                width !=
                    1080 ||
                height !=
                    1920
            ) {
                error(
                    "Social master dimensions are ${width}×${height}, expected 1080×1920"
                )
            }

            val maxAllowed =
                (
                    requestedBitrate.toLong() *
                        135L
                    ) /
                    100L

            if (
                totalBitrate >
                    maxAllowed
            ) {
                error(
                    "Social master remained too close to original bitrate (${totalBitrate / 1_000_000L} Mbps). Forced re-encode verification failed."
                )
            }

            if (
                totalBitrate <
                    4_000_000L
            ) {
                error(
                    "Social master bitrate is unexpectedly low (${totalBitrate / 1_000_000L} Mbps)"
                )
            }

            val mbps =
                String.format(
                    Locale.US,
                    "%.1f",
                    totalBitrate /
                        1_000_000.0
                )

            "1080×1920 • $mbps Mbps"
        } finally {
            try {
                retriever.release()
            } catch (_: Exception) {
            }
        }
    }

'''

publish_anchor = "    private fun publishSocialMaster(\n"

if publish_anchor not in editor:
    raise SystemExit("V221 FIX1 verify-helper anchor missing")

editor = editor.replace(
    publish_anchor,
    verify_helper + publish_anchor,
    1
)

editor = editor.replace(
    '"DEVELOP_UGANDA_V221_${platform}_MASTER_"',
    '"DEVELOP_UGANDA_V221_FIX1_${platform}_MASTER_"',
    1
)

editor = editor.replace(
    '"$platform MASTER • preparing 1080×1920 H.264/AAC • ${bitrate / 1_000_000} Mbps target"',
    '"$platform MASTER • FORCED RE-ENCODE • 1080×1920 H.264/AAC • ${bitrate / 1_000_000} Mbps target"',
    1
)

EDITOR.write_text(
    editor,
    encoding="utf-8"
)

gradle = re.sub(
    r"versionCode\s*=\s*\d+",
    "versionCode = 22101",
    gradle,
    count=1
)

gradle = re.sub(
    r'versionName\s*=\s*"[^"]+"',
    'versionName = "221.1-social-upload-master-fix1"',
    gradle,
    count=1
)

GRADLE.write_text(
    gradle,
    encoding="utf-8"
)

print("V221 FIX1 Forced Social Re-encode applied.")
