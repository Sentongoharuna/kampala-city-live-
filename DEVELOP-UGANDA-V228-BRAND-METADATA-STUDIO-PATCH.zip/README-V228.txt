develop.uganda V228 Brand & Metadata Studio

Base required:
- V227 Director & QC Pro
- versionCode 22700
- versionName 227.0-director-qc-pro

V228 keeps V227 Director/QC and V226 FIX2 newsroom intake.

Implemented:
- configurable saved-video top display name
- optional organization/newsroom line
- app-credit toggle
- per-category saved-video metadata switches
- FULL FORENSIC / NEWS REPORT / SOCIAL CLEAN / CONSTRUCTION / INTERVIEW / PRIVATE MASTER / CUSTOM presets
- VERIFIED MASTER and PUBLIC/SOCIAL recording-output profiles
- exact-GPS warning before immediate share
- REPORT and LIVE saved overlays read the V228 tag profile every frame
- V227 screen-only Director / histogram remain screen-only
- Story Package BRAND_METADATA.json captures the profile used for the clip
- caption draft uses the user brand / organization
- old V227 users default to ALL tags visible so V228 drops nothing by default

Important:
PUBLIC / SOCIAL changes which metadata is burned into NEW recordings.
It does not pretend to remove metadata that was already burned into an older video.
