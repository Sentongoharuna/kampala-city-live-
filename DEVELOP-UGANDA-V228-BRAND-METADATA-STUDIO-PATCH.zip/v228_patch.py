from pathlib import Path
import re
import shutil

ROOT = Path("v172-source/app")
SRC = ROOT / "src/main/java/com/sentongoharuna/pulse"

REPORT = SRC / "DevelopUgandaCameraActivity.kt"
LIVE = SRC / "DevelopUgandaLiveActivity.kt"
PHOTO = SRC / "DevelopUgandaPhotoSuiteActivity.kt"
HOME = SRC / "DevelopUgandaNewsroomActivity.kt"
PACKAGER = SRC / "DevelopUgandaStoryPackager.kt"
REVIEW = SRC / "DevelopUgandaInstantReviewDialog.kt"
MANIFEST = ROOT / "src/main/AndroidManifest.xml"
GRADLE = ROOT / "build.gradle.kts"

PAYLOAD = Path(__file__).resolve().parent

def replace_once(text, old, new, label):
    if old not in text:
        raise SystemExit("V228 anchor missing: " + label)
    return text.replace(old, new, 1)

def function_bounds(text, function_name):
    marker = f"fun {function_name}"
    start = text.find(marker)
    if start < 0:
        raise SystemExit("V228 function missing: " + function_name)

    line_start = text.rfind("\n", 0, start) + 1
    brace = text.find("{", start)

    if brace < 0:
        raise SystemExit("V228 opening brace missing: " + function_name)

    depth = 0
    quote = None
    escaped = False

    for index in range(brace, len(text)):
        char = text[index]

        if quote is not None:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == quote:
                quote = None
            continue

        if char in ('"', "'"):
            quote = char
            continue

        if char == "{":
            depth += 1
        elif char == "}":
            depth -= 1

            if depth == 0:
                return line_start, index + 1

    raise SystemExit("V228 closing brace missing: " + function_name)

def replace_function(text, function_name, replacement):
    start, end = function_bounds(text, function_name)
    return text[:start] + replacement.rstrip() + "\n" + text[end:]

gradle = GRADLE.read_text(encoding="utf-8")

if 'versionCode = 22700' not in gradle:
    raise SystemExit("V228 requires V227 versionCode 22700")

if 'versionName = "227.0-director-qc-pro"' not in gradle:
    raise SystemExit("V228 requires V227 Director & QC Pro base")

for name in [
    "DevelopUgandaBrandMetadataStore.kt",
    "DevelopUgandaBrandMetadataActivity.kt",
]:
    shutil.copyfile(
        PAYLOAD / name,
        SRC / name
    )

# REPORT
report = REPORT.read_text(encoding="utf-8")

report = replace_once(
    report,
    "        const val ACTION_HEALTH = 26\n",
    "        const val ACTION_HEALTH = 26\n"
    "        const val ACTION_BRAND_METADATA = 27\n",
    "REPORT V228 action"
)

report = replace_once(
    report,
    "    private lateinit var healthButton: Button\n",
    "    private lateinit var healthButton: Button\n"
    "    private lateinit var brandMetadataButton: Button\n",
    "REPORT brand button field"
)

health_button_block = '''        healthButton =
            deckButton(
                "CAMERA\\nHEALTH",
                0xFF73B7D9.toInt()
            )

'''

brand_button_block = health_button_block + '''        brandMetadataButton =
            deckButton(
                "BRAND\\nTAGS",
                0xFFD0B06F.toInt()
            )

'''

report = replace_once(
    report,
    health_button_block,
    brand_button_block,
    "REPORT brand button"
)

report = replace_once(
    report,
    '''        listOf(
            directorButton,
            continuityButton,
            healthButton
        ).forEachIndexed {
''',
    '''        listOf(
            directorButton,
            continuityButton,
            healthButton,
            brandMetadataButton
        ).forEachIndexed {
''',
    "REPORT V227 row retained + V228 button"
)

report = replace_once(
    report,
    '''        healthButton.setOnTouchListener(
            DeckTouchListener(ACTION_HEALTH)
        )
''',
    '''        healthButton.setOnTouchListener(
            DeckTouchListener(ACTION_HEALTH)
        )

        brandMetadataButton.setOnTouchListener(
            DeckTouchListener(ACTION_BRAND_METADATA)
        )
''',
    "REPORT brand touch listener"
)

report = replace_once(
    report,
    '''                        ACTION_HEALTH ->
                            openV227CameraHealth()
''',
    '''                        ACTION_HEALTH ->
                            openV227CameraHealth()

                        ACTION_BRAND_METADATA ->
                            openV228BrandMetadataStudio()
''',
    "REPORT brand dispatch"
)

report = replace_once(
    report,
    '''        previewBrandView =
            hud(
                "develop.uganda • V227",
''',
    '''        previewBrandView =
            hud(
                DevelopUgandaBrandMetadataStore.previewTitle(
                    this,
                    "V228"
                ),
''',
    "REPORT preview brand"
)

report = replace_once(
    report,
    '''    override fun onResume() {
        super.onResume()
''',
    '''    override fun onResume() {
        super.onResume()

        refreshV228BrandUi()
''',
    "REPORT refresh brand on resume"
)

brand_helpers = '''    private fun refreshV228BrandUi() {
        if (
            ::previewBrandView.isInitialized
        ) {
            previewBrandView.text =
                DevelopUgandaBrandMetadataStore.previewTitle(
                    this,
                    "V228"
                )
        }

        if (
            ::brandMetadataButton.isInitialized
        ) {
            val config =
                DevelopUgandaBrandMetadataStore.snapshot(
                    this
                )

            brandMetadataButton.text =
                "BRAND\\n" +
                    config.preset
                        .take(
                            9
                        )
        }
    }

    private fun openV228BrandMetadataStudio() {
        startActivity(
            android.content.Intent(
                this,
                DevelopUgandaBrandMetadataActivity::class.java
            )
        )
    }

'''

report = replace_once(
    report,
    '''    private fun openV227CameraHealth() {
''',
    brand_helpers + '''    private fun openV227CameraHealth() {
''',
    "REPORT V228 helpers"
)

report = replace_function(
    report,
    "drawReporterOverlay",
    (PAYLOAD / "report_v228_overlay.txt").read_text(
        encoding="utf-8"
    )
)

report = report.replace(
    "DEVELOP_UGANDA_V227_",
    "DEVELOP_UGANDA_V228_"
)

REPORT.write_text(
    report,
    encoding="utf-8"
)

# LIVE
live = LIVE.read_text(encoding="utf-8")

live = replace_once(
    live,
    '''        liveTitle =
            label(
                "develop.uganda • V227",
''',
    '''        liveTitle =
            label(
                DevelopUgandaBrandMetadataStore.previewTitle(
                    this,
                    "V228"
                ),
''',
    "LIVE preview brand"
)

live = replace_function(
    live,
    "drawLiveBroadcastOverlay",
    (PAYLOAD / "live_v228_overlay.txt").read_text(
        encoding="utf-8"
    )
)

live = live.replace(
    "DEVELOP_UGANDA_V227_",
    "DEVELOP_UGANDA_V228_"
)

LIVE.write_text(
    live,
    encoding="utf-8"
)

# PHOTO
photo = PHOTO.read_text(encoding="utf-8")
photo = photo.replace(
    '"${modeDisplayName()} • V225"',
    '"${modeDisplayName()} • V228"'
)
PHOTO.write_text(
    photo,
    encoding="utf-8"
)

# REVIEW
review = REVIEW.read_text(encoding="utf-8")

review = replace_function(
    review,
    "share",
    (PAYLOAD / "review_v228_share.txt").read_text(
        encoding="utf-8"
    )
)

review = review.replace(
    '"develop.uganda • V227 REVIEW"',
    '"develop.uganda • V228 REVIEW"'
)

REVIEW.write_text(
    review,
    encoding="utf-8"
)

# STORY PACKAGE
packager = PACKAGER.read_text(encoding="utf-8")

packager = replace_once(
    packager,
    '''        val appContext = context.applicationContext

        executor.execute {
''',
    '''        val appContext = context.applicationContext

        // Snapshot before the background task starts, so the Story Package
        // records the V228 brand/tag profile that belonged to this clip.
        val brandSnapshot =
            DevelopUgandaBrandMetadataStore.snapshot(
                context
            )

        executor.execute {
''',
    "Story Package capture-time brand snapshot"
)

packager = packager.replace(
    '"V227"',
    '"V228"'
)

packager = packager.replace(
    "AUTO STORY PACKAGE • V227",
    "AUTO STORY PACKAGE • V228"
)

metadata_start = '''                writeJson(
                    appContext,
                    relative,
                    "METADATA.json",
'''

brand_json_write = '''                writeJson(
                    appContext,
                    relative,
                    "BRAND_METADATA.json",
                    brandSnapshot.toJson()
                        .put(
                            "captured_for_package",
                            packageId
                        )
                        .put(
                            "captured_utc",
                            Instant.now().toString()
                        )
                )

''' + metadata_start

packager = replace_once(
    packager,
    metadata_start,
    brand_json_write,
    "Story Package BRAND_METADATA.json"
)

packager = replace_once(
    packager,
    '''                        .put("app_version", "V228")
                        .put("package_id", packageId)
''',
    '''                        .put("app_version", "V228")
                        .put("brand_display_name", brandSnapshot.displayName)
                        .put("brand_organization", brandSnapshot.organization)
                        .put("brand_overlay_preset", brandSnapshot.preset)
                        .put("brand_output_profile", brandSnapshot.outputProfile)
                        .put("package_id", packageId)
''',
    "METADATA brand fields"
)

packager = replace_once(
    packager,
    '''                    suggestedCaption(metadata)
''',
    '''                    suggestedCaption(
                        metadata,
                        brandSnapshot
                    )
''',
    "caption brand snapshot"
)

packager = replace_once(
    packager,
    '''                                    "METADATA.json",
                                    "INTEGRITY.json",
''',
    '''                                    "METADATA.json",
                                    "BRAND_METADATA.json",
                                    "INTEGRITY.json",
''',
    "manifest brand metadata file"
)

caption_replacement = '''    private fun suggestedCaption(
        metadata: StoryMetadata,
        brand: DevelopUgandaBrandMetadataStore.Snapshot
    ): String {
        val subject =
            metadata.autoView
                .substringAfter(
                    "likely",
                    ""
                )
                .replace(
                    "•",
                    ","
                )
                .trim()

        val title =
            metadata.title
                .trim()
                .takeIf {
                    it.isNotBlank() &&
                        it !=
                            "--"
                }

        val place =
            metadata.place
                ?.trim()
                ?.takeIf {
                    it.isNotBlank() &&
                        !it.startsWith(
                            "Locating",
                            ignoreCase =
                                true
                        )
                }

        val sentence =
            listOfNotNull(
                title,
                subject.takeIf {
                    it.isNotBlank()
                },
                place
            )
                .joinToString(
                    " — "
                )
                .ifBlank {
                    "Field report"
                }

        val byline =
            when {
                brand.organization.isNotBlank() ->
                    "${brand.displayName} • ${brand.organization}"

                brand.displayName.isNotBlank() ->
                    brand.displayName

                else ->
                    metadata.reporter
            }

        return "DRAFT CAPTION • REVIEW BEFORE POSTING\\n\\n" +
            sentence +
            "\\n\\nField report • $byline\\n" +
            "Camera • ${metadata.camera}\\n" +
            "Recorded with develop.uganda • V228\\n"
    }
'''

packager = replace_function(
    packager,
    "suggestedCaption",
    caption_replacement
)

PACKAGER.write_text(
    packager,
    encoding="utf-8"
)

# HOME
home = HOME.read_text(encoding="utf-8")

home = home.replace(
    '"DIRECTOR & QC PRO • V227\\nV226 FIX2 NEWSROOM + V225 PHOTO RETAINED"',
    '"BRAND & METADATA STUDIO • V228\\nV227 DIRECTOR/QC + V226 FIX2 NEWSROOM RETAINED"',
    1
)

v227_status = '''        page.addView(
            compactStatus(
                "V227 • DIRECTOR & QC PRO",
                "SCREEN-ONLY REAL FACE COMPOSITION FOR PEOPLE/INTERVIEW • PREVIEW LUMA HISTOGRAM • ESTIMATED RECORD TIME • REAL CAMERA DEVICE MAP • SHOT CONTINUITY • INSTANT MP4 QC + REVIEW • V226 FIX2 NEWSROOM INTAKE RETAINED",
                0xFF91B6A0.toInt()
            )
        )

'''

v228_block = v227_status + '''        page.addView(
            compactStatus(
                "V228 • BRAND & METADATA STUDIO",
                "CUSTOM TOP NAME / ORGANIZATION • EVERY SAVED-VIDEO METADATA CATEGORY CAN BE ON/OFF • FULL FORENSIC / NEWS / SOCIAL CLEAN / CONSTRUCTION / INTERVIEW / PRIVATE MASTER / CUSTOM • PUBLIC PROFILE HIDES EXACT GPS BY DEFAULT • STORY PACKAGE PRESERVES BRAND/TAG SNAPSHOT",
                0xFFD0B06F.toInt()
            )
        )

        page.addView(
            launchCard(
                "V228 • BRAND & METADATA",
                "Make the camera yours without losing the professional system",
                "Change the main saved-video name • optional organization • choose exactly which telemetry is visibly burned into NEW recordings • privacy-aware PUBLIC/SOCIAL profile • VERIFIED MASTER defaults to the full V227 experience",
                0xFFD0B06F.toInt(),
                "OPEN BRAND & TAG STUDIO"
            ) {
                openIndependentCamera(
                    DevelopUgandaBrandMetadataActivity::class.java
                )
            }
        )

'''

home = replace_once(
    home,
    v227_status,
    v228_block,
    "Home V228 Brand Studio card"
)

HOME.write_text(
    home,
    encoding="utf-8"
)

# MANIFEST
manifest = MANIFEST.read_text(encoding="utf-8")

health_activity = '''        <activity
            android:name=".DevelopUgandaCameraHealthActivity"
            android:screenOrientation="portrait"
            android:exported="false"/>

'''

manifest = replace_once(
    manifest,
    health_activity,
    health_activity + '''        <activity
            android:name=".DevelopUgandaBrandMetadataActivity"
            android:screenOrientation="portrait"
            android:exported="false"/>

''',
    "Manifest V228 Brand Studio"
)

MANIFEST.write_text(
    manifest,
    encoding="utf-8"
)

gradle = re.sub(
    r"versionCode\s*=\s*\d+",
    "versionCode = 22800",
    gradle,
    count=1
)

gradle = re.sub(
    r'versionName\s*=\s*"[^"]+"',
    'versionName = "228.0-brand-metadata-studio"',
    gradle,
    count=1
)

GRADLE.write_text(
    gradle,
    encoding="utf-8"
)

print("V228 Brand & Metadata Studio applied.")
