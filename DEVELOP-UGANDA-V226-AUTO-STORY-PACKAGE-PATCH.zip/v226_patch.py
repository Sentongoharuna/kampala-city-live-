from pathlib import Path
import re
import shutil

ROOT = Path('v172-source/app')
SRC = ROOT / 'src/main/java/com/sentongoharuna/pulse'
REPORT = SRC / 'DevelopUgandaCameraActivity.kt'
LIVE = SRC / 'DevelopUgandaLiveActivity.kt'
HOME = SRC / 'DevelopUgandaNewsroomActivity.kt'
PHOTO = SRC / 'DevelopUgandaPhotoSuiteActivity.kt'
MANIFEST = ROOT / 'src/main/AndroidManifest.xml'
GRADLE = ROOT / 'build.gradle.kts'
PAYLOAD = Path(__file__).resolve().parent


def must(text: str, needle: str, label: str):
    if needle not in text:
        raise SystemExit(f'V226 anchor missing: {label}')


def replace_once(text: str, old: str, new: str, label: str) -> str:
    must(text, old, label)
    return text.replace(old, new, 1)


def regex_once(text: str, pattern: str, repl: str, label: str, flags=0) -> str:
    out, n = re.subn(pattern, repl, text, count=1, flags=flags)
    if n != 1:
        raise SystemExit(f'V226 regex anchor missing: {label} ({n})')
    return out


gradle = GRADLE.read_text(encoding='utf-8')
if 'versionCode = 22500' not in gradle:
    raise SystemExit('V226 expects successful V225 versionCode 22500')
if 'versionName = "225.0-professional-photo-suite"' not in gradle:
    raise SystemExit('V226 expects V225 Professional Photo Suite base')

# New isolated story-package components. Existing camera engines stay in their files.
for name in [
    'DevelopUgandaStoryPackager.kt',
    'DevelopUgandaTranscriptEngine.kt',
    'DevelopUgandaStoryPackagesActivity.kt',
]:
    shutil.copyfile(PAYLOAD / name, SRC / name)

# ------------------------------------------------------------------
# REPORT CAMERA: add package hook after successful CameraX Finalize.
# ------------------------------------------------------------------
report = REPORT.read_text(encoding='utf-8')

# Track warnings actually seen while recording, so the package can summarize them.
state_anchor = '    private val shotAssistModeLabels = arrayOf("OFF", "PEAK", "ZEBRA", "BOTH")\n'
if 'private val recordingWarningsSeen' not in report:
    report = replace_once(
        report,
        state_anchor,
        state_anchor + '    private val recordingWarningsSeen = linkedSetOf<String>()\n',
        'recording warning history'
    )

# Add recording warnings to the history inside the real guard refresh.
if 'recordingWarningsSeen.addAll' not in report:
    pattern = r'(private fun updateShotQualityGuard\(\) \{.*?val warnings\s*=\s*shotQualityWarnings\(\)\n)'
    repl = r'''\1
        if (recording != null) {
            recordingWarningsSeen.addAll(
                warnings
            )
        }
'''
    report = regex_once(
        report,
        pattern,
        repl,
        'recording warning accumulation',
        re.S
    )

# Clear warning history only when a brand-new recording is about to start.
if 'recordingWarningsSeen.clear()' not in report:
    report = replace_once(
        report,
        '        reportId = newReportId()\n',
        '        recordingWarningsSeen.clear()\n\n        reportId = newReportId()\n',
        'recording warning reset'
    )

# Pass package identity through the asynchronous V222 social export.
report = regex_once(
    report,
    r'private fun exportAutomaticSocialMaster\(\s*inputUri: Uri\s*\)',
    'private fun exportAutomaticSocialMaster(\n        inputUri: Uri,\n        storyPackageId: String\n    )',
    'social export signature',
    re.S
)

# Attach the completed forced social re-encode to the same Story Package.
old_publish = '''                            publishAutomaticSocialMaster(
                                temp
                            )

                            temp.delete()
'''
new_publish = '''                            val socialUri =
                                publishAutomaticSocialMaster(
                                    temp
                                )

                            DevelopUgandaStoryPackager.attachSocialMaster(
                                this@DevelopUgandaCameraActivity,
                                storyPackageId,
                                socialUri
                            )

                            temp.delete()
'''
report = replace_once(
    report,
    old_publish,
    new_publish,
    'attach social master to package'
)

# Make social-export failure visible in the package too. Replace both identical toast sites.
old_fail_toast = '''                        toast(
                            "SM optimization failed • original video is safe"
                        )
'''
new_fail_toast = '''                        DevelopUgandaStoryPackager.markSocialMasterFailed(
                            this@DevelopUgandaCameraActivity,
                            storyPackageId,
                            "Media3 social export failed"
                        )

                        toast(
                            "SM optimization failed • original video is safe"
                        )
'''
if old_fail_toast in report:
    report = report.replace(old_fail_toast, new_fail_toast)

# Insert the automatic package after successful Finalize, before the V222 social export begins.
old_finalize_social = '''                        if (
                            !hadError &&
                            isSocialMediaCamera()
                        ) {
                            exportAutomaticSocialMaster(
                                event.outputResults.outputUri
                            )
                        }
'''
new_finalize_social = '''                        if (
                            !hadError
                        ) {
                            val packageFinishedUtc =
                                Instant.now().toString()

                            DevelopUgandaStoryPackager.createVideoPackage(
                                this@DevelopUgandaCameraActivity,
                                event.outputResults.outputUri,
                                DevelopUgandaStoryPackager.StoryMetadata(
                                    packageId = reportId.ifBlank {
                                        baseName.ifBlank {
                                            "DU_${System.currentTimeMillis()}"
                                        }
                                    },
                                    camera = cameraExperienceShortLabel(),
                                    reporter = reporterDisplayName(),
                                    storyId = storyDisplayId(),
                                    title = storyId.ifBlank {
                                        "FIELD REPORT"
                                    },
                                    place = placeName,
                                    latitude = lat,
                                    longitude = lon,
                                    gpsAccuracyM = accuracy,
                                    startedUtc = recordStartUtc,
                                    finishedUtc = packageFinishedUtc,
                                    scene = sceneModes[sceneIndex],
                                    look = lookModes[lookIndex],
                                    quality = qualityModes[qualityIndex],
                                    autoView = autoViewSummary,
                                    warnings = recordingWarningsSeen.toList(),
                                    sourceKind = "REPORT",
                                    autoTranscribe =
                                        cameraExperienceId == "V211_AUDIO" ||
                                            sceneModes[sceneIndex] == "INTERVIEW",
                                    expectSocialMaster = isSocialMediaCamera()
                                )
                            )
                        }

                        if (
                            !hadError &&
                            isSocialMediaCamera()
                        ) {
                            exportAutomaticSocialMaster(
                                event.outputResults.outputUri,
                                reportId
                            )
                        }
'''
report = replace_once(
    report,
    old_finalize_social,
    new_finalize_social,
    'report finalize story package hook'
)

# Advance only the app/build identity shown by the video camera; specialist camera names stay V205...V222.
report = report.replace('"${sceneTag()} • V224"', '"${sceneTag()} • V226"')
report = report.replace('•   V224   •   THERM', '•   V226   •   THERM')
report = report.replace('"app_version",\n                            "V224"', '"app_version",\n                            "V226"')
report = report.replace('DEVELOP_UGANDA_V224_', 'DEVELOP_UGANDA_V226_')
REPORT.write_text(report, encoding='utf-8')

# ------------------------------------------------------------------
# LIVE CAMERA: package successful local LIVE recordings.
# ------------------------------------------------------------------
live = LIVE.read_text(encoding='utf-8')

if 'import java.time.Instant\n' not in live:
    live = replace_once(
        live,
        'import java.time.ZoneId\n',
        'import java.time.Instant\nimport java.time.ZoneId\n',
        'LIVE Instant import'
    )

if 'private var liveRecordStartUtc' not in live:
    live = replace_once(
        live,
        '    private var recordStartMs = 0L\n',
        '    private var recordStartMs = 0L\n    private var liveRecordStartUtc = "--"\n',
        'LIVE UTC start field'
    )

if 'liveRecordStartUtc =\n                            Instant.now().toString()' not in live:
    live = replace_once(
        live,
        '''                        recordStartMs =
                            SystemClock.elapsedRealtime()

                        markLiveJournalStarted()
''',
        '''                        recordStartMs =
                            SystemClock.elapsedRealtime()

                        liveRecordStartUtc =
                            Instant.now().toString()

                        markLiveJournalStarted()
''',
        'LIVE UTC start assignment'
    )

old_live_finalize = '''                        markLiveJournalFinished(
                            event.hasError()
                        )

                        if (
                            event.hasError()
                        ) {
'''
new_live_finalize = '''                        markLiveJournalFinished(
                            event.hasError()
                        )

                        if (
                            !event.hasError()
                        ) {
                            DevelopUgandaStoryPackager.createVideoPackage(
                                this@DevelopUgandaLiveActivity,
                                event.outputResults.outputUri,
                                DevelopUgandaStoryPackager.StoryMetadata(
                                    packageId = liveRecordingName.ifBlank {
                                        "LIVE_${System.currentTimeMillis()}"
                                    },
                                    camera = "LIVE STUDIO",
                                    reporter = reporterName,
                                    storyId = storyId,
                                    title = headline,
                                    place = null,
                                    latitude = null,
                                    longitude = null,
                                    gpsAccuracyM = null,
                                    startedUtc = liveRecordStartUtc,
                                    finishedUtc = Instant.now().toString(),
                                    scene = profiles[profileIndex],
                                    look = liveEffectLabels[liveEffectIndex],
                                    quality = qualityLabel,
                                    autoView = liveAutoViewSummary,
                                    warnings = buildLivePreflight().warnings,
                                    sourceKind = "LIVE",
                                    autoTranscribe =
                                        profiles[profileIndex] == "INTERVIEW" ||
                                            livePresetLabels[livePresetIndex] == "INTERVIEW",
                                    expectSocialMaster = false
                                )
                            )
                        }

                        if (
                            event.hasError()
                        ) {
'''
live = replace_once(
    live,
    old_live_finalize,
    new_live_finalize,
    'LIVE finalize story package hook'
)

# App/build tag advances; LIVE STUDIO identity remains explicit.
live = live.replace('V224', 'V226')
LIVE.write_text(live, encoding='utf-8')

# ------------------------------------------------------------------
# PHOTO SUITE: preserve V225 camera identities; only metadata records app V226.
# ------------------------------------------------------------------
photo = PHOTO.read_text(encoding='utf-8')
photo = photo.replace(
    r'\"app_version\": \"V225\"',
    r'\"app_version\": \"V226\"',
    1
)
PHOTO.write_text(photo, encoding='utf-8')

# ------------------------------------------------------------------
# HOME: Story Packages become a visible first-class newsroom feature.
# ------------------------------------------------------------------
home = HOME.read_text(encoding='utf-8')

top_old = '"PROFESSIONAL PHOTO SUITE • V225\\nVIDEO CAMERAS + V224 GUARD RETAINED"'
if top_old in home:
    home = home.replace(
        top_old,
        '"AUTO STORY PACKAGE • V226\\nV225 PHOTO + V224 GUARD RETAINED"',
        1
    )

photo_section = '''        page.addView(
            sectionTitle(
                "PROFESSIONAL PHOTO CAMERAS • V225"
            )
        )
'''

if 'OPEN STORY PACKAGES' not in home:
    must(home, photo_section, 'Home Photo Suite section')
    story_section = '''        page.addView(
            sectionTitle(
                "AUTO STORY PACKAGE • V226"
            )
        )

        page.addView(
            compactStatus(
                "AFTER A SUCCESSFUL REPORT / LIVE RECORDING",
                "ORIGINAL PACKAGE COPY • THUMBNAIL • MANIFEST • METADATA • SHA-256 COPY CHECK • CAPTION DRAFT • SOCIAL MASTER WHEN AVAILABLE • OPTIONAL ON-DEVICE TRANSCRIPT / SRT DRAFT",
                0xFF62D8C9.toInt()
            )
        )

        page.addView(
            launchCard(
                "V226 • STORY PACKAGES",
                "Open, share and transcribe completed report packages",
                "Each package is stored under Download/develop.uganda/Story Packages/<Package ID> • original Gallery video stays untouched • Interview/V211 can request on-device transcript automatically • any package can request transcript manually on Android 13+ when an on-device recognizer exists",
                0xFF62D8C9.toInt(),
                "OPEN STORY PACKAGES"
            ) {
                openIndependentCamera(
                    DevelopUgandaStoryPackagesActivity::class.java
                )
            }
        )

'''
    home = home.replace(photo_section, story_section + photo_section, 1)

HOME.write_text(home, encoding='utf-8')

# ------------------------------------------------------------------
# Manifest: package manager activity + SpeechRecognizer service query.
# ------------------------------------------------------------------
manifest = MANIFEST.read_text(encoding='utf-8')

if '<queries>' not in manifest:
    manifest = replace_once(
        manifest,
        '    <uses-feature android:name="android.hardware.microphone" android:required="false"/>\n\n',
        '''    <uses-feature android:name="android.hardware.microphone" android:required="false"/>

    <queries>
        <intent>
            <action android:name="android.speech.RecognitionService"/>
        </intent>
    </queries>

''',
        'SpeechRecognizer queries block'
    )

if '.DevelopUgandaStoryPackagesActivity' not in manifest:
    manifest = replace_once(
        manifest,
        '''        <activity
            android:name=".DevelopUgandaCameraActivity"
            android:screenOrientation="portrait"
            android:exported="false"/>
''',
        '''        <activity
            android:name=".DevelopUgandaStoryPackagesActivity"
            android:screenOrientation="portrait"
            android:exported="false"/>

        <activity
            android:name=".DevelopUgandaCameraActivity"
            android:screenOrientation="portrait"
            android:exported="false"/>
''',
        'Story Packages manifest activity'
    )

MANIFEST.write_text(manifest, encoding='utf-8')

# App version.
gradle = re.sub(r'versionCode\s*=\s*\d+', 'versionCode = 22600', gradle, count=1)
gradle = re.sub(
    r'versionName\s*=\s*"[^"]+"',
    'versionName = "226.0-auto-story-package"',
    gradle,
    count=1
)
GRADLE.write_text(gradle, encoding='utf-8')

print('V226 Auto Story Package applied.')
