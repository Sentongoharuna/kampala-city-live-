DEVELOP.UGANDA V270 PRO CAM • GUIDED WORKFLOW + VERIFIED ACTIONS
Version name: 270.0-guided-workflow-verified-actions
Version code: 27000

WHAT V270 CHANGES
- Core first-page workflow is now chronological: 1 PREPARE → 2 SHOOT → 3 DIRECT/MONITOR → 4 REVIEW/COLOR → 5 EDIT/DELIVER.
- Adds a live NEXT ACTION panel based on readiness, clip count, rating state and shot-list progress.
- Adds VERIFY ACTIONS: the installed app checks that the 27 main workflow Activity destinations actually exist before claiming navigation is available.
- Adds Action Guard so launcher buttons do not blindly open a missing destination.
- Adds small ⓘ touch-help to workflow cards and Pro Settings. Help explains WHAT IT DOES, HOW TO USE IT and the RESULT to expect.
- Adds first-use guided workflow coach (can be turned off).
- Adds Pro Settings controls for Guided Help, First-use Coach, Action Guard and Function Audit.
- Reorders Smart Story / Field Desk into numbered use steps and adds instructions inside each stage.
- Story take rating/tag/note controls are disabled until a real clip exists.
- Fixes legacy MainActivity LIVE and EDIT buttons so they open the real Live Studio and Editor instead of only showing placeholder messages.
- Converts old non-functional manual readout buttons in MainActivity to passive readouts so they no longer look actionable.
- Keeps established develop.uganda navy/cyan/gold interface and preserves V269/V265/V264/V263/V262 and earlier systems.

STATIC FUNCTION AUDIT
- 27/27 main launcher workflow routes are declared in AndroidManifest.xml.
- No empty setOnClickListener handlers found.
- V270 workflow guards are included in the GitHub Action before Android compilation.

IMPORTANT
The source audit can verify button wiring, navigation destinations, state guards and code references. Camera hardware, microphones, codecs, thermal behavior and Wi-Fi/multi-camera behavior still depend on the actual Android device and must be verified on real phones after the GitHub build succeeds.

BUILD
Upload V270-PRO-CAM.yml to:
.github/workflows/V270-PRO-CAM.yml
Commit the file. GitHub Actions will compile the APK and upload artifact:
DEVELOP-UGANDA-V270-PRO-CAM
