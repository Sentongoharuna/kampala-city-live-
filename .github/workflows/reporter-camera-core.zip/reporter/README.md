# Reporter — Camera Core (Android)

Stage 1 of the build: the capture spine. Everything downstream (autonomous
framing, live mode, telemetry, the analysis engine, the editor) hangs off the
pipeline defined here, so this layer is built to carry them rather than to be
replaced later.

## The one architectural rule

**The encoder never sees an overlay.**

    Camera2 ──▶ SurfaceTexture (OES) ──▶ GL "clean" FBO
                                            │
                              ┌─────────────┼─────────────┐
                              ▼             ▼             ▼
                       Encoder surface  Preview surface  Scope FBO
                       (clean master)   (+ monitoring)   (256×144 readback)

Focus peaking, zebras, false colour, the preview LUT, grids, horizon and every
status readout are applied on the branch that goes to the screen only. The file
written to disk is a clean master. That is what makes the mandatory
annotated/clean dual export possible later without re-rendering from a
degraded source, and it is why the pipeline is GL-based from the first commit
rather than using MediaRecorder.

The log tone curve is the one exception — it is baked, because it is a capture
decision, not a monitoring aid. It is applied in the pass that feeds both
branches.

## What is implemented

| Area | File | Notes |
|---|---|---|
| Device capability probe | `camera/CameraCapabilities.kt` | ISO/exposure ranges, 10-bit profiles, high-speed ranges, physical lenses |
| Shutter angle ⇄ exposure | `camera/ShutterAngle.kt` | angle-locked across frame-rate changes |
| Kelvin + tint white balance | `camera/WhiteBalance.kt` | Planckian locus → RGGB channel gains |
| Manual request building | `camera/CaptureController.kt` | ISO, exposure, WB, focus distance, AE lock, OIS/EIS, lens switch |
| Session lifecycle | `camera/CameraCore.kt` | standard + constrained-high-speed sessions |
| GL pipeline | `pipeline/GLRenderPipeline.kt` | OES → clean FBO → preview/encoder/scope branches |
| Monitoring shaders | `pipeline/Shaders.kt` | peaking, zebra, false colour, LUT, log curve, ND |
| Waveform + histogram | `pipeline/ScopeSampler.kt` | downsample + async readback on a worker |
| H.265 encoder | `record/VideoEncoder.kt` | independent fps/bitrate, all-I mode, HLG10 |
| Audio | `record/AudioEngine.kt` | UNPROCESSED source, manual gain, true dBFS metering |
| Timecode | `record/Timecode.kt` | SMPTE, drop-frame for 29.97/59.94 |
| Control surface | `ui/CameraScreen.kt` | one-thumb dark control bar, scopes, tally |

## What is honestly not there yet

- **RAW photo, night mode, timelapse, burst.** Stills share the Camera2 session
  but need their own request path; scaffolded in `CameraCore`, not written.
- **Headphone monitoring.** `AudioEngine` exposes the loopback hook. Android's
  round-trip latency makes true confidence monitoring device-dependent; on most
  handsets it lands at 40–120 ms, which is unusable for lip sync. Worth
  budgeting a USB-C audio interface path instead.
- **Horizon level** reads the rotation vector sensor — sensor plumbing is
  stubbed in `CameraState`.
- **Unit tests.** `ShutterAngle` and `WhiteBalance` are pure functions and are
  the two places worth testing first.

## Device constraints you should plan around

1. **240 fps means giving up manual control.** `CONSTRAINED_HIGH_SPEED_VIDEO`
   sessions accept at most two surfaces and reject most manual keys. The app
   handles this by switching session type and greying the manual bar — it
   cannot be worked around.
2. **10-bit HDR is Android 13+ and profile-gated.** `CameraCapabilities`
   probes `DynamicRangeProfiles`; devices without HLG10 fall back to 8-bit
   silently and the UI reflects it.
3. **There is no ProRes on Android.** The "ProRes-style" option is all-intra
   H.265 (`I_FRAME_INTERVAL = 0`) at a very high bitrate. It is edit-friendly
   and roughly comparable in handling, but it is not ProRes and the UI should
   not call it that.
4. **There is no physical ND.** ND simulation holds your shutter angle and
   pulls ISO to the sensor floor first; below that it applies a digital
   exposure offset in the GL pass, which costs highlight headroom. It is a
   convenience, not glass.
5. **Manual white balance needs `COLOR_CORRECTION_MODE_TRANSFORM_MATRIX`.**
   Setting gains alone while AWB is on is silently ignored on many devices.

## Build

    ./gradlew :app:assembleDebug

minSdk 29, targetSdk 35, Kotlin 2.0, Compose. The Gradle wrapper is not
included in this drop — run `gradle wrapper` once.
