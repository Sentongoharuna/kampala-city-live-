package ug.haruna.reporter.camera

import kotlin.math.roundToLong

/**
 * Shutter angle is the control cinematographers actually think in, because it is
 * frame-rate relative: 180 degrees looks the same at 24 fps and at 60 fps, while
 * 1/48s does not. Camera2 only speaks exposure time in nanoseconds, so the angle
 * is the user-facing value and the exposure is derived.
 *
 * The consequence worth understanding: when the operator changes frame rate we
 * hold the angle and recompute exposure, so the image keeps its motion
 * character. That is the opposite of what happens if you hold shutter speed.
 */
object ShutterAngle {

    /** Detents the control snaps to, matching what a cine operator expects. */
    val DETENTS = listOf(11.25, 22.5, 45.0, 90.0, 144.0, 172.8, 180.0, 270.0, 360.0)

    const val MIN_DEGREES = 5.0
    const val MAX_DEGREES = 360.0

    fun toExposureNs(degrees: Double, fps: Double): Long {
        require(fps > 0.0) { "fps must be positive" }
        val clamped = degrees.coerceIn(MIN_DEGREES, MAX_DEGREES)
        val frameNs = 1_000_000_000.0 / fps
        return (frameNs * (clamped / 360.0)).roundToLong()
    }

    fun fromExposureNs(exposureNs: Long, fps: Double): Double {
        val frameNs = 1_000_000_000.0 / fps
        return (exposureNs / frameNs) * 360.0
    }

    /**
     * The sensor's exposure range is a hard limit and it is narrower than the
     * angle range at high frame rates. Returns the exposure we will actually
     * request plus the angle that corresponds to it, so the UI can show the
     * operator the real value rather than the one they asked for.
     */
    fun resolve(degrees: Double, fps: Double, sensorRangeNs: ClosedRange<Long>): Resolved {
        val wanted = toExposureNs(degrees, fps)
        val actual = wanted.coerceIn(sensorRangeNs.start, sensorRangeNs.endInclusive)
        return Resolved(actual, fromExposureNs(actual, fps), actual != wanted)
    }

    /** Operators read "1/48" faster than "20833333 ns". */
    fun asFractionLabel(exposureNs: Long): String {
        if (exposureNs <= 0L) return "--"
        val denominator = (1_000_000_000.0 / exposureNs).roundToLong()
        return "1/$denominator"
    }

    data class Resolved(val exposureNs: Long, val actualDegrees: Double, val clamped: Boolean)
}
