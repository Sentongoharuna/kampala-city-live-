package ug.haruna.reporter.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import ug.haruna.reporter.camera.CameraCapabilities
import ug.haruna.reporter.camera.CameraCore
import ug.haruna.reporter.model.CameraState
import ug.haruna.reporter.pipeline.GLRenderPipeline
import ug.haruna.reporter.pipeline.ScopeSampler
import ug.haruna.reporter.record.AudioEngine
import ug.haruna.reporter.record.Timecode
import ug.haruna.reporter.record.VideoEncoder
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Wiring. Deliberately thin — everything with a decision in it lives in its own
 * class so that stage 2 can insert the framing layer between the pipeline and
 * the capture controller without touching this file.
 */
class CameraActivity : ComponentActivity() {

    private lateinit var core: CameraCore
    private lateinit var pipeline: GLRenderPipeline
    private val scopes = ScopeSampler()
    private var encoder: VideoEncoder? = null
    private var audio: AudioEngine? = null
    private var timecode = Timecode(25.0)

    private var state by mutableStateOf(CameraState())
    private var lenses: List<CameraCapabilities> = emptyList()

    private val permissions = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { granted ->
        if (granted[Manifest.permission.CAMERA] == true) bringUp()
        else state = state.copy(warnings = listOf("Camera permission denied"))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        core = CameraCore(this) { msg -> state = state.copy(warnings = listOf(msg)) }
        pipeline = GLRenderPipeline { buf, w, h -> scopes.submit(buf, w, h) }

        setContent {
            CameraScreen(
                state = state,
                scopes = scopes,
                onState = ::onStateChange,
                onRecordToggle = ::toggleRecording,
                onFocusTap = { x, y -> core.focusAt(state, x, y) },
                viewfinder = { modifier ->
                    AndroidView(modifier = modifier, factory = { ctx ->
                        SurfaceView(ctx).apply {
                            holder.addCallback(object : SurfaceHolder.Callback {
                                override fun surfaceCreated(h: SurfaceHolder) =
                                    pipeline.attachPreview(h.surface)
                                override fun surfaceChanged(
                                    h: SurfaceHolder, f: Int, w: Int, ht: Int) = Unit
                                override fun surfaceDestroyed(h: SurfaceHolder) = Unit
                            })
                        }
                    })
                }
            )
        }

        permissions.launch(arrayOf(
            Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.ACCESS_FINE_LOCATION
        ))
    }

    private fun bringUp() {
        lenses = core.availableLenses()
        val wide = lenses.firstOrNull { it.lensRole == CameraCapabilities.LensRole.WIDE }
            ?: lenses.firstOrNull() ?: return

        // Never offer what the sensor will not do.
        if (!wide.fullManual) {
            state = state.copy(
                autoExposure = true,
                autoWhiteBalance = true,
                warnings = listOf("Device lacks full manual sensor control")
            )
        }
        state = state.copy(tenBit = state.tenBit && wide.supportsHlg10)

        lifecycleScope.launch {
            core.open(wide)
            pipeline.start(state.resolution.width, state.resolution.height) {
                lifecycleScope.launch {
                    core.startSession(listOf(pipeline.cameraSurface), state)
                    pipeline.state = state
                    pipeline.ndResidualStops = core.residualNdStops()
                    refreshStorage()
                }
            }
        }
    }

    private fun onStateChange(next: CameraState) {
        state = next
        pipeline.state = next
        core.update(next)
        pipeline.ndResidualStops = core.residualNdStops()
    }

    private fun toggleRecording() {
        if (state.recording) stopRecording() else startRecording()
    }

    private fun startRecording() {
        val stamp = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())
        val dir = getExternalFilesDir(Environment.DIRECTORY_MOVIES)!!
        val file = File(dir, "REP_$stamp.mp4")

        val enc = VideoEncoder { msg -> state = state.copy(warnings = listOf(msg)) }
        val surface = enc.prepare(file, state)
        pipeline.attachEncoder(surface)
        enc.start()

        val aud = AudioEngine(
            encoder = enc,
            onLevel = { peak, _ -> state = state.copy(audioPeakDb = peak to peak) },
            onNotice = { msg -> state = state.copy(warnings = listOf(msg)) }
        ).also { it.gainDb = state.audioGainDb; it.start() }

        timecode = Timecode(state.frameRate).apply { start(System.nanoTime()) }
        encoder = enc; audio = aud
        state = state.copy(recording = true, warnings = emptyList())
    }

    private fun stopRecording() {
        audio?.release(); audio = null
        encoder?.stop(); encoder?.release(); encoder = null
        pipeline.attachEncoder(null)
        state = state.copy(recording = false)
        refreshStorage()
    }

    private fun refreshStorage() {
        val dir = getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: return
        val stat = StatFs(dir.absolutePath)
        val battery = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = battery?.getIntExtra("level", -1) ?: -1
        val scale = battery?.getIntExtra("scale", 100) ?: 100
        state = state.copy(
            storageRemainingBytes = stat.availableBytes,
            batteryPercent = if (level >= 0) level * 100 / scale else state.batteryPercent
        )
    }

    override fun onDestroy() {
        super.onDestroy()
        stopRecording()
        core.release()
        pipeline.release()
    }
}
