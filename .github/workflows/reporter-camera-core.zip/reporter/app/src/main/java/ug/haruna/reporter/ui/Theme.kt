package ug.haruna.reporter.ui

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.sp

/**
 * The brief fixes the direction: dark, dense, broadcast. So the palette is not a
 * style choice, it is a functional constraint — anything luminous on screen
 * contaminates the operator's read of the image, which is the only thing on the
 * display that is supposed to be judged.
 *
 * Hence: near-black chrome, one signal colour (tally red) reserved exclusively
 * for "you are rolling", and amber used only for states that need attention.
 * Nothing else gets to be saturated. If a control is coloured, it means
 * something.
 */
object Broadcast {
    val Black = Color(0xFF07090B)
    val Chrome = Color(0xFF12161A)
    val Rule = Color(0xFF232A31)
    val Text = Color(0xFFD6DDE3)
    val TextDim = Color(0xFF7A858F)
    val Tally = Color(0xFFE0231F)
    val Attention = Color(0xFFE8A33D)
    val Active = Color(0xFF4FB3A5)

    /** Monospaced, because readouts that change must not reflow as digits change. */
    val Mono = FontFamily.Monospace
    val ReadoutSize = 13.sp
    val LabelSize = 10.sp
}
