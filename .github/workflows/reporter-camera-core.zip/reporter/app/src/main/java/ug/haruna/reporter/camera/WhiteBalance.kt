package ug.haruna.reporter.camera

import android.hardware.camera2.params.ColorSpaceTransform
import android.hardware.camera2.params.RggbChannelVector
import kotlin.math.ln
import kotlin.math.pow

/**
 * Manual white balance in Kelvin plus green/magenta tint.
 *
 * Two things bite here and both fail silently:
 *
 *  1. Channel gains are ignored unless AWB is off AND colour correction mode is
 *     TRANSFORM_MATRIX. Set gains with AWB still running and most devices
 *     overwrite them on the next frame.
 *  2. Gains are multiplicative and relative. Normalising so the smallest gain is
 *     1.0 stops us adding gain we do not need, which would cost highlight
 *     headroom for nothing.
 */
object WhiteBalance {

    const val MIN_KELVIN = 2000
    const val MAX_KELVIN = 10000

    val PRESETS = linkedMapOf(
        "Tungsten" to 3200,
        "Fluorescent" to 4300,
        "Daylight" to 5600,
        "Cloudy" to 6500,
        "Shade" to 7500
    )

    /** Identity matrix as Camera2 rationals — 9 entries, each numerator/denominator. */
    val IDENTITY_TRANSFORM: ColorSpaceTransform = ColorSpaceTransform(
        intArrayOf(
            1, 1, 0, 1, 0, 1,
            0, 1, 1, 1, 0, 1,
            0, 1, 0, 1, 1, 1
        )
    )

    /**
     * @param kelvin colour temperature of the scene light being neutralised
     * @param tint green/magenta shift, -100 (green) .. +100 (magenta)
     */
    fun gains(kelvin: Int, tint: Int = 0): RggbChannelVector {
        val k = kelvin.coerceIn(MIN_KELVIN, MAX_KELVIN)
        val (r, g, b) = planckianRgb(k)

        var rGain = 1.0 / r
        var gGain = 1.0 / g
        var bGain = 1.0 / b

        // Positive tint = more magenta = less green.
        gGain *= 1.0 - (tint.coerceIn(-100, 100) / 100.0) * 0.35

        val floor = minOf(rGain, gGain, bGain)
        rGain /= floor; gGain /= floor; bGain /= floor

        // Even and odd green share the gain; splitting them is a lens-shading
        // concern, not a white balance one.
        return RggbChannelVector(rGain.toFloat(), gGain.toFloat(), gGain.toFloat(), bGain.toFloat())
    }

    /**
     * Approximation of the Planckian locus in linear RGB, valid 1000K–40000K and
     * accurate well within what anyone can judge on a phone screen.
     */
    private fun planckianRgb(kelvin: Int): Triple<Double, Double, Double> {
        val t = kelvin / 100.0

        val r = if (t <= 66.0) 1.0
        else (329.698727446 * (t - 60).pow(-0.1332047592) / 255.0).coerceIn(0.0, 1.0)

        val g = if (t <= 66.0)
            ((99.4708025861 * ln(t) - 161.1195681661) / 255.0).coerceIn(0.0, 1.0)
        else
            (288.1221695283 * (t - 60).pow(-0.0755148492) / 255.0).coerceIn(0.0, 1.0)

        val b = when {
            t >= 66.0 -> 1.0
            t <= 19.0 -> 0.0
            else -> ((138.5177312231 * ln(t - 10) - 305.0447927307) / 255.0).coerceIn(0.0, 1.0)
        }

        return Triple(r.coerceAtLeast(1e-4), g.coerceAtLeast(1e-4), b.coerceAtLeast(1e-4))
    }
}
