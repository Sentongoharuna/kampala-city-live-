package ug.haruna.reporter.record

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaRecorder
import android.os.Handler
import android.os.HandlerThread
import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.pow

/**
 * Audio capture, gain and metering.
 *
 * The source matters more than anything else here. VOICE_RECOGNITION and
 * CAMCORDER both run vendor processing — AGC, noise suppression, sometimes a
 * high-pass at 200 Hz — that ruins an interview recording and cannot be undone.
 * UNPROCESSED gives the raw path where the device supports it; where it does
 * not, we fall back and say so in the UI rather than pretending.
 *
 * Meters are true peak and RMS in dBFS, not a normalised bar. An operator
 * setting gain needs to know they are at -12 dBFS, not that the bar is
 * two-thirds full.
 */
class AudioEngine(
    private val encoder: VideoEncoder,
    private val onLevel: (peakDb: Float, rmsDb: Float) -> Unit,
    private val onNotice: (String) -> Unit
) {
    private var record: AudioRecord? = null
    private var codec: MediaCodec? = null
    private val thread = HandlerThread("audio").apply { start() }
    private val handler = Handler(thread.looper)

    @Volatile private var running = false
    @Volatile var gainDb: Float = 0f

    /** Set false when UNPROCESSED is unavailable, so the UI can say the path is processed. */
    var rawPath = true
        private set

    @SuppressLint("MissingPermission")
    fun start() {
        val minBuf = AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNEL_CONFIG, ENCODING)
        val bufSize = maxOf(minBuf * 4, SAMPLE_RATE / 4 * 2 * 2)

        var r = AudioRecord(
            MediaRecorder.AudioSource.UNPROCESSED,
            SAMPLE_RATE, CHANNEL_CONFIG, ENCODING, bufSize
        )
        if (r.state != AudioRecord.STATE_INITIALIZED) {
            r.release()
            rawPath = false
            onNotice("Unprocessed audio unavailable — device processing is active")
            r = AudioRecord(
                MediaRecorder.AudioSource.CAMCORDER,
                SAMPLE_RATE, CHANNEL_CONFIG, ENCODING, bufSize
            )
        }
        record = r

        val format = MediaFormat.createAudioFormat(
            MediaFormat.MIMETYPE_AUDIO_AAC, SAMPLE_RATE, 2
        ).apply {
            setInteger(MediaFormat.KEY_AAC_PROFILE,
                MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            setInteger(MediaFormat.KEY_BIT_RATE, 256_000)
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, bufSize)
        }
        val c = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
        c.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        codec = c

        r.startRecording()
        c.start()
        running = true
        handler.post { captureLoop(bufSize) }
        handler.post { drainLoop() }
    }

    private fun captureLoop(bufSize: Int) {
        val r = record ?: return
        val c = codec ?: return
        val pcm = ShortArray(bufSize / 2)

        while (running) {
            val n = r.read(pcm, 0, pcm.size)
            if (n <= 0) continue

            val linearGain = 10.0.pow(gainDb / 20.0).toFloat()
            var peak = 0
            var sumSquares = 0.0

            for (i in 0 until n) {
                var v = (pcm[i] * linearGain).toInt()
                // Hard clip at full scale. Soft clipping would hide the fact that
                // the operator has overdriven the gain, which is the one thing
                // they need to see.
                if (v > 32767) v = 32767
                if (v < -32768) v = -32768
                pcm[i] = v.toShort()
                val a = abs(v)
                if (a > peak) peak = a
                sumSquares += v.toDouble() * v
            }

            onLevel(toDbfs(peak / 32768.0), toDbfs(Math.sqrt(sumSquares / n) / 32768.0))

            val index = c.dequeueInputBuffer(TIMEOUT_US)
            if (index >= 0) {
                val buf = c.getInputBuffer(index) ?: continue
                buf.clear()
                buf.asShortBuffer().put(pcm, 0, n)
                c.queueInputBuffer(index, 0, n * 2, System.nanoTime() / 1000, 0)
            }
        }
    }

    private fun drainLoop() {
        val c = codec ?: return
        val info = MediaCodec.BufferInfo()
        while (running) {
            when (val index = c.dequeueOutputBuffer(info, TIMEOUT_US)) {
                MediaCodec.INFO_TRY_AGAIN_LATER -> Unit
                MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> encoder.addAudioTrack(c.outputFormat)
                else -> if (index >= 0) {
                    val buf = c.getOutputBuffer(index)
                    if (buf != null && info.size > 0 &&
                        (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0
                    ) {
                        encoder.writeAudio(buf, info)
                    }
                    c.releaseOutputBuffer(index, false)
                }
            }
        }
    }

    private fun toDbfs(normalised: Double): Float =
        if (normalised <= 1e-6) -96f else (20.0 * log10(normalised)).toFloat().coerceAtLeast(-96f)

    fun stop() {
        running = false
        runCatching { record?.stop(); record?.release() }
        runCatching { codec?.stop(); codec?.release() }
        record = null; codec = null
    }

    fun release() { stop(); thread.quitSafely() }

    private companion object {
        const val SAMPLE_RATE = 48_000
        const val CHANNEL_CONFIG = AudioFormat.CHANNEL_IN_STEREO
        const val ENCODING = AudioFormat.ENCODING_PCM_16BIT
        const val TIMEOUT_US = 10_000L
    }
}
