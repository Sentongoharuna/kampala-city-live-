package ug.haruna.reporter.camera

import android.content.Context
import android.graphics.ImageFormat
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.params.DynamicRangeProfiles
import android.os.Build
import android.util.Range
import android.util.Size

/**
 * Everything the UI is allowed to offer has to come from here. Android camera
 * hardware is uneven, and the difference between a pro tool and a toy is that a
 * pro tool never shows a control the sensor will not honour.
 */
data class CameraCapabilities(
    val cameraId: String,
    val facing: Int,
    val focalLengthMm: Float,
    val lensRole: LensRole,
    val supportsManualSensor: Boolean,
    val supportsManualPostProcessing: Boolean,
    val supportsRaw: Boolean,
    val isoRange: Range<Int>,
    val exposureRangeNs: Range<Long>,
    val minFocusDistanceDiopters: Float,
    val videoSizes: List<Size>,
    val fpsRanges: List<Range<Int>>,
    val highSpeed: List<HighSpeedMode>,
    val tenBitProfiles: Set<Long>,
    val hasOis: Boolean,
    val sensorOrientation: Int
) {
    val supportsHlg10: Boolean
        get() = DynamicRangeProfiles.HLG10 in tenBitProfiles

    /** True manual needs both sensor and post-processing control. */
    val fullManual: Boolean
        get() = supportsManualSensor && supportsManualPostProcessing

    enum class LensRole { ULTRA_WIDE, WIDE, TELE, UNKNOWN }

    data class HighSpeedMode(val size: Size, val fps: Int)

    companion object {

        fun probeAll(context: Context): List<CameraCapabilities> {
            val mgr = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            return mgr.cameraIdList
                .mapNotNull { id -> runCatching { probe(mgr, id) }.getOrNull() }
        }

        private fun probe(mgr: CameraManager, id: String): CameraCapabilities {
            val c = mgr.getCameraCharacteristics(id)
            val caps = (c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)
                ?: IntArray(0)).toList()
            val map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)

            val focal = (c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)
                ?: floatArrayOf(0f)).first()

            val highSpeed = buildList {
                map?.highSpeedVideoSizes?.forEach { size ->
                    map.getHighSpeedVideoFpsRangesFor(size).forEach { r ->
                        if (r.upper >= 120) add(HighSpeedMode(size, r.upper))
                    }
                }
            }.distinct().sortedByDescending { it.fps }

            val profiles: Set<Long> =
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    c.get(CameraCharacteristics.REQUEST_AVAILABLE_DYNAMIC_RANGE_PROFILES)
                        ?.supportedProfiles ?: emptySet()
                } else emptySet()

            return CameraCapabilities(
                cameraId = id,
                facing = c.get(CameraCharacteristics.LENS_FACING) ?: -1,
                focalLengthMm = focal,
                lensRole = LensRole.UNKNOWN, // LensSet assigns this once the group is known
                supportsManualSensor =
                    CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_SENSOR in caps,
                supportsManualPostProcessing =
                    CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_POST_PROCESSING in caps,
                supportsRaw =
                    CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_RAW in caps,
                isoRange = c.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)
                    ?: Range(100, 800),
                exposureRangeNs = c.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)
                    ?: Range(100_000L, 100_000_000L),
                minFocusDistanceDiopters =
                    c.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f,
                videoSizes = map?.getOutputSizes(ImageFormat.PRIVATE)?.toList().orEmpty()
                    .sortedByDescending { it.width.toLong() * it.height },
                fpsRanges = c.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)
                    ?.toList().orEmpty(),
                highSpeed = highSpeed,
                tenBitProfiles = profiles,
                hasOis = (c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION)
                    ?: IntArray(0)).any { it == 1 },
                sensorOrientation = c.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 0
            )
        }
    }
}

/**
 * Assigns ultra-wide / wide / tele by focal length rather than by camera id,
 * because id ordering means nothing across vendors. Shortest back lens is the
 * ultra-wide, longest is the tele, everything between is treated as wide.
 */
object LensSet {
    fun classifyBack(all: List<CameraCapabilities>): List<CameraCapabilities> {
        val back = all.filter { it.facing == CameraCharacteristics.LENS_FACING_BACK }
        if (back.size <= 1) return back.map { it.copy(lensRole = CameraCapabilities.LensRole.WIDE) }
        val sorted = back.sortedBy { it.focalLengthMm }
        return sorted.mapIndexed { i, cap ->
            cap.copy(
                lensRole = when (i) {
                    0 -> CameraCapabilities.LensRole.ULTRA_WIDE
                    sorted.lastIndex -> CameraCapabilities.LensRole.TELE
                    else -> CameraCapabilities.LensRole.WIDE
                }
            )
        }
    }
}
