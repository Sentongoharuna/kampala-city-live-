package ug.haruna.reporter.record

import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.os.Handler
import android.os.HandlerThread
import android.view.Surface
import ug.haruna.reporter.model.CameraState
import java.io.File

/**
 * H.265 surface encoder, writing the clean master.
 *
 * Two things the spec asked for that are worth spelling out:
 *
 *   Independent frame rate and bitrate. MediaCodec derives a default bitrate
 *   from resolution and frame rate if you let it; we never do. KEY_BIT_RATE is
 *   set explicitly and KEY_BITRATE_MODE is CBR, because VBR on a phone encoder
 *   throws away exactly the frames you care about — fast pans and crowds.
 *
 *   The "ProRes-style" option. Android has no ProRes encoder. What it has is
 *   all-intra H.265: KEY_I_FRAME_INTERVAL = 0 makes every frame a keyframe, so
 *   the file scrubs and cuts like an intermediate codec. At 4K60 that wants
 *   300–400 Mbps and it will fill storage fast, which is why the UI shows
 *   remaining record time rather than remaining gigabytes.
 */
class VideoEncoder(
    private val onError: (String) -> Unit
) {
    private var codec: MediaCodec? = null
    private var muxer: MediaMuxer? = null
    private var videoTrack = -1
    private var audioTrack = -1
    private var muxerStarted = false

    private val thread = HandlerThread("encoder").apply { start() }
    private val handler = Handler(thread.looper)

    private val bufferInfo = MediaCodec.BufferInfo()
    @Volatile private var running = false

    var inputSurface: Surface? = null
        private set

    var outputFile: File? = null
        private set

    fun prepare(file: File, state: CameraState): Surface {
        outputFile = file

        val format = MediaFormat.createVideoFormat(
            MediaFormat.MIMETYPE_VIDEO_HEVC,
            state.resolution.width,
            state.resolution.height
        ).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT,
                MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, state.bitrateMbps * 1_000_000)
            setInteger(MediaFormat.KEY_BITRATE_MODE,
                MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_CBR)
            setFloat(MediaFormat.KEY_FRAME_RATE, state.frameRate.toFloat())

            when (state.codec) {
                CameraState.Codec.H265_ALL_I -> {
                    setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 0)
                    setInteger(MediaFormat.KEY_LATENCY, 0)
                }
                CameraState.Codec.H265_HIGH ->
                    setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            }

            if (state.tenBit) {
                setInteger(MediaFormat.KEY_PROFILE,
                    MediaCodecInfo.CodecProfileLevel.HEVCProfileMain10HDR10)
                setInteger(MediaFormat.KEY_COLOR_STANDARD,
                    MediaFormat.COLOR_STANDARD_BT2020)
                setInteger(MediaFormat.KEY_COLOR_TRANSFER,
                    MediaFormat.COLOR_TRANSFER_HLG)
                setInteger(MediaFormat.KEY_COLOR_RANGE, MediaFormat.COLOR_RANGE_LIMITED)
            }
        }

        val c = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_HEVC)
        c.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        val surface = c.createInputSurface()
        codec = c
        inputSurface = surface

        muxer = MediaMuxer(file.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        return surface
    }

    fun start() {
        val c = codec ?: return
        c.start()
        running = true
        handler.post { drainLoop() }
    }

    /** Audio track is added by AudioEngine before the muxer can start. */
    @Synchronized
    fun addAudioTrack(format: MediaFormat): Int {
        audioTrack = muxer?.addTrack(format) ?: -1
        maybeStartMuxer()
        return audioTrack
    }

    @Synchronized
    fun writeAudio(buffer: java.nio.ByteBuffer, info: MediaCodec.BufferInfo) {
        if (muxerStarted && audioTrack >= 0) muxer?.writeSampleData(audioTrack, buffer, info)
    }

    @Synchronized
    private fun maybeStartMuxer() {
        if (!muxerStarted && videoTrack >= 0 && audioTrack >= 0) {
            muxer?.start()
            muxerStarted = true
        }
    }

    private fun drainLoop() {
        val c = codec ?: return
        while (running) {
            when (val index = c.dequeueOutputBuffer(bufferInfo, TIMEOUT_US)) {
                MediaCodec.INFO_TRY_AGAIN_LATER -> Unit
                MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> synchronized(this) {
                    videoTrack = muxer?.addTrack(c.outputFormat) ?: -1
                    maybeStartMuxer()
                }
                else -> if (index >= 0) {
                    val buf = c.getOutputBuffer(index)
                    if (buf != null && bufferInfo.size > 0 && muxerStarted &&
                        (bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0
                    ) {
                        buf.position(bufferInfo.offset)
                        buf.limit(bufferInfo.offset + bufferInfo.size)
                        synchronized(this) { muxer?.writeSampleData(videoTrack, buf, bufferInfo) }
                    }
                    c.releaseOutputBuffer(index, false)
                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        running = false
                    }
                }
            }
        }
        finish()
    }

    fun stop() {
        if (!running) return
        runCatching { codec?.signalEndOfInputStream() }
            .onFailure { running = false }
    }

    private fun finish() {
        runCatching { codec?.stop(); codec?.release() }
        runCatching { if (muxerStarted) muxer?.stop(); muxer?.release() }
            .onFailure { onError("Muxer failed to close — file may be truncated") }
        codec = null; muxer = null; muxerStarted = false
        videoTrack = -1; audioTrack = -1
        inputSurface?.release(); inputSurface = null
    }

    fun release() {
        stop()
        thread.quitSafely()
    }

    private companion object { const val TIMEOUT_US = 10_000L }
}
