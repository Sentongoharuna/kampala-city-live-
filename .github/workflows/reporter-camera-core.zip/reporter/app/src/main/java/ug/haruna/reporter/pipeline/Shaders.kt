package ug.haruna.reporter.pipeline

/**
 * Two fragment programs, and the split between them is the whole architecture.
 *
 *   CAPTURE_FS  runs once, into the clean FBO. Whatever it does ends up in the
 *               file: the log tone curve and the ND digital offset, and nothing
 *               else, because those are capture decisions.
 *
 *   MONITOR_FS  runs on the way to the screen only. Peaking, zebras, false
 *               colour and the preview LUT live here and can never be recorded
 *               by accident, because the encoder branch does not run this
 *               program at all.
 */
object Shaders {

    const val VERTEX = """#version 300 es
        in vec4 aPosition;
        in vec2 aTexCoord;
        uniform mat4 uTexMatrix;
        out vec2 vTexCoord;
        void main() {
            gl_Position = aPosition;
            vTexCoord = (uTexMatrix * vec4(aTexCoord, 0.0, 1.0)).xy;
        }
    """

    /** OES external sampler → clean linearised/graded output. */
    const val CAPTURE_FS = """#version 300 es
        #extension GL_OES_EGL_image_external_essl3 : require
        precision highp float;

        uniform samplerExternalOES uTexture;
        uniform float uNdStops;     // digital exposure offset, ND simulation remainder
        uniform float uLogEnabled;  // 0 or 1

        in vec2 vTexCoord;
        out vec4 fragColor;

        vec3 srgbToLinear(vec3 c) {
            return mix(c / 12.92, pow((c + 0.055) / 1.055, vec3(2.4)), step(0.04045, c));
        }
        vec3 linearToSrgb(vec3 c) {
            return mix(c * 12.92, 1.055 * pow(c, vec3(1.0 / 2.4)) - 0.055, step(0.0031308, c));
        }

        // Cineon-style log encode. The sensor hands us display-gamma pixels, not
        // true sensor linear, so this is a flat *profile* rather than genuine log
        // — it preserves grading latitude in the mids but cannot recover
        // highlights the ISP already clipped. Shooting real log on Android needs
        // the RAW path.
        vec3 logEncode(vec3 lin) {
            vec3 c = max(lin, vec3(1e-5));
            return clamp((log2(c * 6.0 + 0.0104) + 7.5) / 11.5, 0.0, 1.0);
        }

        void main() {
            vec3 c = srgbToLinear(texture(uTexture, vTexCoord).rgb);
            c *= exp2(-uNdStops);
            vec3 outRgb = (uLogEnabled > 0.5) ? logEncode(c) : linearToSrgb(c);
            fragColor = vec4(outRgb, 1.0);
        }
    """

    /** Clean texture → screen, with every monitoring aid layered on. */
    const val MONITOR_FS = """#version 300 es
        precision highp float;

        uniform sampler2D uTexture;
        uniform sampler2D uLut;         // 33^3 LUT packed as a 1089x33 strip
        uniform vec2  uTexelSize;
        uniform float uPeaking;         // 0 or 1
        uniform float uPeakThreshold;
        uniform vec3  uPeakColour;
        uniform float uZebra;
        uniform float uZebraLevel;
        uniform float uFalseColour;
        uniform float uLut3d;

        in vec2 vTexCoord;
        out vec4 fragColor;

        float luma(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }

        // Sobel on luma. Cheaper edge detectors drift with noise at high ISO,
        // which is exactly when an operator is leaning on peaking hardest.
        float edgeStrength(vec2 uv) {
            float tl = luma(texture(uTexture, uv + uTexelSize * vec2(-1.0, -1.0)).rgb);
            float t  = luma(texture(uTexture, uv + uTexelSize * vec2( 0.0, -1.0)).rgb);
            float tr = luma(texture(uTexture, uv + uTexelSize * vec2( 1.0, -1.0)).rgb);
            float l  = luma(texture(uTexture, uv + uTexelSize * vec2(-1.0,  0.0)).rgb);
            float r  = luma(texture(uTexture, uv + uTexelSize * vec2( 1.0,  0.0)).rgb);
            float bl = luma(texture(uTexture, uv + uTexelSize * vec2(-1.0,  1.0)).rgb);
            float b  = luma(texture(uTexture, uv + uTexelSize * vec2( 0.0,  1.0)).rgb);
            float br = luma(texture(uTexture, uv + uTexelSize * vec2( 1.0,  1.0)).rgb);
            float gx = (tr + 2.0 * r + br) - (tl + 2.0 * l + bl);
            float gy = (bl + 2.0 * b + br) - (tl + 2.0 * t + tr);
            return sqrt(gx * gx + gy * gy);
        }

        // ARRI-style exposure map. The two bands that matter in the field are
        // pink for skin at around 55 IRE and green for 18% grey at 42.
        vec3 falseColour(float y) {
            if (y < 0.025) return vec3(0.44, 0.16, 0.63);   // black clip
            if (y < 0.08)  return vec3(0.12, 0.30, 0.85);   // shadow detail
            if (y < 0.38)  return vec3(0.32, 0.32, 0.32);   // low mids
            if (y < 0.46)  return vec3(0.16, 0.78, 0.28);   // 18% grey
            if (y < 0.52)  return vec3(0.58, 0.58, 0.58);   // high mids
            if (y < 0.60)  return vec3(0.98, 0.60, 0.72);   // skin
            if (y < 0.92)  return vec3(0.80, 0.80, 0.80);
            if (y < 0.99)  return vec3(0.98, 0.85, 0.20);   // near clip
            return vec3(0.92, 0.13, 0.13);                  // clipped
        }

        vec3 sampleLut(vec3 c) {
            const float N = 33.0;
            float bC = c.b * (N - 1.0);
            float b0 = floor(bC);
            float b1 = min(b0 + 1.0, N - 1.0);
            float f  = bC - b0;
            vec2 uvBase = vec2(c.r * (N - 1.0) + 0.5, c.g * (N - 1.0) + 0.5) / vec2(N * N, N);
            vec3 s0 = texture(uLut, uvBase + vec2(b0 * N / (N * N), 0.0)).rgb;
            vec3 s1 = texture(uLut, uvBase + vec2(b1 * N / (N * N), 0.0)).rgb;
            return mix(s0, s1, f);
        }

        void main() {
            vec3 c = texture(uTexture, vTexCoord).rgb;
            float y = luma(c);

            if (uLut3d > 0.5) { c = sampleLut(clamp(c, 0.0, 1.0)); }

            if (uFalseColour > 0.5) {
                fragColor = vec4(falseColour(y), 1.0);
                return;
            }

            if (uZebra > 0.5 && y >= uZebraLevel) {
                float stripe = step(0.5, fract((gl_FragCoord.x + gl_FragCoord.y) / 12.0));
                c = mix(c, vec3(stripe), 0.85);
            }

            if (uPeaking > 0.5) {
                float e = edgeStrength(vTexCoord);
                c = mix(c, uPeakColour, smoothstep(uPeakThreshold, uPeakThreshold * 1.6, e));
            }

            fragColor = vec4(c, 1.0);
        }
    """

    /** Straight blit — clean FBO to the encoder surface and to the scope FBO. */
    const val BLIT_FS = """#version 300 es
        precision mediump float;
        uniform sampler2D uTexture;
        in vec2 vTexCoord;
        out vec4 fragColor;
        void main() { fragColor = texture(uTexture, vTexCoord); }
    """
}
