package ug.haruna.reporter.pipeline

import android.graphics.SurfaceTexture
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLExt
import android.opengl.EGLSurface
import android.opengl.GLES11Ext
import android.opengl.GLES30
import android.os.Handler
import android.os.HandlerThread
import android.view.Surface
import ug.haruna.reporter.model.CameraState
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer

/**
 * The render graph.
 *
 *   OES (camera)
 *      └─ CAPTURE pass  ──▶ clean FBO
 *                            ├─ BLIT  ──▶ encoder surface   (recorded, no overlays)
 *                            ├─ MONITOR ▶ preview surface   (peaking/zebra/false colour/LUT)
 *                            └─ BLIT  ──▶ 256×144 scope FBO ──▶ async readback
 *
 * One EGL context, one GL thread, three window surfaces. The encoder branch runs
 * before the monitor branch so that a slow preview can never delay a recorded
 * frame — if the GPU falls behind, the screen tears, the file does not.
 */
class GLRenderPipeline(
    private val onScopeFrame: (ByteArray, Int, Int) -> Unit
) {
    private val thread = HandlerThread("gl-pipeline").apply { start() }
    val handler = Handler(thread.looper)

    private var display: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var context: EGLContext = EGL14.EGL_NO_CONTEXT
    private var config: EGLConfig? = null

    private var previewSurface: EGLSurface? = null
    private var encoderSurface: EGLSurface? = null
    private var pbuffer: EGLSurface? = null

    private var oesTexture = 0
    private var cleanTexture = 0
    private var cleanFbo = 0
    private var scopeTexture = 0
    private var scopeFbo = 0
    private var lutTexture = 0

    private var captureProgram = 0
    private var monitorProgram = 0
    private var blitProgram = 0

    lateinit var surfaceTexture: SurfaceTexture
        private set
    lateinit var cameraSurface: Surface
        private set

    private var width = 1920
    private var height = 1080
    private val texMatrix = FloatArray(16)

    private var frameCount = 0L
    var state: CameraState = CameraState()
    var ndResidualStops: Float = 0f

    private val quad: FloatBuffer = ByteBuffer
        .allocateDirect(16 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
            put(floatArrayOf(
                -1f, -1f, 0f, 0f,
                 1f, -1f, 1f, 0f,
                -1f,  1f, 0f, 1f,
                 1f,  1f, 1f, 1f
            ))
            position(0)
        }

    // ---------------------------------------------------------------- setup

    fun start(captureWidth: Int, captureHeight: Int, onReady: () -> Unit) {
        width = captureWidth; height = captureHeight
        handler.post {
            initEgl()
            initGl()
            onReady()
        }
    }

    private fun initEgl() {
        display = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        EGL14.eglInitialize(display, IntArray(1), 0, IntArray(1), 0)

        val attribs = intArrayOf(
            EGL14.EGL_RED_SIZE, 8,
            EGL14.EGL_GREEN_SIZE, 8,
            EGL14.EGL_BLUE_SIZE, 8,
            EGL14.EGL_ALPHA_SIZE, 8,
            EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
            EGLExt.EGL_RECORDABLE_ANDROID, 1,
            EGL14.EGL_NONE
        )
        val configs = arrayOfNulls<EGLConfig>(1)
        EGL14.eglChooseConfig(display, attribs, 0, configs, 0, 1, IntArray(1), 0)
        config = configs[0]

        context = EGL14.eglCreateContext(
            display, config, EGL14.EGL_NO_CONTEXT,
            intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 3, EGL14.EGL_NONE), 0
        )
        pbuffer = EGL14.eglCreatePbufferSurface(
            display, config, intArrayOf(EGL14.EGL_WIDTH, 1, EGL14.EGL_HEIGHT, 1, EGL14.EGL_NONE), 0
        )
        EGL14.eglMakeCurrent(display, pbuffer, pbuffer, context)
    }

    private fun initGl() {
        captureProgram = Gl.program(Shaders.VERTEX, Shaders.CAPTURE_FS)
        monitorProgram = Gl.program(Shaders.VERTEX, Shaders.MONITOR_FS)
        blitProgram = Gl.program(Shaders.VERTEX, Shaders.BLIT_FS)

        oesTexture = Gl.createExternalTexture()
        val (ct, cf) = Gl.createFbo(width, height)
        cleanTexture = ct; cleanFbo = cf
        val (st, sf) = Gl.createFbo(SCOPE_W, SCOPE_H)
        scopeTexture = st; scopeFbo = sf
        lutTexture = Gl.createEmpty2d(33 * 33, 33)

        surfaceTexture = SurfaceTexture(oesTexture).apply {
            setDefaultBufferSize(width, height)
            setOnFrameAvailableListener({ handler.post { drawFrame() } }, handler)
        }
        cameraSurface = Surface(surfaceTexture)
    }

    fun attachPreview(surface: Surface) = handler.post {
        previewSurface = EGL14.eglCreateWindowSurface(
            display, config, surface, intArrayOf(EGL14.EGL_NONE), 0)
    }

    fun attachEncoder(surface: Surface?) = handler.post {
        encoderSurface?.let { EGL14.eglDestroySurface(display, it) }
        encoderSurface = surface?.let {
            EGL14.eglCreateWindowSurface(display, config, it, intArrayOf(EGL14.EGL_NONE), 0)
        }
    }

    /** Upload a 33³ LUT flattened to RGB bytes, row-major, blue slices left to right. */
    fun uploadLut(rgb: ByteArray) = handler.post {
        Gl.upload2d(lutTexture, 33 * 33, 33, rgb)
    }

    // ---------------------------------------------------------------- draw

    private fun drawFrame() {
        surfaceTexture.updateTexImage()
        surfaceTexture.getTransformMatrix(texMatrix)
        val timestampNs = surfaceTexture.timestamp

        // 1. Capture pass into the clean FBO. This is the only pass whose output
        //    reaches the file.
        EGL14.eglMakeCurrent(display, pbuffer, pbuffer, context)
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, cleanFbo)
        GLES30.glViewport(0, 0, width, height)
        GLES30.glUseProgram(captureProgram)
        Gl.bindQuad(captureProgram, quad)
        Gl.setMatrix(captureProgram, "uTexMatrix", texMatrix)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, oesTexture)
        Gl.uniform1i(captureProgram, "uTexture", 0)
        Gl.uniform1f(captureProgram, "uNdStops", ndResidualStops)
        Gl.uniform1f(captureProgram, "uLogEnabled", if (state.logProfile) 1f else 0f)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, 0, 4)
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)

        // 2. Encoder branch first — a stalled preview must never cost a frame.
        encoderSurface?.let { es ->
            EGL14.eglMakeCurrent(display, es, es, context)
            GLES30.glViewport(0, 0, width, height)
            blit(cleanTexture)
            EGLExt.eglPresentationTimeANDROID(display, es, timestampNs)
            EGL14.eglSwapBuffers(display, es)
        }

        // 3. Preview branch, with the monitoring aids.
        previewSurface?.let { ps ->
            EGL14.eglMakeCurrent(display, ps, ps, context)
            GLES30.glViewport(0, 0, width, height)
            drawMonitor()
            EGL14.eglSwapBuffers(display, ps)
        }

        // 4. Scopes, downsampled. Reading back the full frame would stall the
        //    pipeline; 256x144 is enough to build an accurate waveform and costs
        //    about 110 KB per sample.
        if ((state.monitoring.waveform || state.monitoring.histogram) && frameCount % 3L == 0L) {
            sampleScopes()
        }
        frameCount++
    }

    private fun drawMonitor() {
        val m = state.monitoring
        GLES30.glUseProgram(monitorProgram)
        Gl.bindQuad(monitorProgram, quad)
        Gl.setMatrix(monitorProgram, "uTexMatrix", IDENTITY)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, cleanTexture)
        Gl.uniform1i(monitorProgram, "uTexture", 0)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE1)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, lutTexture)
        Gl.uniform1i(monitorProgram, "uLut", 1)
        Gl.uniform2f(monitorProgram, "uTexelSize", 1f / width, 1f / height)
        Gl.uniform1f(monitorProgram, "uPeaking", if (m.focusPeaking) 1f else 0f)
        Gl.uniform1f(monitorProgram, "uPeakThreshold", m.peakingThreshold)
        val pc = when (m.peakingColour) {
            CameraState.Monitoring.PeakColour.RED -> floatArrayOf(1f, 0.1f, 0.1f)
            CameraState.Monitoring.PeakColour.GREEN -> floatArrayOf(0.1f, 1f, 0.2f)
            CameraState.Monitoring.PeakColour.BLUE -> floatArrayOf(0.2f, 0.5f, 1f)
            CameraState.Monitoring.PeakColour.WHITE -> floatArrayOf(1f, 1f, 1f)
        }
        Gl.uniform3f(monitorProgram, "uPeakColour", pc[0], pc[1], pc[2])
        Gl.uniform1f(monitorProgram, "uZebra", if (m.zebra) 1f else 0f)
        Gl.uniform1f(monitorProgram, "uZebraLevel", m.zebraIre)
        Gl.uniform1f(monitorProgram, "uFalseColour", if (m.falseColour) 1f else 0f)
        Gl.uniform1f(monitorProgram, "uLut3d", if (m.previewLut) 1f else 0f)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, 0, 4)
    }

    private fun blit(texture: Int) {
        GLES30.glUseProgram(blitProgram)
        Gl.bindQuad(blitProgram, quad)
        Gl.setMatrix(blitProgram, "uTexMatrix", IDENTITY)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, texture)
        Gl.uniform1i(blitProgram, "uTexture", 0)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, 0, 4)
    }

    private val scopeBuf: ByteBuffer =
        ByteBuffer.allocateDirect(SCOPE_W * SCOPE_H * 4).order(ByteOrder.nativeOrder())

    private fun sampleScopes() {
        EGL14.eglMakeCurrent(display, pbuffer, pbuffer, context)
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, scopeFbo)
        GLES30.glViewport(0, 0, SCOPE_W, SCOPE_H)
        blit(cleanTexture)
        scopeBuf.rewind()
        GLES30.glReadPixels(0, 0, SCOPE_W, SCOPE_H,
            GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, scopeBuf)
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
        val copy = ByteArray(SCOPE_W * SCOPE_H * 4)
        scopeBuf.rewind(); scopeBuf.get(copy)
        onScopeFrame(copy, SCOPE_W, SCOPE_H)
    }

    fun release() = handler.post {
        EGL14.eglMakeCurrent(display, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE,
            EGL14.EGL_NO_CONTEXT)
        listOfNotNull(previewSurface, encoderSurface, pbuffer)
            .forEach { EGL14.eglDestroySurface(display, it) }
        EGL14.eglDestroyContext(display, context)
        EGL14.eglTerminate(display)
        surfaceTexture.release()
        cameraSurface.release()
        thread.quitSafely()
    }

    companion object {
        const val SCOPE_W = 256
        const val SCOPE_H = 144
        private val IDENTITY = floatArrayOf(
            1f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f)
    }
}
