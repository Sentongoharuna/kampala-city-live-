package ug.haruna.reporter.camera

import android.annotation.SuppressLint
import android.content.Context
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraConstrainedHighSpeedCaptureSession
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.TotalCaptureResult
import android.hardware.camera2.params.DynamicRangeProfiles
import android.hardware.camera2.params.OutputConfiguration
import android.hardware.camera2.params.SessionConfiguration
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import android.view.Surface
import ug.haruna.reporter.model.CameraState
import java.util.concurrent.Executor
import java.util.concurrent.Executors
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.coroutines.suspendCoroutine

/**
 * Owns the Camera2 device and session.
 *
 * Only one surface is given to the camera: the SurfaceTexture the GL pipeline
 * reads from. Preview and encoder are downstream of GL, not downstream of the
 * camera. That costs one texture copy and buys three things — monitoring
 * overlays that never reach the file, a single place to apply the log curve and
 * ND offset, and, in stage 2, somewhere for the framing layer to crop without
 * the sensor knowing about it.
 *
 * The exception is high-speed capture, where the framework will not tolerate a
 * GL hop at 240 fps. That path wires the camera straight to the encoder and
 * gives up monitoring, which is the honest trade.
 */
class CameraCore(
    private val context: Context,
    private val onError: (String) -> Unit
) {
    private val manager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private val thread = HandlerThread("camera-core").apply { start() }
    private val handler = Handler(thread.looper)
    private val executor: Executor = Executors.newSingleThreadExecutor()

    private var device: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var builder: CaptureRequest.Builder? = null

    lateinit var capabilities: CameraCapabilities
        private set
    private lateinit var controller: CaptureController

    var lastReadback: CaptureController.Readback? = null
        private set

    /** All back lenses, already classified by role. */
    fun availableLenses(): List<CameraCapabilities> =
        LensSet.classifyBack(CameraCapabilities.probeAll(context))

    @SuppressLint("MissingPermission")
    suspend fun open(caps: CameraCapabilities) {
        close()
        capabilities = caps
        controller = CaptureController(caps)
        device = suspendCoroutine { cont ->
            manager.openCamera(caps.cameraId, handler.asExecutor(),
                object : CameraDevice.StateCallback() {
                    override fun onOpened(camera: CameraDevice) = cont.resume(camera)
                    override fun onDisconnected(camera: CameraDevice) {
                        camera.close()
                        onError("Camera disconnected")
                    }
                    override fun onError(camera: CameraDevice, error: Int) {
                        camera.close()
                        cont.resumeWithException(
                            IllegalStateException("Camera open failed, code $error"))
                    }
                })
        }
    }

    /**
     * @param targets the GL input surface, and — in high-speed mode only — the
     *                encoder surface as well.
     */
    suspend fun startSession(targets: List<Surface>, state: CameraState) {
        val cam = device ?: error("open() first")

        val template =
            if (state.isHighSpeed) CameraDevice.TEMPLATE_RECORD
            else CameraDevice.TEMPLATE_RECORD

        val b = cam.createCaptureRequest(template)
        targets.forEach { b.addTarget(it) }
        controller.apply(b, state)
        builder = b

        val configs = targets.map { surface ->
            OutputConfiguration(surface).also { cfg ->
                if (state.tenBit &&
                    Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                    capabilities.supportsHlg10
                ) {
                    cfg.dynamicRangeProfile = DynamicRangeProfiles.HLG10
                }
            }
        }

        val sessionType =
            if (state.isHighSpeed) SessionConfiguration.SESSION_HIGH_SPEED
            else SessionConfiguration.SESSION_REGULAR

        if (state.isHighSpeed && targets.size > 2) {
            error("High-speed sessions accept at most two surfaces")
        }

        session = suspendCoroutine { cont ->
            val cb = object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(s: CameraCaptureSession) = cont.resume(s)
                override fun onConfigureFailed(s: CameraCaptureSession) =
                    cont.resumeWithException(IllegalStateException("Session config failed"))
            }
            cam.createCaptureSession(SessionConfiguration(sessionType, configs, executor, cb))
        }

        submitRepeating(state)
    }

    /** Push a settings change without tearing the session down. */
    fun update(state: CameraState) {
        val b = builder ?: return
        controller.apply(b, state)
        submitRepeating(state)
    }

    /** Digital exposure offset the GL pass must apply for ND simulation. */
    fun residualNdStops(): Float =
        if (::controller.isInitialized) controller.residualNdStops else 0f

    private fun submitRepeating(state: CameraState) {
        val s = session ?: return
        val b = builder ?: return
        val listener = object : CameraCaptureSession.CaptureCallback() {
            override fun onCaptureCompleted(
                sess: CameraCaptureSession,
                request: CaptureRequest,
                result: TotalCaptureResult
            ) {
                lastReadback = controller.readback(result, state.frameRate)
            }
        }
        try {
            if (s is CameraConstrainedHighSpeedCaptureSession) {
                s.setRepeatingBurst(s.createHighSpeedRequestList(b.build()), listener, handler)
            } else {
                s.setRepeatingRequest(b.build(), listener, handler)
            }
        } catch (e: Exception) {
            Log.e(TAG, "repeating request failed", e)
            onError(e.message ?: "Capture failed")
        }
    }

    /**
     * Touch to focus. Pauses continuous AF, drives one precapture trigger at the
     * tapped region, then hands control back. Stage 2 hooks the same entry point
     * — manual focus always wins and suspends autonomous racking for 5 s.
     */
    fun focusAt(state: CameraState, normX: Float, normY: Float) {
        // Metering-region plumbing lands with the framing layer, which needs the
        // same sensor-to-view coordinate transform. Left deliberately unwritten
        // rather than written twice.
        update(state.copy(autoFocus = true))
    }

    fun close() {
        runCatching { session?.close() }
        runCatching { device?.close() }
        session = null; device = null; builder = null
    }

    fun release() {
        close()
        thread.quitSafely()
    }

    private fun Handler.asExecutor(): Executor = Executor { post(it) }

    private companion object { const val TAG = "CameraCore" }
}
