package ug.haruna.reporter.record

import kotlin.math.roundToLong

/**
 * SMPTE timecode.
 *
 * Drop-frame exists because 29.97 fps is not 30 fps: counting 30 frames per
 * second against a 29.97 clock drifts about 3.6 seconds per hour. Drop-frame
 * fixes the *labels* by skipping frame numbers 0 and 1 at the start of every
 * minute except every tenth minute. No frames are lost — only names are.
 *
 * Broadcast delivery in Uganda is 25p/50i PAL heritage, which is exactly
 * divisible and never drop-frame. The 29.97/59.94 path matters for anything cut
 * for a US-facing feed.
 */
class Timecode(private val fps: Double) {

    private val nominal: Int = when {
        fps > 59.0 && fps < 60.0 -> 60
        fps > 29.0 && fps < 30.0 -> 30
        else -> fps.roundToLong().toInt()
    }

    val isDropFrame: Boolean = (fps > 29.0 && fps < 30.0) || (fps > 59.0 && fps < 60.0)

    private var startNs: Long = 0L

    fun start(monotonicNs: Long) { startNs = monotonicNs }

    fun at(monotonicNs: Long): String = format(framesSince(monotonicNs))

    fun framesSince(monotonicNs: Long): Long =
        ((monotonicNs - startNs) / 1_000_000_000.0 * fps).toLong().coerceAtLeast(0L)

    fun format(frameNumber: Long): String {
        var f = frameNumber
        if (isDropFrame) f = applyDropFrame(f)

        val frames = (f % nominal).toInt()
        val totalSeconds = f / nominal
        val seconds = (totalSeconds % 60).toInt()
        val minutes = ((totalSeconds / 60) % 60).toInt()
        val hours = ((totalSeconds / 3600) % 24).toInt()

        val sep = if (isDropFrame) ';' else ':'
        return "%02d:%02d:%02d%c%02d".format(hours, minutes, seconds, sep, frames)
    }

    /**
     * Converts a real frame count into a drop-frame label index by adding back
     * the numbers that are skipped.
     */
    private fun applyDropFrame(frameNumber: Long): Long {
        val dropPerMinute = if (nominal == 60) 4L else 2L
        val framesPerMinute = nominal * 60L - dropPerMinute
        val framesPer10Minutes = nominal * 600L - dropPerMinute * 9L

        val tenMinuteBlocks = frameNumber / framesPer10Minutes
        var remainder = frameNumber % framesPer10Minutes

        var added = tenMinuteBlocks * dropPerMinute * 9L
        if (remainder >= nominal * 60L) {
            remainder -= nominal * 60L
            val extraMinutes = remainder / framesPerMinute
            added += dropPerMinute * (extraMinutes + 1L)
        }
        return frameNumber + added
    }
}
