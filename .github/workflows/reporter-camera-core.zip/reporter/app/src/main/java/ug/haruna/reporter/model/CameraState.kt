package ug.haruna.reporter.model

import ug.haruna.reporter.camera.CameraCapabilities

/**
 * Single source of truth for the capture layer. The Camera2 request builder, the
 * GL pipeline and the UI all read from this one object; nothing holds its own
 * copy of a setting. That matters more than it looks: the autonomous framing
 * layer arriving in stage 2 writes framing intent into this same state, and the
 * rule that auto-framing may never touch exposure is enforceable only because
 * exposure lives in exactly one place.
 */
data class CameraState(
    // ---- capture format ----
    val resolution: Resolution = Resolution.UHD_4K,
    val frameRate: Double = 25.0,
    val codec: Codec = Codec.H265_HIGH,
    val bitrateMbps: Int = 100,
    val tenBit: Boolean = false,

    // ---- manual exposure ----
    val autoExposure: Boolean = true,
    val iso: Int = 400,
    val shutterAngleDeg: Double = 180.0,
    val exposureLocked: Boolean = false,
    /** Stops of simulated ND. Pulls ISO to the floor first, then digital offset. */
    val ndStops: Float = 0f,

    // ---- colour ----
    val autoWhiteBalance: Boolean = true,
    val kelvin: Int = 5600,
    val tint: Int = 0,
    val logProfile: Boolean = false,

    // ---- focus ----
    val autoFocus: Boolean = true,
    /** Dioptres. 0.0 is infinity. */
    val focusDistance: Float = 0f,

    // ---- lens / stabilisation ----
    val lensRole: CameraCapabilities.LensRole = CameraCapabilities.LensRole.WIDE,
    val stabilisation: Stabilisation = Stabilisation.OFF,

    // ---- monitoring (display only, never recorded) ----
    val monitoring: Monitoring = Monitoring(),

    // ---- audio ----
    val audioGainDb: Float = 0f,
    val externalMic: Boolean = false,
    val headphoneMonitor: Boolean = false,

    // ---- runtime ----
    val recording: Boolean = false,
    val timecode: String = "00:00:00:00",
    val batteryPercent: Int = 100,
    val storageRemainingBytes: Long = 0L,
    val audioPeakDb: Pair<Float, Float> = -96f to -96f,
    val horizonRollDeg: Float = 0f,
    val warnings: List<String> = emptyList()
) {
    val isHighSpeed: Boolean get() = frameRate > 120.0

    /**
     * Constrained high-speed sessions reject most manual keys and cap the
     * surface count at two. Rather than letting requests fail silently, the UI
     * greys the manual bar when this is false.
     */
    val manualAvailable: Boolean get() = !isHighSpeed

    enum class Resolution(val width: Int, val height: Int, val label: String) {
        UHD_4K(3840, 2160, "4K"),
        FHD(1920, 1080, "1080p");
    }

    enum class Codec(val label: String) {
        /** Long-GOP H.265. Small files, fine for delivery. */
        H265_HIGH("H.265"),
        /**
         * All-intra H.265 at a very high bitrate. This is the "ProRes-style"
         * option — it edits like an intermediate codec, but it is not ProRes and
         * should never be labelled as such.
         */
        H265_ALL_I("H.265 ALL-I")
    }

    enum class Stabilisation { OFF, OPTICAL, ELECTRONIC }

    data class Monitoring(
        val focusPeaking: Boolean = false,
        val peakingThreshold: Float = 0.25f,
        val peakingColour: PeakColour = PeakColour.RED,
        val zebra: Boolean = false,
        val zebraIre: Float = 0.95f,
        val falseColour: Boolean = false,
        val waveform: Boolean = false,
        val histogram: Boolean = false,
        val previewLut: Boolean = false,
        val grid: Grid = Grid.NONE,
        val horizonLevel: Boolean = false
    ) {
        enum class PeakColour { RED, GREEN, BLUE, WHITE }
        enum class Grid { NONE, THIRDS, CROSSHAIR, SAFE_AREA }
    }
}
