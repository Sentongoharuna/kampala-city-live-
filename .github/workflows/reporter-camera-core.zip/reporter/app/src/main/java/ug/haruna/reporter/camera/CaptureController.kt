package ug.haruna.reporter.camera

import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.CaptureResult
import android.hardware.camera2.TotalCaptureResult
import android.util.Range
import ug.haruna.reporter.model.CameraState
import kotlin.math.pow

/**
 * Translates [CameraState] into a CaptureRequest.
 *
 * Ordering is not cosmetic here. Turning a manual control on means turning its
 * auto counterpart off in the same request — set SENSOR_EXPOSURE_TIME while
 * CONTROL_AE_MODE is still ON and the framework discards it without an error.
 * Every manual key below is paired with its mode key for that reason.
 */
class CaptureController(private val caps: CameraCapabilities) {

    /** How much digital exposure offset the GL pass has to make up for ND sim. */
    var residualNdStops: Float = 0f
        private set

    fun apply(b: CaptureRequest.Builder, s: CameraState) {
        if (s.isHighSpeed) {
            // Constrained high-speed accepts almost nothing. Ask for the range
            // and leave everything else to the device.
            b.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE,
                Range(s.frameRate.toInt(), s.frameRate.toInt()))
            residualNdStops = 0f
            return
        }

        applyExposure(b, s)
        applyWhiteBalance(b, s)
        applyFocus(b, s)
        applyStabilisation(b, s)

        // Keep the frame duration pinned so the encoder's PTS spacing and the
        // sensor's actual cadence agree. Drifting here shows up later as audio
        // sync error that is very hard to trace back.
        b.set(CaptureRequest.SENSOR_FRAME_DURATION, (1_000_000_000.0 / s.frameRate).toLong())

        // Vendor scene modes and effects fight manual control. Off, always.
        b.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO)
        b.set(CaptureRequest.CONTROL_SCENE_MODE, CaptureRequest.CONTROL_SCENE_MODE_DISABLED)
        b.set(CaptureRequest.CONTROL_EFFECT_MODE, CaptureRequest.CONTROL_EFFECT_MODE_OFF)
        b.set(CaptureRequest.NOISE_REDUCTION_MODE,
            if (s.logProfile) CaptureRequest.NOISE_REDUCTION_MODE_MINIMAL
            else CaptureRequest.NOISE_REDUCTION_MODE_FAST)
    }

    private fun applyExposure(b: CaptureRequest.Builder, s: CameraState) {
        if (s.autoExposure || !caps.supportsManualSensor) {
            b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
            b.set(CaptureRequest.CONTROL_AE_LOCK, s.exposureLocked)
            b.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE,
                Range(s.frameRate.toInt(), s.frameRate.toInt()))
            residualNdStops = 0f
            return
        }

        b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)

        val resolved = ShutterAngle.resolve(
            s.shutterAngleDeg,
            s.frameRate,
            caps.exposureRangeNs.lower..caps.exposureRangeNs.upper
        )
        b.set(CaptureRequest.SENSOR_EXPOSURE_TIME, resolved.exposureNs)

        // ND simulation. There is no physical filter, so we buy back exposure by
        // pulling ISO down first — that is free and it reduces noise. Only once
        // ISO hits the sensor floor do we hand the remainder to the GL pass as a
        // digital offset, which does cost highlight headroom.
        val isoFloor = caps.isoRange.lower
        val wantedIso = (s.iso / 2.0.pow(s.ndStops.toDouble())).toInt()
        val appliedIso = wantedIso.coerceIn(isoFloor, caps.isoRange.upper)
        residualNdStops =
            if (wantedIso < isoFloor) (kotlin.math.log2(isoFloor.toDouble() / wantedIso)).toFloat()
            else 0f

        b.set(CaptureRequest.SENSOR_SENSITIVITY, appliedIso)
    }

    private fun applyWhiteBalance(b: CaptureRequest.Builder, s: CameraState) {
        if (s.autoWhiteBalance || !caps.supportsManualPostProcessing) {
            b.set(CaptureRequest.CONTROL_AWB_MODE, CaptureRequest.CONTROL_AWB_MODE_AUTO)
            b.set(CaptureRequest.COLOR_CORRECTION_MODE,
                CaptureRequest.COLOR_CORRECTION_MODE_FAST)
            return
        }
        // All three keys or none — see the note in WhiteBalance.
        b.set(CaptureRequest.CONTROL_AWB_MODE, CaptureRequest.CONTROL_AWB_MODE_OFF)
        b.set(CaptureRequest.COLOR_CORRECTION_MODE,
            CaptureRequest.COLOR_CORRECTION_MODE_TRANSFORM_MATRIX)
        b.set(CaptureRequest.COLOR_CORRECTION_TRANSFORM, WhiteBalance.IDENTITY_TRANSFORM)
        b.set(CaptureRequest.COLOR_CORRECTION_GAINS, WhiteBalance.gains(s.kelvin, s.tint))
    }

    private fun applyFocus(b: CaptureRequest.Builder, s: CameraState) {
        if (s.autoFocus) {
            b.set(CaptureRequest.CONTROL_AF_MODE,
                CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO)
        } else {
            b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_OFF)
            b.set(CaptureRequest.LENS_FOCUS_DISTANCE,
                s.focusDistance.coerceIn(0f, caps.minFocusDistanceDiopters))
        }
    }

    private fun applyStabilisation(b: CaptureRequest.Builder, s: CameraState) {
        when (s.stabilisation) {
            CameraState.Stabilisation.OFF -> {
                b.set(CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE,
                    CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_OFF)
                b.set(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE,
                    CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_OFF)
            }
            CameraState.Stabilisation.OPTICAL -> {
                if (caps.hasOis) b.set(CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE,
                    CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_ON)
                b.set(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE,
                    CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_OFF)
            }
            CameraState.Stabilisation.ELECTRONIC -> {
                // EIS crops the sensor read. Stage 2's virtual pan/tilt also
                // spends crop budget, so the two must not both be on — the
                // framing layer owns the crop once it exists.
                b.set(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE,
                    CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_ON)
            }
        }
    }

    /** What the sensor actually did, for the status readout. */
    fun readback(result: TotalCaptureResult, fps: Double): Readback {
        val exposure = result.get(CaptureResult.SENSOR_EXPOSURE_TIME) ?: 0L
        return Readback(
            iso = result.get(CaptureResult.SENSOR_SENSITIVITY) ?: 0,
            exposureNs = exposure,
            shutterAngleDeg = if (exposure > 0) ShutterAngle.fromExposureNs(exposure, fps) else 0.0,
            focusDistance = result.get(CaptureResult.LENS_FOCUS_DISTANCE) ?: 0f,
            afLocked = result.get(CaptureResult.CONTROL_AF_STATE) ==
                CaptureResult.CONTROL_AF_STATE_FOCUSED_LOCKED
        )
    }

    data class Readback(
        val iso: Int,
        val exposureNs: Long,
        val shutterAngleDeg: Double,
        val focusDistance: Float,
        val afLocked: Boolean
    )
}
