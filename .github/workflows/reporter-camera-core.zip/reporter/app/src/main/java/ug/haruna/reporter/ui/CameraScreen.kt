package ug.haruna.reporter.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.Canvas
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import ug.haruna.reporter.camera.ShutterAngle
import ug.haruna.reporter.model.CameraState
import ug.haruna.reporter.pipeline.ScopeSampler

/**
 * The control surface.
 *
 * Layout rule the brief sets and this follows literally: every control is one
 * tap from the viewfinder, and the phone is held in two hands with the right
 * thumb over the record button. So the manual bar runs along the bottom edge
 * within thumb reach, the status readouts sit top-left away from the thumb, and
 * nothing opens a modal — tapping a control expands it in place over the image.
 */
@Composable
fun CameraScreen(
    state: CameraState,
    scopes: ScopeSampler,
    onState: (CameraState) -> Unit,
    onRecordToggle: () -> Unit,
    onFocusTap: (Float, Float) -> Unit,
    viewfinder: @Composable (Modifier) -> Unit
) {
    var expanded by remember { mutableStateOf<String?>(null) }

    Box(Modifier.fillMaxSize().background(Broadcast.Black)) {

        viewfinder(
            Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGestures { pos ->
                        onFocusTap(pos.x / size.width, pos.y / size.height)
                    }
                }
        )

        // Tally border. Deliberately the full frame edge rather than a dot —
        // it has to be unmistakable in peripheral vision while the operator is
        // watching the subject, not the screen.
        if (state.recording) {
            Box(Modifier.fillMaxSize().border(4.dp, Broadcast.Tally))
        }

        if (state.monitoring.grid != CameraState.Monitoring.Grid.NONE) {
            GridOverlay(state.monitoring.grid, Modifier.fillMaxSize())
        }

        StatusStrip(state, Modifier.align(Alignment.TopStart).padding(12.dp))

        Column(
            Modifier.align(Alignment.TopEnd).padding(12.dp),
            horizontalAlignment = Alignment.End
        ) {
            if (state.monitoring.waveform) Waveform(scopes, Modifier.size(180.dp, 90.dp))
            Spacer(Modifier.height(8.dp))
            if (state.monitoring.histogram) Histogram(scopes, Modifier.size(180.dp, 70.dp))
        }

        state.warnings.firstOrNull()?.let { warning ->
            Text(
                warning,
                color = Broadcast.Attention,
                fontFamily = Broadcast.Mono,
                fontSize = Broadcast.LabelSize,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 12.dp)
                    .background(Broadcast.Chrome.copy(alpha = 0.9f), RoundedCornerShape(3.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            )
        }

        ControlBar(
            state = state,
            expanded = expanded,
            onExpand = { expanded = if (expanded == it) null else it },
            onState = onState,
            modifier = Modifier.align(Alignment.BottomCenter)
        )

        RecordButton(
            recording = state.recording,
            onClick = onRecordToggle,
            modifier = Modifier.align(Alignment.CenterEnd).padding(end = 20.dp)
        )
    }
}

@Composable
private fun StatusStrip(state: CameraState, modifier: Modifier) {
    Column(modifier) {
        Readout(state.timecode, if (state.recording) Broadcast.Tally else Broadcast.Text, 18)
        Spacer(Modifier.height(4.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Readout("${state.resolution.label} ${fmtFps(state.frameRate)}")
            Readout(state.codec.label)
            Readout("${state.bitrateMbps}Mb")
            if (state.tenBit) Readout("10-BIT", Broadcast.Active)
            if (state.logProfile) Readout("LOG", Broadcast.Active)
        }
        Spacer(Modifier.height(4.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Readout("${state.batteryPercent}%",
                if (state.batteryPercent < 15) Broadcast.Attention else Broadcast.TextDim)
            Readout(remainingTime(state), Broadcast.TextDim)
            AudioMeter(state.audioPeakDb)
        }
    }
}

/**
 * Record time remaining, not gigabytes. At all-intra 4K60 the difference between
 * "18 GB free" and "4 minutes left" is the difference between a usable warning
 * and a number nobody can act on mid-take.
 */
private fun remainingTime(s: CameraState): String {
    val bytesPerSecond = s.bitrateMbps * 125_000L
    if (bytesPerSecond <= 0) return "--:--"
    val seconds = s.storageRemainingBytes / bytesPerSecond
    return "%02d:%02d REM".format(seconds / 60, seconds % 60)
}

private fun fmtFps(fps: Double): String =
    if (fps % 1.0 == 0.0) "${fps.toInt()}p" else "%.2fp".format(fps)

@Composable
private fun Readout(text: String, colour: Color = Broadcast.Text, size: Int = 13) {
    Text(text, color = colour, fontFamily = Broadcast.Mono,
        fontSize = size.sp, fontWeight = FontWeight.Medium)
}

@Composable
private fun AudioMeter(levels: Pair<Float, Float>) {
    val (l, r) = levels
    Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
        listOf(l, r).forEach { db ->
            // -96..0 dBFS mapped across the bar, with the last 6 dB in red.
            val fraction = ((db + 60f) / 60f).coerceIn(0f, 1f)
            Canvas(Modifier.size(54.dp, 5.dp)) {
                drawRect(Broadcast.Rule, size = size)
                drawRect(
                    if (db > -6f) Broadcast.Tally else Broadcast.Active,
                    size = size.copy(width = size.width * fraction)
                )
            }
        }
        Spacer(Modifier.width(4.dp))
        Readout("%.0f".format(maxOf(l, r)), Broadcast.TextDim, 10)
    }
}

@Composable
private fun ControlBar(
    state: CameraState,
    expanded: String?,
    onExpand: (String) -> Unit,
    onState: (CameraState) -> Unit,
    modifier: Modifier
) {
    Column(modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {

        expanded?.let { key -> ExpandedControl(key, state, onState) }

        Row(
            Modifier
                .fillMaxWidth()
                .background(Broadcast.Chrome.copy(alpha = 0.94f))
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Cell("ISO", if (state.autoExposure) "AUTO" else state.iso.toString(),
                state.manualAvailable) { onExpand("iso") }
            Cell("SHUTTER", "%.0f°".format(state.shutterAngleDeg),
                state.manualAvailable) { onExpand("shutter") }
            Cell("WB", if (state.autoWhiteBalance) "AWB" else "${state.kelvin}K",
                state.manualAvailable) { onExpand("wb") }
            Cell("TINT", state.tint.toString(), state.manualAvailable) { onExpand("wb") }
            Cell("FOCUS", if (state.autoFocus) "AF" else "%.2f".format(state.focusDistance),
                true) { onExpand("focus") }
            Cell("ND", if (state.ndStops == 0f) "—" else "%.0f".format(state.ndStops),
                state.manualAvailable) { onExpand("nd") }
            Cell("LENS", state.lensRole.name.take(2), true) { onExpand("lens") }
            Cell("LOCK", if (state.exposureLocked) "ON" else "OFF", true) {
                onState(state.copy(exposureLocked = !state.exposureLocked))
            }
            Cell("TOOLS", activeToolCount(state).toString(), true) { onExpand("tools") }
        }
    }
}

private fun activeToolCount(s: CameraState): Int = listOf(
    s.monitoring.focusPeaking, s.monitoring.zebra, s.monitoring.falseColour,
    s.monitoring.waveform, s.monitoring.histogram, s.monitoring.previewLut
).count { it }

@Composable
private fun Cell(label: String, value: String, enabled: Boolean, onClick: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 6.dp)
    ) {
        Text(label, color = if (enabled) Broadcast.TextDim else Broadcast.Rule,
            fontFamily = Broadcast.Mono, fontSize = Broadcast.LabelSize)
        Text(value, color = if (enabled) Broadcast.Text else Broadcast.Rule,
            fontFamily = Broadcast.Mono, fontSize = Broadcast.ReadoutSize,
            fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun ExpandedControl(key: String, state: CameraState, onState: (CameraState) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .background(Broadcast.Black.copy(alpha = 0.88f))
            .padding(horizontal = 12.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        when (key) {
            "shutter" -> {
                Chip("AUTO", state.autoExposure) { onState(state.copy(autoExposure = true)) }
                ShutterAngle.DETENTS.forEach { angle ->
                    Chip(
                        "%.0f°".format(angle),
                        !state.autoExposure && state.shutterAngleDeg == angle
                    ) { onState(state.copy(autoExposure = false, shutterAngleDeg = angle)) }
                }
                Spacer(Modifier.weight(1f))
                Readout(
                    ShutterAngle.asFractionLabel(
                        ShutterAngle.toExposureNs(state.shutterAngleDeg, state.frameRate)
                    ), Broadcast.TextDim, 11
                )
            }
            "iso" -> {
                Chip("AUTO", state.autoExposure) { onState(state.copy(autoExposure = true)) }
                listOf(100, 200, 400, 800, 1600, 3200, 6400).forEach { iso ->
                    Chip(iso.toString(), !state.autoExposure && state.iso == iso) {
                        onState(state.copy(autoExposure = false, iso = iso))
                    }
                }
            }
            "wb" -> {
                Chip("AWB", state.autoWhiteBalance) {
                    onState(state.copy(autoWhiteBalance = true))
                }
                listOf(2800, 3200, 4300, 5600, 6500, 7500).forEach { k ->
                    Chip("${k / 100}", !state.autoWhiteBalance && state.kelvin == k) {
                        onState(state.copy(autoWhiteBalance = false, kelvin = k))
                    }
                }
            }
            "nd" -> listOf(0f, 1f, 2f, 3f, 4f, 6f).forEach { stops ->
                Chip(if (stops == 0f) "CLEAR" else "${stops.toInt()} STOP",
                    state.ndStops == stops) { onState(state.copy(ndStops = stops)) }
            }
            "tools" -> {
                val m = state.monitoring
                Chip("PEAK", m.focusPeaking) {
                    onState(state.copy(monitoring = m.copy(focusPeaking = !m.focusPeaking)))
                }
                Chip("ZEBRA", m.zebra) {
                    onState(state.copy(monitoring = m.copy(zebra = !m.zebra)))
                }
                Chip("FALSE", m.falseColour) {
                    onState(state.copy(monitoring = m.copy(falseColour = !m.falseColour)))
                }
                Chip("WFM", m.waveform) {
                    onState(state.copy(monitoring = m.copy(waveform = !m.waveform)))
                }
                Chip("HIST", m.histogram) {
                    onState(state.copy(monitoring = m.copy(histogram = !m.histogram)))
                }
                Chip("LUT", m.previewLut) {
                    onState(state.copy(monitoring = m.copy(previewLut = !m.previewLut)))
                }
                Chip("GRID", m.grid != CameraState.Monitoring.Grid.NONE) {
                    val next = CameraState.Monitoring.Grid.entries[
                        (m.grid.ordinal + 1) % CameraState.Monitoring.Grid.entries.size]
                    onState(state.copy(monitoring = m.copy(grid = next)))
                }
            }
        }
    }
}

@Composable
private fun Chip(label: String, active: Boolean, onClick: () -> Unit) {
    Text(
        label,
        color = if (active) Broadcast.Black else Broadcast.Text,
        fontFamily = Broadcast.Mono,
        fontSize = Broadcast.ReadoutSize,
        modifier = Modifier
            .background(
                if (active) Broadcast.Active else Broadcast.Chrome,
                RoundedCornerShape(3.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp)
    )
}

@Composable
private fun RecordButton(recording: Boolean, onClick: () -> Unit, modifier: Modifier) {
    Box(
        modifier
            .size(64.dp)
            .background(Broadcast.Chrome.copy(alpha = 0.6f), CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Box(
            Modifier
                .size(if (recording) 26.dp else 46.dp)
                .background(Broadcast.Tally,
                    if (recording) RoundedCornerShape(4.dp) else CircleShape)
        )
    }
}

@Composable
private fun GridOverlay(grid: CameraState.Monitoring.Grid, modifier: Modifier) {
    Canvas(modifier) {
        val line = Color.White.copy(alpha = 0.28f)
        when (grid) {
            CameraState.Monitoring.Grid.THIRDS -> {
                for (i in 1..2) {
                    val x = size.width * i / 3f
                    val y = size.height * i / 3f
                    drawLine(line, Offset(x, 0f), Offset(x, size.height), 1f)
                    drawLine(line, Offset(0f, y), Offset(size.width, y), 1f)
                }
            }
            CameraState.Monitoring.Grid.CROSSHAIR -> {
                drawLine(line, Offset(size.width / 2, size.height / 2 - 30f),
                    Offset(size.width / 2, size.height / 2 + 30f), 1.5f)
                drawLine(line, Offset(size.width / 2 - 30f, size.height / 2),
                    Offset(size.width / 2 + 30f, size.height / 2), 1.5f)
            }
            CameraState.Monitoring.Grid.SAFE_AREA -> {
                val inset = 0.05f
                drawRect(
                    line,
                    topLeft = Offset(size.width * inset, size.height * inset),
                    size = size.copy(size.width * (1 - 2 * inset),
                        size.height * (1 - 2 * inset)),
                    style = Stroke(1f)
                )
            }
            else -> Unit
        }
    }
}

@Composable
private fun Waveform(scopes: ScopeSampler, modifier: Modifier) {
    val data = scopes.waveform
    Canvas(modifier.background(Broadcast.Black.copy(alpha = 0.8f))) {
        val cw = size.width / ScopeSampler.WAVE_W
        val ch = size.height / ScopeSampler.WAVE_H
        for (y in 0 until ScopeSampler.WAVE_H) {
            for (x in 0 until ScopeSampler.WAVE_W) {
                val v = data[y * ScopeSampler.WAVE_W + x].toInt() and 0xFF
                if (v > 0) {
                    drawRect(
                        Broadcast.Active.copy(alpha = v / 255f),
                        topLeft = Offset(x * cw, y * ch),
                        size = androidx.compose.ui.geometry.Size(cw, ch)
                    )
                }
            }
        }
        // 100 IRE and 0 IRE reference lines.
        drawLine(Broadcast.Tally.copy(alpha = 0.5f), Offset(0f, 0f), Offset(size.width, 0f), 1f)
        drawLine(Broadcast.Tally.copy(alpha = 0.5f),
            Offset(0f, size.height), Offset(size.width, size.height), 1f)
    }
}

@Composable
private fun Histogram(scopes: ScopeSampler, modifier: Modifier) {
    val h = scopes.histogram
    Canvas(modifier.background(Broadcast.Black.copy(alpha = 0.8f))) {
        val bw = size.width / 256f
        listOf(
            h.red to Color(0x99FF4136),
            h.green to Color(0x9901FF70),
            h.blue to Color(0x990074D9)
        ).forEach { (channel, colour) ->
            for (i in 0 until 256) {
                val barHeight = size.height * (channel[i].toFloat() / h.peak)
                drawRect(
                    colour,
                    topLeft = Offset(i * bw, size.height - barHeight),
                    size = androidx.compose.ui.geometry.Size(bw, barHeight)
                )
            }
        }
    }
}
