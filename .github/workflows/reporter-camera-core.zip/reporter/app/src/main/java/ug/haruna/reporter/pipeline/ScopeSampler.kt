package ug.haruna.reporter.pipeline

import kotlin.math.max

/**
 * Builds the waveform and the RGB histogram from the 256×144 readback.
 *
 * Running this on the GL thread would stall the pipeline, so the render loop
 * hands over a copied buffer and returns immediately. At 1/3 frame cadence this
 * costs roughly 3 ms per sample on a mid-range chip, off the capture path
 * entirely.
 *
 * The waveform is a luma parade: for every source column, a 256-bucket vertical
 * histogram of luma, which is what gives the classic smeared-trace look rather
 * than a line graph.
 */
class ScopeSampler {

    @Volatile var waveform: ByteArray = ByteArray(WAVE_W * WAVE_H)
        private set
    @Volatile var histogram: Histogram = Histogram()
        private set

    fun submit(rgba: ByteArray, w: Int, h: Int) {
        val wave = ByteArray(WAVE_W * WAVE_H)
        val r = IntArray(256); val g = IntArray(256); val b = IntArray(256); val l = IntArray(256)

        var i = 0
        for (y in 0 until h) {
            for (x in 0 until w) {
                val rr = rgba[i].toInt() and 0xFF
                val gg = rgba[i + 1].toInt() and 0xFF
                val bb = rgba[i + 2].toInt() and 0xFF
                i += 4

                r[rr]++; g[gg]++; b[bb]++

                val luma = ((rr * 54 + gg * 183 + bb * 19) shr 8).coerceIn(0, 255)
                l[luma]++

                // Map the source column onto the waveform's width, and luma onto
                // its height inverted, so black sits at the bottom like a scope.
                val wx = x * WAVE_W / w
                val wy = (255 - luma) * WAVE_H / 256
                val idx = wy * WAVE_W + wx
                val cur = wave[idx].toInt() and 0xFF
                if (cur < 250) wave[idx] = (cur + 24).toByte()
            }
        }

        waveform = wave
        histogram = Histogram(r, g, b, l, normalise = true)
    }

    data class Histogram(
        val red: IntArray = IntArray(256),
        val green: IntArray = IntArray(256),
        val blue: IntArray = IntArray(256),
        val luma: IntArray = IntArray(256),
        private val normalise: Boolean = false
    ) {
        /** Peak across all channels — the scale every channel is drawn against. */
        val peak: Int = if (!normalise) 1 else max(
            1,
            maxOf(red.max(), green.max(), blue.max())
        )

        /** Fraction of pixels sitting at 0 or 255 — drives the clipping warning. */
        val shadowClipped: Float get() = luma[0].toFloat() / max(1, luma.sum())
        val highlightClipped: Float get() = luma[255].toFloat() / max(1, luma.sum())

        override fun equals(other: Any?) = this === other
        override fun hashCode() = System.identityHashCode(this)
    }

    companion object {
        const val WAVE_W = 256
        const val WAVE_H = 128
    }
}
